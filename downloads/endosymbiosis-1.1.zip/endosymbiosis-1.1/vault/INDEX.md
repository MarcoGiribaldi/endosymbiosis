# BÓVEDA — lo que terminó

> Navegar: [[start]] · [[state]] · [[decisions]] · [[DEFERRED]]
> Aquí baja lo cerrado, una línea por cierre y nunca reescrita: `- P4 · qué era [CLOSED AAAA-MM-DD · done · evidence: dónde se ve]`.
> Cuando este archivo crezca mucho, se abre uno por mes (`vault/2026-11.md`) y aquí queda una línea que apunta a él.
> Para encontrar algo de aquí o de cualquier época: `python3 organs/search.py "palabra|sinónimo"`.

