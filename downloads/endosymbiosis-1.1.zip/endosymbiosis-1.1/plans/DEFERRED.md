# DEFERRED — lo postergado a propósito, con su gatillo

> Navegar: [[start]] · [[state]] · [[decisions]] · [[vault/INDEX|bóveda]]
> Un diferido es algo que se decide **no hacer ahora**, sin perderlo. No se carga al empezar: el canario lo revisa solo.
> Una línea por diferido, con un ID que nunca se reusa y **uno de los dos gatillos**:
> - `until:AAAA-MM-DD` → cuando pasa la fecha, el canario lo pone en 🔴 y vuelve a [[state]] como pendiente nuevo.
> - `when: <condición en palabras>` → el canario lo muestra como ⏳ al empezar, para mirar si ya se cumplió.
> Si venía del estado, se anota de dónde: `was:P4`. Al reactivarlo o descartarlo no se borra la línea: se le agrega `[CLOSED AAAA-MM-DD · reactivated as P9]` o `[CLOSED AAAA-MM-DD · dropped · reason: …]`.
>
> Forma: `- DEF-1 · was:P4 · until:2026-12-01 · qué es, en palabras · por qué se postergó`

