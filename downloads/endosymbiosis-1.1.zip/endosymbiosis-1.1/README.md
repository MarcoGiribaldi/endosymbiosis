# Endosimbiosis 1.1 — léeme primero

> **Versión de investigación, en piloto con un grupo chico de usuarios.** Probada en Linux, Windows 11 y macOS (instalación, los siete órganos y los dos modos del guardián: ver § Alcance); con Claude Code y Antigravity en uso diario. Es una red que reduce errores, no una garantía.

Es tu memoria con la IA (ocho notas en `core/`: `start.md`, `canary.md`, `state.md`, `profile.md`, `context.md`, `agreement.md`, `course.md` y `decisions.md`) más siete piezas chicas que la cuidan sin depender de la buena voluntad del modelo. No tienes que entender el código: lo instalas una vez y tu IA hace el resto contigo.

**Cuatro palabras.** **Núcleo** (*long-term memory*): tus ocho notas. **Jaula** (*immutable files*) (`organs/`): las piezas; la IA las lee y las corre, nunca las cambia. **Commit**: la foto que git guarda de tu carpeta («hacer commit» = guardar la foto). **Hook**: el gancho con el que tu programa de IA, o git, llama a una pieza antes de actuar.

## Las siete piezas, en una frase cada una
- **guardián** (*PreToolUse hook*) — sus reglas: la IA no borra nada, no reescribe la historia de git, no entra a tus carpetas privadas (las anotas tú en `organs/denied.txt`, una por línea), no toca la jaula y no salta el filtro de secretos (*pre-commit hook*). Viene en dos modos (ver «El guardián en dos modos»): en **prosa** (*modo pasivo*), el de fábrica, esas reglas están escritas y la IA las cumple; en **código** (*modo enforcing*), además la frena antes de cada acción. Tiene una **segunda puerta**, `secret_scan.py`, en los dos modos: antes de cada commit, git le pregunta si lo que va a entrar lleva una llave, una contraseña con su etiqueta y dos puntos, igual o un espacio (`password: …`, `contraseña = …`, `contraseña …`; también en una frase con «es», «mi clave del banco es …», si el valor tiene 8 caracteres o más y una cifra; no ve una clave sin etiqueta ni «es», ni una de menos de 8 o sin cifra, «mi clave es 1234»: medido el 3-nov-2026) o un DNI con su palabra al lado; si lo lleva, el commit no entra.
- **apartar** (*quarantine*, `python3 organs/quarantine.py <ruta> <motivo>`) — en vez de borrar, mueve lo que sobra a `_QUARANTINE/`; esa carpeta la revisas y la vacías tú.
- **libre** (*just-in-time access*) — en código, tu llave: por unos minutos, el guardián te deja pasar a tus carpetas privadas (pide tu clave). Borrar o cambiar la jaula, nunca.
- **canario** (*startup integrity check*) — al empezar, pasa lista: que no se haya perdido ningún pendiente desde que empezaste a usar git, que el hook de secretos esté puesto y el guardián: en código, que esté vivo; en prosa, que `organs/` siga igual y que nada se haya borrado sin pasar por `_QUARANTINE/`. También mide cuánto de la ventana de la IA se lleva tu núcleo al empezar (🟡 sobre el 15 %; `window: N` en `core/start.md` lo ajusta).
- **buscador** (*working tree + git history search*) — busca en todo lo que hay en tu carpeta y en todo lo que alguna vez guardaste con git, y dice dónde buscó y qué encontró; «no existe» solo después de buscar en lo de hoy y en el historial.
- **DAISY** (*AI disclosure*) — cuenta quién hizo cada cambio (tú o la IA) y frena el cierre (*end-of-session*) si uno quedó sin firma (*git trailer*); si ya no es el último, un commit firmado «atribuye <hash>: …» lo da por atribuido. Su borrador de declaración sale en inglés porque es para una revista: lo lees con tu IA.

## Antes (una sola vez)
Necesitas Python 3.10 o más nuevo y git. En Windows, en PowerShell: `winget install Python.Python.3.12` y `winget install Git.Git`; cierra y vuelve a abrir PowerShell. Si no puedes usar `winget`, descarga Python de python.org y marca «Add to PATH». **Los comandos de este texto usan `python3` (Mac y Linux). En Windows escribe `python` donde diga `python3`.**

## Instalar (5 minutos)
1. Pon esta carpeta donde quieras tu núcleo, sin espacios en el nombre (por ejemplo `C:\proyectos\mi-nucleo`).
2. Abre una terminal en esa carpeta y corre `python3 install.py`. Escribe `si` cuando pregunte. Cuando pregunte el modo del guardián, Enter es **prosa**; `codigo` es código.
3. El instalador hace cinco pasos: revisa, copia (y pone el hook de git de secretos), elige el modo del guardián, prueba y te dice cómo empezar. Al final compara los ganchos que ya tenías (de Claude Code, de Antigravity, de Codex y de git) con los de ahora: si se cayó alguno, te lo dice en 🔴.
4. Tiene que terminar con **✅ el núcleo nació** (prosa) o **✅ el guardián nació** (código). Si dice 🔴, manda la salida a quien te pasó el kit (y en código, no uses la IA con permisos libres).
5. **Activa las instantáneas de tu sistema**: en Windows, «Historial de archivos»; en Mac, «Time Machine»; en Linux, las instantáneas de tu disco. Son la red que el guardián no es. En código, al terminar, el instalador pone el candado en `organs/` (ver más abajo).

Después abre tu IA en esta carpeta y dile: «Lee ENDOSYMBIOSIS.md y arma mi núcleo conmigo, una pregunta a la vez.»

## El guardián en dos modos
**Prosa (el de fábrica).** El guardián se copia pero no se registra: no frena nada. Sus reglas quedan escritas en `AGENTS.md` y en tu trato (*operating policy*) (`core/agreement.md`, reglas 1 y 2: nada se borra y la jaula no se toca; secretos y datos de clientes, nunca), y la IA las cumple. Al instalar se guarda la **huella** (*integrity hash*) de `organs/` y, en cada arranque, el canario mira que `organs/` siga igual y que nada de lo que estaba en git haya desaparecido sin pasar por `_QUARANTINE/` (apartar, mover o renombrar no cuenta). Si encuentra algo, lo dice en 🔴 y te recomienda pasar a código, en cada arranque mientras siga. Si lo viste (o el cambio lo hiciste tú, por ejemplo en `denied.txt`): `python3 install.py --guardian off` toma la huella de nuevo, «lo vi, sigo en prosa».
**Código.** `python3 install.py --guardian on`: el guardián se registra en Claude Code, en Antigravity y, si tienes Codex (el programa `codex` o la carpeta `~/.codex/`), en Codex; frena a la IA antes de cada acción que rompe una regla y `organs/` queda con candado. Con Claude Code 2.1.295 o más nuevo se registra con `"onFailure": "block"`: si el guardián falla o se cuelga, frena en vez de dejar pasar (con una versión anterior te avisa y no lo pone). **En Codex** hay un paso más, tuyo: abre Codex en la carpeta del núcleo, escribe `/hooks` y aprueba el guardián (una vez; si el guardián cambia, otra vez). Codex no corre un gancho que no aprobaste, y si el guardián se cae o se pasa de tiempo, Codex deja seguir la acción (no tiene el «onFailure» de Claude Code). El instalador lo registra solo en tu `~/.codex/hooks.json`; un gancho en `<carpeta>/.codex/hooks.json` Codex lo carga solo si marcaste esa carpeta como de confianza, y el canario no puede ver si lo hiciste. En Codex el guardián también lee sus ediciones por parche (`apply_patch`): borrar un archivo con un parche es borrar, y editar la jaula con un parche es editar la jaula. Probado con Codex CLI real en Linux (D230) y en Windows 11 (D231): medido en Windows y en Linux (4-nov-2026): Codex no obedece el «no» que el guardián da como error de salida (el que obedece Claude Code) y sí el que va escrito en su respuesta, así que a Codex el guardián le responde de las dos formas; en modo interactivo la persona aprueba el gancho una vez con `/hooks`. Con un modelo local (o ChatGPT en el navegador) no hay código: todo es prosa.
**Cambiar de modo** lo haces tú, en tu terminal; la IA no (el instalador no corre sin una terminal de verdad). Cierra y vuelve a abrir tu IA después.

## Tres advertencias
**Abre tu IA siempre en esta carpeta** (la que tiene `core/`): abierta en otra carpeta, la IA no lee tu núcleo. El canario te lo grita en 🔴 si pasa.

**Si ya tienes un sistema** (notas, reglas o scripts propios): el instalador no pisa tu `core/` y pregunta antes de tocar tu configuración (guarda una copia de la anterior en `_QUARANTINE/`). Si ya tenías un hook `pre-commit`, queda como `pre-commit.anterior` y corre primero. Si ya tenías el guardián en código, una instalación nueva no lo baja a prosa. Lo viejo sin fecha ni gatillo es tu línea base, no un rojo. Y si tu forma de trabajar borra en carpetas temporales, en código el guardián lo va a frenar: decídelo con tu IA antes de pasar a código. **Para pasar tu memoria vieja al núcleo** (arranque, perfiles, misiones (*workstream*), bitácora, Obsidian), dile a tu IA: «Lee MIGRATE.md y migra lo mío»: te hace cuatro preguntas juntas al principio, hace sola lo reversible y al final te entrega la lista de lo que espera tu palabra.

**Tu programa también decide**: Claude Code y Antigravity tienen su propio permiso por herramienta y pueden preguntar o frenar lo que el núcleo da por verde. No es un fallo del guardián.

## La prueba de vida, sin código
En código, cada vez que empiezas, el canario le hace al guardián cuatro preguntas trampa, como un simulacro de incendio: «¿puedo borrar este archivo desde mi carpeta personal?», «¿y desde la carpeta del núcleo?», «¿puedo leer tus llaves?», «¿puedo escribir dentro de la jaula?». Las cuatro son de mentira. Si el guardián dice «no» a todas, con su propio aviso, el canario escribe **✅ guardián vivo**; si una sola pasa, o si responde algo que no es el guardián (por ejemplo, porque la carpeta se movió), **🔴 GUARDIÁN DESCONECTADO** (en Antigravity la cuarta no se hace; en Codex hay una quinta: «¿puedo borrar este archivo con un parche?»). En Codex el canario dice **✅ guardián responde (codex)** y no «vivo»: prueba que el guardián frena, no que Codex lo corra; eso depende de que lo hayas aprobado con `/hooks`, y el canario no lo puede ver. En prosa no hay simulacro: el canario escribe **⚪ guardián en prosa (elegido)**.

## Qué cambió en la 1.1 (nov-2026)
- **Nombres en inglés** (D230): carpetas, archivos y flags que lee la máquina: `core/`, `organs/`, `vault/`, `plans/`, `_QUARANTINE/`; `README.md`, `ENDOSYMBIOSIS.md`, `MIGRATE.md`, `install.py`; los órganos `guardian.py`, `quarantine.py`, `canary.py`, `search.py`, `free.py`, `secret_scan.py`, `daisy.py`, con `denied.txt` y `checks.txt`; y `--guardian on|off`, `--open`/`--close`, `--uninstall`, `--dashboard`, `--last`. El texto sigue en español. **Si ya tenías la 1.1 con los nombres de antes** (`nucleo/`, `organos/`, `boveda/`…), desde este kit: `python3 install.py --migrate-names <tu carpeta>` (con candado, antes `--open`). Renombra con `git mv`, pone las rutas al día en tus notas, en tus hooks y en tu pre-commit, nunca borra y, si ya está migrado, dice «nada que migrar». El canario te lo pide en 🔴 si encuentra los nombres de antes.
- **La carga al arrancar** (D230): el canario dice qué parte de la ventana de contexto se lleva el núcleo al empezar («carga al arrancar: 3 % de 200k») y avisa en 🟡 sobre el 15 %. Si tu ventana es otra, una línea `window: 1000000` en `core/start.md`. Lo que cargas al empezar no pasa del 15 % de la ventana; el tope de notas es alarma, no tijera.
- **La cabina (*observability dashboard*) por misión** (`python3 organs/canary.py --dashboard`) y el **tope de cola** (*backlog growth alert*): los pendientes agrupados por misión, y un aviso 🟡 cuando la lista crece más rápido de lo que se cierra. Nació de una queja de los usuarios: las submisiones se abrían sin orden.
- **El canario ya no da verde falso al mudar la carpeta:** el guardián tiene que responder con su propio aviso, no solo con un código de salida.
- **El instalador compara los ganchos de antes y de después** (idea de un usuario: otro instalador le había desconectado uno sin avisar).
- **El buscador corta las líneas largas** a unos 200 caracteres, mostrando el tramo donde aparece lo buscado: gasta menos.
- **Probada en Windows 11 y en macOS reales**, y en Antigravity con el programa real.
- **Codex en código:** el instalador registra el guardián en `~/.codex/hooks.json` (sin pisar tus otros ganchos) y el guardián entiende las ediciones por parche de Codex. Falta aprobarlo una vez con `/hooks` dentro de Codex. Codex: el guardián en código entra en la 1.1, probado con Codex CLI real en Linux (frena el borrado por parche y la escritura en la jaula; deja pasar las ediciones normales); en modo interactivo la persona lo aprueba una vez con `/hooks`.

**En la 1.0.3 (1-nov-2026):** el guardián en dos modos (prosa por defecto), menos frenos de más (eran 55 en 8 días, 3 útiles), `organs/quarantine.py` avisa cuando deja un traslado preparado en git, y `organs/secret_scan.py` también frena un DNI de ejemplo (escribe «DNI <8 dígitos>»).

## Próximos parches
- El canario no ve una nota que miente sobre otra cosa que el estado, ni un dato viejo en `context.md` en un núcleo grande.
- En código, un enlace o un `cd` hacia `~/.claude`, `~/.codex` o `.git/hooks`, y algunas formas raras de shell, siguen pasando.
- En prosa, el canario ve lo que pasó (un borrado, un cambio en `organs/`), no lo que la IA leyó; y la regla «solo desde una terminal» la puede imitar un programa.
- Codex: el guardián en código entra en la 1.1, probado con Codex CLI real en Linux (frena el borrado por parche y la escritura en la jaula; deja pasar las ediciones normales); en modo interactivo la persona lo aprueba una vez con `/hooks`.

## Si el canario sale en rojo
Un 🔴 es un aviso, no una avería que tengas que entender. (1) Copia la salida entera del canario y pégasela a tu IA: «explícame qué significa y qué hago». (2) No le pidas que lo arregle sola: lo que toca la jaula lo cambias tú. (3) Si el rojo es del **guardián** («GUARDIÁN DESCONECTADO») o de **secretos** («falta el hook pre-commit»), no trabajes con permisos libres (los que no preguntan antes de cada acción) hasta arreglarlo. `python3 install.py --hook` repone el hook de secretos. (4) En prosa, si el canario dice que algo se borró o que `organs/` cambió, mira qué fue (git lo guarda) y decide: pasar a código (`--guardian on`) o seguir en prosa (`--guardian off`).

## El candado de la jaula (`organs/`)
En código, `organs/` queda con el candado de tu sistema. **Lo que vale cada uno, dicho sin adornos:** en Linux es un muro (solo se quita con tu clave); en Mac y en Windows es un seguro de puerta (lo quita el mismo usuario sin clave: frena el error, no la decisión). El guardián frena a la IA si usa esos comandos sobre la jaula (`chattr`, `chflags`, `attrib`) o toca `.git/hooks`. Cada arranque el canario dice **🔒 jaula con candado** o **🟡 jaula sin candado**. En prosa no hay candado: la cuida la huella.
Para reinstalar, anotar una carpeta en `denied.txt`, poner un chequeo en `checks.txt` o aplicar un parche: en código, `python3 install.py --open` (en Linux pide tu clave), haces el cambio y `python3 install.py --close`; en prosa, haces el cambio y `python3 install.py --guardian off`.

## Chequeos propios (`organs/checks.txt`)
De la prosa al órgano (*policy-as-code*): cuando un fallo se repite, se vuelve un chequeo. Una línea por chequeo, `nombre | comando | lo que debe decir`, con las tres partes; una línea con menos, el canario la marca 🔴 «mal escrita». Por ejemplo, en Mac y Linux `índice QGIS | test -f proyecto/indice.qgz && echo ok | ok`, y en Windows `índice QGIS | if exist proyecto\indice.qgz echo ok | ok`. El canario lo corre en cada arranque (10 segundos como máximo) y pinta 🔴 el que no diga lo esperado. Tu IA te propone la línea en el chat; la pones tú.

**Lo que el canario te recuerda (🟡, no frena):** que tu copia exista (si hace más de 7 días que nada entra a git, si no hay remoto o si lo local va adelante del remoto) y lo que solo tú haces (si `_QUARANTINE/` tiene algo de más de 30 días o pesa más de 500 MB, y si `denied.txt` sigue sin carpetas tuyas a la semana de instalar).

## La llave libre (`free.py`)
En código, si necesitas que la IA trabaje en una carpeta privada: en una terminal tuya, no en la de la IA, corre `python3 organs/free.py 30`. Te pide tu clave y abre la llave por 30 minutos; `python3 organs/free.py end` la cierra antes. Con llave o sin llave, **nada se borra** y **la jaula no se abre**. En Windows hay que abrir la terminal «como administrador» (todavía no está probado en una máquina Windows real). En prosa no hace falta: se lo dices a tu IA.

## Lo de todos los días
- **Al empezar:** tu IA corre el canario y te cuenta qué está urgente y qué venció.
- **Si la IA quiere borrar algo:** lo aparta en `_QUARANTINE/` (en código, el guardián la frena si intenta borrar). Esa carpeta la vacías tú cuando quieras.
- **Si git frena un commit** («el commit no entró»): leyó una llave, una contraseña o un DNI. Sácalo del archivo. Si es un falso positivo, el commit lo haces tú desde tu terminal con `git commit --no-verify`.
- **Prueba en frío:** cuando cambies de modelo o cada tanto, abre una conversación nueva, dale solo `core/` y hazle tres preguntas cuya respuesta ya sabes; si falla una, se corrige la nota, no se agrega una regla.
- **Para encontrar algo viejo:** «búscalo» → tu IA corre el buscador y te dice dónde buscó.
- **Para ver todo ordenado:** `python3 organs/canary.py --dashboard` muestra tus pendientes agrupados por misión, con lo vencido y lo próximo. El canario avisa en 🟡 si la cola crece (más de 40 pendientes, más entradas que cierres en la semana, más de 7 misiones abiertas, pendientes sin misión cuando ya tienes alguna misión —al empezar, cuando ninguno tiene misión, no avisa salvo que pasen de 15— o un `due:` con una fecha que no existe): avisa, no frena.
- **Al cerrar:** tu IA deja el estado al día, corre DAISY y hacen commit con firma. **Para ver los últimos frenos** (código): `python3 organs/guardian.py --last 5`.

## Lo que no hace (y qué lo cubre) — recomendaciones sinceras
- **Borrados por otro programa.** En código, el guardián lee el texto del comando y conoce `rm`, `find -delete`, `git clean`, `truncate`, `python -c` y los parches; no ve un borrado hecho por `perl`, `tar --remove-files`, `rsync --del`, `npx rimraf` ni un `git checkout`/`git restore` que pisa un archivo con la versión vieja (medido el 3-nov-2026). Git y las instantáneas del sistema son la red para eso.
- **Texto escondido.** En código, el guardián lee lo que la IA escribe en el comando, no lo que un programa hace por dentro: un borrado en una variable, en un script, con el programa entre comillas o con su ruta completa, con un comodín como `~/.s*` o en una herramienta MCP puede pasar. No hay aislamiento de contenedor. Por eso: **trabaja en carpetas con git o con instantáneas**, y mira tú el commit de cada día.
- **Lo que se dejó fuera.** El buscador puede leer una carpeta vedada (*deny-listed paths*) si se le pide; una búsqueda por terminal (`grep -r`, `find`) que recorra tu carpeta personal pasa; y en código los comandos de más de 10 000 caracteres se frenan (ponlos en un archivo).
- **Lo que `secret_scan.py` no ve.** Un DNI sin la palabra «DNI», una contraseña sin etiqueta, un secreto dentro de una imagen, un PDF o un paquete (`.tar.gz`, `.zip`: no los abre), y lo que ya estaba en git antes de instalar. Guarda los datos de tus clientes fuera de esta carpeta.
- **En prosa el canario detecta descuidos, no engaños.** La huella y el punto de partida viven en `.endo/guardian_modo.json`, sin candado: una IA que lo reescriba deja el canario en verde. Y da dos falsos positivos: mover **y** editar una nota chica sin git (git no la reconoce como la misma), y cambiar a una rama vieja de git que no tiene tus notas (compara con el último arranque, no con la rama; al volver, se va).
- **Un guardián por usuario, no por carpeta.** En código el guardián se registra para tu usuario: si tienes dos carpetas con kits distintos, las dos usan el guardián del último que pasaste a código.
- **Avisos de git en Windows.** El primer commit puede mostrar muchos avisos «LF will be replaced by CRLF»: son normales (git ajusta los finales de línea de Windows) y no son un error.
- **Vaciar o pisar un archivo.** Se cuida el borrado, no el pisado: lo anterior se recupera con git o con las instantáneas. Haz commit antes de pedirle cambios grandes.
- **Lo que no está en la lista.** Solo cuida `~/.ssh`, `~/.secretos` y lo que tú anotes en `organs/denied.txt`: anótalas (clientes, contabilidad, claves de otros programas).
- **Tildes.** El buscador busca letras, no palabras: «árbol» y «arbol» son distintas. Escribe las dos, separadas por `|`.
- **DAISY declara, no verifica.** Cuenta las firmas que llevan los commits; si alguien firma mal a propósito, DAISY le cree.
- **Mover o quitar la carpeta del núcleo.** El guardián (en código) y el hook de git guardan su ruta: si la mueves o la borras, la IA queda sin herramientas. Antes, en tu terminal: `python3 install.py --uninstall` (pide que escribas `quitar`) y luego cierra y abre tu IA. Si ya la moviste, córrelo en la carpeta nueva y reinstala.
- **Alcance de las pruebas.** Probada en Linux, en Windows 11 y en macOS (instalación, los siete órganos y los dos modos del guardián), con Claude Code y con Antigravity, y en uso diario por un grupo chico de personas. En Windows y Mac el candado lo puede quitar el mismo usuario. `free` como administrador en Windows: sin probar. Si algo te falla, cuéntanos qué pasó.

## Referencias
1. Giribaldi, M. (2026). *Simbiosis — Manual para un buen linaje*, v2.1. Zenodo. DOI 10.5281/zenodo.23934097 (concepto 10.5281/zenodo.23024311). Viene en el kit, en `symbiosis-manual/` (español e inglés): la IA lo lee entero la primera vez, antes de armar el núcleo, y después lo consulta; no se carga en cada arranque.
2. Giribaldi, M. (2026). *Corrupted memory, healthy components*. HAI '26. DOI 10.1145/3841580.3845736 (in press).
3. Ahmetoglu, Y., Constantinides, M., Cox, A. (2026). *AI Disclosure with DAISY*. arXiv:2604.02760.
4. Meniw, C. «Agentic Endosymbiosis» (uso previo del término en gobernanza de IA; sin relación con este kit).

## Glosario

### El sistema
| Palabra nuestra | Término técnico | Qué es, en una línea |
|---|---|---|
| núcleo | memoria de largo plazo externa (*long-term memory*) | las ocho notas que la IA lee enteras al empezar y deja al día al cerrar |
| el trato | política operativa (*operating policy*) | las reglas escritas, numeradas, que mandan sobre la IA |
| órgano | barandilla determinista (*deterministic guardrail*) con autoprueba | un programa chico que vigila una regla sin depender de la buena voluntad del modelo |
| jaula | archivos inmutables (*immutable files*, `chattr +i` en Linux; en Windows y Mac solo lectura) | `organs/` y los ganchos del programa: la IA los lee y los corre, nunca los cambia |
| huella | hash de integridad (*integrity hash*, SHA-256) | la firma de `organs/` que el canario compara en cada arranque |
| prosa / código | modo pasivo / modo *enforcing* | en prosa la IA cumple las reglas por su cuenta; en código un programa la frena antes |
| de la prosa al código | política como código (*policy-as-code*) | una regla que falló dos veces deja de pedirse por favor y se vuelve programa |
| bóveda | registro de solo anexar (*append-only log*) | lo cerrado baja ahí, una línea por cierre, y nunca se reescribe |
| diferido | pendiente con gatillo (*deferred item with trigger*) | lo que se decide no hacer ahora, con la fecha o la condición que lo despierta |
| cabina | panel de observabilidad (*observability dashboard*) | lo que el arranque dice, en pantalla |
| misión | línea de trabajo (*workstream*) | un frente con su plan; cada pendiente lleva la suya (`m:`) |

### Los órganos
| Palabra nuestra | Término técnico | Qué es, en una línea |
|---|---|---|
| guardián | gancho previo a la herramienta (*PreToolUse hook*), punto de aplicación de políticas (*policy enforcement point*) | revisa cada acción de la IA antes de que ocurra y la frena si rompe una regla |
| apartar (`python3 organs/quarantine.py`) | cuarentena (*quarantine*, *soft delete*) | lo que sobra va a `_QUARANTINE/` en vez de borrarse; la persona vacía a mano |
| canario | chequeo de integridad al arranque (*startup integrity check*) | pasa lista: pendientes perdidos, notas que mienten, diferidos vencidos, guardián vivo |
| prueba de vida | prueba sintética negativa (*negative synthetic test*; por analogía, *liveness probe*) | el canario manda acciones falsas que deben frenarse; si una pasa, el guardián está desconectado |
| falla sembrada | prueba de mutación (*mutation testing*) | cada autoprueba rompe su propio órgano a propósito y comprueba que lo detecta |
| filtro de secretos | gancho de pre-commit (*pre-commit hook*) con detección de secretos (*secret scanning*) | frena el commit si entra una llave, una contraseña etiquetada o un DNI |
| llave libre | acceso temporal justo a tiempo (*just-in-time access*) | la clave de la persona abre las carpetas vedadas por unos minutos; nunca el borrado ni la jaula |
| carpetas vedadas (`organs/denied.txt`) | rutas denegadas (*deny-listed paths*) | lo que ninguna IA lee ni escribe |
| buscador | búsqueda en el árbol de trabajo y en el historial de git (*working tree + git history search*) | antes de decir «no existe», busca en lo de hoy y en todo lo que alguna vez entró a git |
| DAISY | declaración de uso de IA (*AI disclosure*), medida desde git | cuenta quién hizo cada cambio según las firmas de git y frena el cierre si uno quedó sin firma; el nombre viene del paper DAISY (Ahmetoglu, Constantinides y Cox, 2026) |
| chequeos propios (`organs/checks.txt`) | comprobaciones de salud del usuario (*user-defined health checks*) | una línea por chequeo: comando y lo que debe decir; el canario lo corre al empezar |
| tope de cola | alarma de crecimiento de la cola (*backlog growth alert*) | aviso cuando la lista crece más rápido de lo que se cierra (40 por defecto: cámbialo si tu cola es otra) |

### La rutina
| Palabra nuestra | Término técnico | Qué es, en una línea |
|---|---|---|
| pasar lista | chequeo de arranque (*startup check*) | lo que el canario hace al empezar |
| el cierre | fin de sesión (*end-of-session*) | estado al día, decisiones con cita, DAISY, commit firmado |
| la firma del commit | tráiler de git (*git trailer*, `Co-Authored-By`) | cada commit dice qué modelo lo escribió o lleva `[humano]` |
| una cosa, un lugar | fuente única de verdad (*single source of truth*) | un hecho vive en una sola nota; las demás apuntan a ella |
| congelado | solo lectura, histórico (*read-only*) | una nota vieja que se conserva pero no se vuelve a editar |
| migrar | integración con memoria preexistente (*legacy memory integration*) | pasar lo que la persona ya tenía al núcleo sin crear dos fuentes de verdad |
| el veto humano asciende | escalamiento con persona en el bucle (*human-in-the-loop escalation*) | lo irreversible nunca se decide solo: sube a la persona |
| tres zonas 🟢🟡🔴 | permitir / preguntar / denegar (*allow / ask / deny*) | se hace y se cuenta · plan y sí · acción exacta, plan B escrito y la palabra reservada que elige cada persona (en el núcleo de Marco es «procedé») |
