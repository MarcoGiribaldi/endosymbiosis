# DECISIONS — el registro: decisiones y fallos, una línea cada uno

> Navegar: [[start]] · [[canary]] · [[state]] · [[profile]] · [[context]] · [[agreement]] · [[course]] · [[decisions]] · [[DEFERRED|diferidos]] · [[vault/INDEX|bóveda]]

> Solo crece; nunca se reescribe. Si dos líneas hablan de lo mismo, vale la más nueva.
> Forma: `- AAAA-MM-DD · DECISION|FAILURE · quién · qué · «las palabras de la persona»`

