# CONTEXT — el territorio: qué puede hacer cada uno y dónde

> Navegar: [[start]] · [[canary]] · [[state]] · [[profile]] · [[context]] · [[agreement]] · [[course]] · [[decisions]] · [[DEFERRED|diferidos]] · [[vault/INDEX|bóveda]]

> Las herramientas, las máquinas y quién hace qué. Si una medición dice otra cosa, manda la medición.

## HERRAMIENTAS
- IA principal: (por llenar: Antigravity, Claude Code, ChatGPT…)
- Otras IA para segundas opiniones: (por llenar)
- Programas del oficio: (por llenar: QGIS, HEC-RAS, Excel…)

## ÓRGANOS (en `organs/`, los cambia solo la persona; los siete órganos y su segunda puerta, `secret_scan.py`)
- **guardián** — las reglas 1 y 2 del trato (nada se borra y la jaula no se toca; secretos y datos de clientes, nunca). Dos modos: prosa (por defecto: escritas, sin frenar; el canario mira la huella de `organs/` y los borrados) o código (`python3 install.py --guardian on`: además frena). Vive si: el canario dice «✅ guardián vivo» (código) o «⚪ guardián en prosa» sin 🔴 (prosa); en código, `python3 organs/guardian.py --last 5` muestra sus frenos.
- **apartar** — en vez de borrar, mueve a `_QUARANTINE/<fecha>-<motivo>/`: `python3 organs/quarantine.py <ruta> <motivo>`. Vive si: `python3 organs/quarantine.py --selftest` termina sin falla.
- **libre** — tu llave: `python3 organs/free.py 30` abre las carpetas vedadas por 30 minutos (pide tu clave); la regla 1 (nada se borra y la jaula no se toca), nunca. Vive si: su `--selftest` termina sin falla.
- **canario** — pasa lista al empezar (pendientes, diferidos, carpeta correcta, prueba de vida del guardián, tus chequeos de `organs/checks.txt`, el candado de la jaula, la copia en git y lo que solo tú vacías). Vive si: su `--selftest` termina sin falla (y, en 🔴, avisa si falta el hook de secretos).
- **buscador** — busca en lo vivo y en todo el historial de git, y termina con un veredicto citable. Vive si: su `--selftest` termina sin falla.
- **DAISY** — quién hizo qué según git; frena el cierre si un commit quedó sin firma. Vive si: su `--selftest` termina sin falla. Si un commit quedó sin firma y ya no es el último, un commit firmado «atribuye <hash>: …» lo da por atribuido.
- **secretos** — la segunda puerta del guardián: git la llama antes de cada commit y lo frena si lleva una llave, una contraseña etiquetada o un DNI. Vive si: su `--selftest` termina sin falla y el canario no dice 🔴 por el hook de `pre-commit`.

## CARPETAS VEDADAS
> La lista NO vive aquí: vive en `organs/denied.txt`, en la jaula, para que la IA no pueda quitarle una carpeta. La escribe la persona a mano, una carpeta por línea (`~/.ssh` y `~/.secretos` ya vienen de fábrica). La IA la puede leer para saber dónde no entra.
