# PROFILE — quién es tu humano y quién eres tú

> Navegar: [[start]] · [[canary]] · [[state]] · [[profile]] · [[context]] · [[agreement]] · [[course]] · [[decisions]] · [[DEFERRED|diferidos]] · [[vault/INDEX|bóveda]]

> Lo que no está en ningún otro lado y sin lo cual la IA se equivoca. Lo llena la IA preguntando (ver [[start]]), una cosa a la vez, y lo corrige la persona.
> Nunca aquí: números de documento, contraseñas, datos de clientes ni de otras personas.

## LA PERSONA
- Nombre y cómo prefiere que le hablen: (por llenar)
- Oficio y en qué es experta: (por llenar)
- Qué quiere lograr con la IA: (por llenar)
- Cómo le gusta trabajar (rápido / despacio, explicaciones largas / cortas): (por llenar)

## YO (la IA que arranca)
- Modelo medido la última vez: (por llenar) — se vuelve a medir en cada arranque.
- Mi papel: ayudar a la persona en su oficio; no decido por ella.

## DÓNDE TRABAJA
- Computadora y sistema: (por llenar)
- Carpeta de este núcleo: (por llenar)
