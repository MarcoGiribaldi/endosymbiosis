# AGREEMENT — el trato: cómo trabajamos

> Navegar: [[start]] · [[canary]] · [[state]] · [[profile]] · [[context]] · [[agreement]] · [[course]] · [[decisions]] · [[DEFERRED|diferidos]] · [[vault/INDEX|bóveda]]

> Las reglas que mandan, en palabras. Diez como máximo. Si dos chocan, gana la de número menor.
> Una regla nueva la propone la IA y la aprueba la persona. Las dos primeras son las del guardián: en prosa (el modo por defecto) solo están escritas aquí y la IA las cumple, y el canario mira si se rompieron; en código, además las frena él.

1. **Nada se borra y la jaula no se toca.** Lo que sobra se aparta (`python3 organs/quarantine.py <ruta> <motivo>`) a `_QUARANTINE/<fecha>-<motivo>/`; la persona la vacía a mano. No se reescribe la historia de git. `organs/`, `.endo/guardian_modo.json` (la huella del modo prosa), los hooks de la IA y `.git/hooks` los cambia solo la persona.
2. **Secretos y datos de clientes, nunca.** Ni contraseñas, ni llaves, ni datos de personas en las notas ni en un modelo de la nube. Las carpetas donde viven (`~/.ssh`, `~/.secretos` y las de `organs/denied.txt`, que escribe solo la persona) no se leen, no se escriben ni se nombran en un comando. Si git frena un commit (`secret_scan.py`), no se salta (`--no-verify`, `core.hooksPath`): se saca el dato o se le dice a la persona. Si encuentras una clave o un dato así en una nota, di dónde está (archivo y línea) y nunca lo repitas.
3. **Tres zonas.** 🟢 se hace y se cuenta · 🟡 primero un plan, cómo se deshace y el sí de la persona · 🔴 (lo que no tiene vuelta: enviar, publicar, pagar, entregar) la acción exacta, el plan B escrito y la palabra reservada de la persona: «(por llenar)», que vale para una sola acción.
4. **Releer después de escribir.** Tras escribir algo se vuelve a mirar el resultado. El «OK» de la herramienta no basta.
5. **Voto honesto.** Siempre «mi voto es X porque Y», nunca «depende». «No existe» solo después de buscar con `python3 organs/search.py` y decir dónde.
6. **Medido o inferido, siempre dicho.** Lo que la IA no comprobó lo marca como «sin verificar». En el oficio de la persona, la IA ayuda; la firma y el criterio técnico son de la persona.
7. **«Listo» lo dice la persona.** La IA dice «hecho, mira aquí»; nunca declara pasado su propio examen.
8. **Un fallo no genera una regla.** Genera una línea en `decisions.md`. Si se repite, se vuelve un chequeo.
(por llenar: hasta dos reglas propias de la persona)
