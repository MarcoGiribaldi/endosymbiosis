# START — por dónde se empieza

> Navegar: [[start]] · [[canary]] · [[state]] · [[profile]] · [[context]] · [[agreement]] · [[course]] · [[decisions]] · [[DEFERRED|diferidos]] · [[vault/INDEX|bóveda]]

> La IA lee esto primero, cada vez. Después lee las otras siete notas enteras, en este orden, antes de hacer nada.

## LEER, siempre entero y en orden
1. [[canary]] — qué no puede faltar y qué no puede estar.
2. [[state]] — lo urgente, lo pendiente y en qué estamos.
3. [[profile]] — quién es tu humano y quién eres tú.
4. [[context]] — qué máquinas y herramientas hay, y qué puede hacer cada uno.
5. [[agreement]] — las reglas. Si dos chocan, gana la de número menor.
6. [[course]] — qué importa primero.
7. [[decisions]] — las últimas ~30 líneas: qué se decidió y qué falló.
8. Si existe `handover.md` (relevo entre modelos), se lee antes de operar. Si el modelo cambia a mitad de sesión, el que se va lo escribe antes de irse (qué está en curso, qué falló, dónde están las trampas) y el que llega vuelve al paso 1.

## QUIÉN SOY
Mira qué modelo eres de verdad (el que te dice tu programa, no el que diga una nota). Si `profile.md` dice otro, avísale a tu humano antes de trabajar.
Si encuentras un núcleo que no es de tu humano (prestado, copiado de otra persona), pregúntale antes de usarlo: las reglas de oficio se pueden aprender de otro; el perfil, el trato y las fechas, nunca.

## AL EMPEZAR
1. `python3 organs/canary.py` → si dice 🔴 (un pendiente perdido, una mentira en las notas, un diferido vencido, la carpeta equivocada, «GUARDIÁN DESCONECTADO» o, en prosa, un cambio en `organs/` o algo borrado fuera de `_QUARANTINE/`), se lo cuentas a tu humano antes que nada, con la recomendación del canario tal cual. Si muestra ⏳ gatillos, le preguntas si alguno ya se cumplió.
2. Lees el núcleo (arriba).
3. Le dices en 5 líneas: qué está urgente, qué espera su decisión, qué toca hoy. Y le preguntas por dónde arrancan.

## DURANTE
- Antes de decir «no existe», «nunca lo hablamos» o de construir algo nuevo: `python3 organs/search.py "palabra|sinónimo"` (busca en lo vivo y en todo el historial de git).
- Nada se borra: lo que sobra se aparta con `python3 organs/quarantine.py <ruta> <motivo>` (va a `_QUARANTINE/`; si estaba en git, su traslado va en un commit aparte). Las reglas del guardián (1 y 2 de [[agreement]]: nada se borra y la jaula no se toca; secretos y datos de clientes, nunca) las cumples aunque esté en prosa. Si el guardián te frena, no busques otro camino: díselo a tu humano. Lo mismo si git frena tu commit (`secret_scan.py` encontró una llave, una contraseña o un DNI): sácalo del archivo o díselo; nunca uses `--no-verify`.
- Lo que se decide no hacer ahora no se borra ni se deja suelto: va a [[DEFERRED]] con `until:` o `when:`.
- Lo decidido se anota en el momento en `decisions.md`, no al cerrar: una conversación cortada no pierde nada.
- Un pendiente nuevo entra con su misión (`m:<nombre>`, una de las del FOCUS). Una misión nueva la abre tu humano, no tú. Para verlo todo agrupado: `python3 organs/canary.py --dashboard`.

## AL CERRAR
1. [[state]] al día: lo que terminó sale de ahí y baja a [[vault/INDEX|la bóveda]] con `[CLOSED AAAA-MM-DD · done · evidence: <dónde se ve>]`.
2. Una línea en [[decisions]] por cada decisión o fallo del día, con las palabras de tu humano entre comillas.
3. Si una decisión del día cambió un dato que está en [[context]] (un precio, una herramienta, un proveedor), corrígelo en [[context]] ese mismo día: una nota vieja que nadie actualizó es la contaminación más común.
4. `python3 organs/daisy.py` → si dice 🔴, falta atribuir algún commit.
5. Commit. Si lo hiciste tú, el mensaje termina con `Co-Authored-By: <tu modelo> <noreply@...>`; si fue tu humano solo, lleva `[humano]`.
