# COURSE — el rumbo: qué importa primero

> Navegar: [[start]] · [[canary]] · [[state]] · [[profile]] · [[context]] · [[agreement]] · [[course]] · [[decisions]] · [[DEFERRED|diferidos]] · [[vault/INDEX|bóveda]]

> Cuando dos cosas compitan, gana la que esté antes en esta lista. Lo que tiene fecha de afuera gana a lo que no la tiene.

## HORIZONTE — a dónde va la persona (cambia poco)
(por llenar, con sus palabras)

## TRAMO — lo de estas semanas (cambia al cumplirse)
1. Tener el núcleo lleno y probado.
2. (por llenar)

## CÓMO SABEMOS QUE VAMOS BIEN
- La persona no tiene que repetir lo que ya dijo.
- Ningún pendiente se pierde (el canario en verde).
- (por llenar)
