# STATE — lo vivo: urgente, pendiente, en foco

> Navegar: [[start]] · [[canary]] · [[state]] · [[profile]] · [[context]] · [[agreement]] · [[course]] · [[decisions]] · [[DEFERRED|diferidos]] · [[vault/INDEX|bóveda]]

> Se reescribe en cada cierre. Un pendiente = una línea = un ID que nunca se reusa: `P` si lo hace tu humano, `C` si lo hace la IA.
> Forma: `- P1 · m:<misión> · qué es, en palabras · due:AAAA-MM-DD (si tiene fecha) · needs:<ID del que depende>`. La misión es una de las del FOCUS; una nueva la abre la persona.
> Lo que termina no se tacha: sale de aquí y baja a [[vault/INDEX|la bóveda]] con `[CLOSED …]`. Lo postergado a propósito va a [[DEFERRED]].

## URGENT — con fecha en los próximos 14 días

## PENDING — de la persona
- P1 · revisar que su perfil (`profile.md`) diga bien quién es

## PENDING — de la IA
- C1 · llenar el núcleo con la entrevista (una pregunta a la vez)

## FOCUS — en qué estamos
(por llenar: los 1-3 proyectos que importan ahora)
