# CANARY — el canario: lo que no puede faltar y lo que no puede estar

> Navegar: [[start]] · [[canary]] · [[state]] · [[profile]] · [[context]] · [[agreement]] · [[course]] · [[decisions]] · [[DEFERRED|diferidos]] · [[vault/INDEX|bóveda]]

> Se pasa lista al empezar (`python3 organs/canary.py` hace la parte que se puede contar). Si algo falla, se dice antes que nada y no se arregla solo: decide tu humano.

## LISTA 1 — TIENE QUE ESTAR (el olvido)
- Cada pendiente de ayer sigue en [[state]], bajó a la bóveda con `[CLOSED` o pasó a [[DEFERRED]]. (lo cuenta el canario)
- Ningún diferido vencido sin decir, y todos con `until:` o `when:`. (lo cuenta el canario)
- [[profile]] dice quién es tu humano, con sus palabras.
- El guardián está vivo («✅ guardián vivo», en código: frenó cuatro pruebas) o en prosa por elección («⚪ guardián en prosa»), y en prosa `organs/` sigue igual a su huella y nada se borró fuera de `_QUARANTINE/`. (lo cuenta el canario)
- (por llenar: lo que tu humano diga que nunca puede faltar)

## LISTA 2 — NO PUEDE ESTAR (la mentira)
- Tachaduras en [[state]]. (lo cuenta el canario)
- Un `[CLOSED` sin evidencia. (lo cuenta el canario)
- Un «listo» o «pasado» que escribió la IA sobre su propio trabajo: eso lo escribe tu humano.
- Datos de clientes, contraseñas o números de documento en cualquier nota.
