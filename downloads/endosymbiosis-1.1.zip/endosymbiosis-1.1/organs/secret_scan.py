#!/usr/bin/env python3
"""
secret_scan.py — Endosimbiosis v1 (1.0.3). La segunda puerta del guardián: antes de cada commit, git le pregunta qué va a entrar.

Qué hace. Corre como hook `pre-commit` de git (lo pone el instalador): mira SOLO las líneas que el commit agrega
(`git diff --cached -U0`), salta los archivos binarios y los muy grandes, y frena el commit (sale con 1) si encuentra:
  · una llave o token conocido (GitHub, Anthropic, OpenAI, Slack, AWS, Google, llave privada);
  · una contraseña etiquetada (`password: …`, `contraseña = …`, de 8 caracteres o más); desde la 1.1 también con un espacio
    en lugar de `:` o `=` (`contraseña …`) y en una frase con «es» («mi clave del banco es …», hasta 4 palabras entre medio),
    si el valor tiene 8 caracteres o más sin espacios y al menos una cifra (informe 47 de ARGOS, 3-nov-2026);
  · un DNI: la palabra DNI (o D.N.I.) y, a 12 caracteres o menos, 8 dígitos sueltos. Desde la 1.0.3 también los de ejemplo
    (el 24-oct entraron así a git): para un ejemplo se escribe «DNI <8 dígitos>». No cuenta 8 dígitos dentro de un código
    más largo (un hash), ni 9 o más seguidos, ni una fecha u hora con separadores.
No imprime el dato: dice el archivo, la línea y qué patrón. Si el propio script falla, también frena (falla cerrada).
Funciona con cualquier programa que haga el commit (Claude Code, Antigravity, Codex, tú a mano). El guardián frena a la IA
si intenta saltárselo (`--no-verify`, `core.hooksPath`, escribir en `.git/hooks`).
Si es un falso positivo, la persona hace el commit desde su terminal con `git commit --no-verify`; la IA no puede.

Qué cuida del trato: que una llave, una contraseña o un DNI no entren a git (regla de Marco, la innegociable).
Su límite: no ve un DNI sin la palabra «DNI», una contraseña sin etiqueta ni «es» (o más corta de 8, o sin cifra), un secreto dentro de una imagen, un PDF o un paquete
(.tar.gz, .zip: no los abre, son binarios), ni lo que entró a git antes de instalarlo. Para eso están las carpetas vedadas y guardar los datos de personas fuera de esta carpeta.
Cómo se prueba:  python3 organs/secret_scan.py --selftest
Uso:  (git lo llama solo) python3 -I -B organs/secret_scan.py --pre-commit   ·   a mano, sobre un repo: --pre-commit --root CARPETA
"""
import sys, os, re, subprocess, tempfile
from pathlib import Path

sys.dont_write_bytecode = True                          # con candado, organs/ no puede tener __pycache__

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

TOPE_ARCHIVO = 10 * 2**20                                 # de cada archivo se miran las líneas agregadas hasta 10 MB
TOPE_LINEA = 20000                                        # y de cada línea, sus primeros 20 000 caracteres
PATRONES = [                                              # (nombre, regex)
    ("llave de GitHub", r"gh[pousr]_[A-Za-z0-9]{36,}|github_pat_[A-Za-z0-9_]{22,}"),
    ("llave de Anthropic", r"sk-ant-[A-Za-z0-9_-]{20,}"),
    ("llave de OpenAI", r"sk-(?:proj-[A-Za-z0-9_-]{32,}|[A-Za-z0-9]{32,})"),
    ("token de Slack", r"xox[bp]-[A-Za-z0-9-]{10,}"),
    ("llave de AWS", r"AKIA[0-9A-Z]{16}"),
    ("llave de Google", r"AIza[0-9A-Za-z_-]{35}"),
    ("llave privada", r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    ("clave etiquetada", r"(?i)\b(?:clave|pin|password|contrase(?:ñ|n\u0303|n)a)\b[^:=\n]{0,40}[:=]\s*(?!\d{1,2}-[A-Za-z]{3}\b|\d{4}-\d{2}-\d{2})(?=[A-Za-z0-9._-]*\d)[A-Za-z0-9][A-Za-z0-9._-]{5,}(?![A-Za-z0-9._-])"),   # P4 (D227)
    ("contraseña etiquetada", r"(?i)\b(?:password|passwd|passphrase|contrase(?:ñ|n\u0303|n)a)\s*[:=]\s*[\"']?(?![<>(){}\[\]$])[^\s\"']{8,}"),
    ("contraseña etiquetada (pass, pwd)",                  # 1.0.3, prueba en Windows; con una cifra, y no una ruta ni una fecha
     r"(?i)\b(?:pass|pwd)\s*[:=]\s*[\"']?(?![<>(){}\[\]$/~\\])(?![A-Za-z]:[\\/])(?!\d{4}-\d{2}-\d{2})(?=[^\s\"']*\d)[^\s\"']{8,}"),
]
# 1.1 (informe 47 de ARGOS): la etiqueta con un espacio en lugar de `:`/`=`, o en una frase con «es». El valor: 8 o más sin espacios,
# con una cifra; no un marcador (<…>, $VAR, (…)), una ruta, una fecha, un conteo (12/12) ni una redirección (2>/dev/null)
_ETIQUETA = r"(?i)\b(?:password|passwd|passphrase|pass|pwd|clave|contrase(?:ñ|n\u0303|n)a)"
_VALOR = (r"[\"'«]?(?![<>(){}\[\]$/~\\])(?![A-Za-z]:[\\/])(?!\d{4}-\d{2}-\d{2})(?!\d{1,2}-[A-Za-z]{3}\b)(?!\d+/\d+(?![^\s\"'»]))"
          r"(?=[^\s\"'»<>|;&]*\d)[^\s\"'»<>|;&]{8,}")
PATRONES += [
    ("contraseña con espacio (sin «:» ni «=»)", _ETIQUETA + r"\s+" + _VALOR),
    ("contraseña en una frase («… es …»)", _ETIQUETA + r"\b(?:\s+[^\s:=]+){0,4}?\s+es\s+" + _VALOR),
]
DNI = re.compile(r"(?i)\bD\.?N\.?I\b\.?.{0,12}?(?<![0-9A-Za-z])\d{8}(?![0-9A-Za-z])")     # 1.0.3: D.N.I., los de ejemplo, no dentro de un hash


def hallazgos_de_linea(linea, patrones=None):
    """Los nombres de patrón que la línea cumple (vacía si está limpia). No devuelve el dato."""
    linea, res = linea[:TOPE_LINEA], []
    for nombre, rx in (PATRONES if patrones is None else patrones):
        if re.search(rx, linea):
            res.append(nombre)
    if DNI.search(linea):
        res.append("DNI (la palabra DNI y 8 dígitos; para un ejemplo escribe «DNI <8 dígitos>»)")
    return res


def revisar(lineas_diff, patrones=None):
    """Recorre la salida de `git diff -U0` y devuelve [(archivo, número de línea, patrón)] solo de las líneas agregadas."""
    archivo, n, binario, bytes_, res, avisos = "?", 0, False, 0, [], []
    for crudo in lineas_diff:
        l = crudo.rstrip("\n")
        if l.startswith("diff --git "):
            archivo, n, binario, bytes_ = "?", 0, False, 0
        elif l.startswith("Binary files ") or l.startswith("GIT binary patch"):
            binario = True
        elif l.startswith("+++ "):
            archivo = l[4:].split("\t")[0]
            archivo = archivo[2:] if archivo[:2] == "b/" else archivo
        elif l.startswith("@@"):
            m = re.search(r"\+(\d+)", l)
            n = int(m.group(1)) - 1 if m else 0
        elif l[:1] == "+" and not binario:
            n += 1
            bytes_ += len(l)
            if bytes_ > TOPE_ARCHIVO:
                if not avisos or avisos[-1] != archivo:
                    avisos.append(archivo)
                continue
            if "\x00" in l:
                binario = True
                continue
            for nombre in hallazgos_de_linea(l[1:], patrones):
                res.append((archivo, n, nombre))
    return res, avisos


def diff_preparado(raiz):
    """La salida de `git diff --cached -U0` del repositorio (o de la copia temporal que usa git commit -a). Falla si git falla."""
    r = subprocess.run(["git", "-C", str(raiz), "-c", "core.quotepath=off", "-c", "color.ui=never", "diff", "--cached", "-U0", "--no-color",
                        "--no-ext-diff", "--no-textconv", "--src-prefix=a/", "--dst-prefix=b/", "--diff-filter=ACMR"],
                       capture_output=True, timeout=120)
    if r.returncode != 0:
        raise RuntimeError("git diff --cached falló: " + r.stderr.decode("utf-8", "replace")[:200])
    return r.stdout.decode("utf-8", "replace").splitlines()


def pre_commit(raiz, patrones=None):
    """Devuelve 0 si el commit puede seguir y 1 si se frena. Cualquier fallo propio frena."""
    try:
        hallazgos, avisos = revisar(diff_preparado(raiz), patrones)
    except Exception as e:
        print(f"🔴 el commit no entró: el revisor de secretos falló ({e!r}). Por seguridad, frena.\n"
              "   Avísale a tu IA o a quien te pasó el kit. Si tienes que guardar ya, hazlo tú desde tu terminal con git commit --no-verify.", file=sys.stderr)
        return 1
    for a in avisos:
        print(f"🟡 {a}: es muy grande; revisé solo sus primeros {TOPE_ARCHIVO // 2**20} MB de líneas agregadas.", file=sys.stderr)
    if not hallazgos:
        return 0
    print("🔴 el commit no entró: parece que llevaría un dato que no debe ir a git.", file=sys.stderr)
    for archivo, n, nombre in hallazgos[:10]:
        print(f"   · {archivo}, línea {n}: {nombre}", file=sys.stderr)
    if len(hallazgos) > 10:
        print(f"   · … y {len(hallazgos) - 10} más", file=sys.stderr)
    print("   No imprimo el dato. Si es real, sácalo del archivo (los secretos y los datos de personas no entran a git).\n"
          "   Si es un ejemplo o un falso positivo, la persona puede hacer el commit desde su terminal con git commit --no-verify\n"
          "   (la IA no puede saltarse esta revisión).", file=sys.stderr)
    return 1


# ---------------------------------------------------------------------------------------------------------------------
# Las pruebas. Los datos de prueba se arman aquí, en memoria y partidos: este archivo no lleva ninguna llave ni DNI escritos.
GHP = "gh" + "p_" + "A1b2C3d4E5f6G7h8I9j0K1l2M3n4O5p6Q7r8"
DNI_REAL = "DN" + "I " + "4" + "0123456"
CLAVE = "pass" + "word: " + "Zx9Kq2Lm7Pw"


def _en_diff(texto, archivo="nota.md"):
    return ["diff --git a/%s b/%s" % (archivo, archivo), "+++ b/" + archivo, "@@ -0,0 +1,%d @@" % len(texto.splitlines())] + ["+" + l for l in texto.splitlines()]


def casos_de_texto():
    """El revisor, en el mismo proceso: qué líneas frena y cuáles deja pasar. Devuelve la lista de fallas."""
    fallas = []
    frenan = {"llave de GitHub": GHP, "llave de GitHub (pat)": "github_pat_" + "A" * 30, "llave de Anthropic": "sk-" + "ant-" + "abcdefghij0123456789xyz",
              "llave de OpenAI": "sk-" + "a1B2c3D4" * 5, "llave de OpenAI (proj)": "sk-" + "proj-" + "a1B2_c3D4-" * 4,"token de Slack": "xo" + "xb-" + "1234567890-abcdefghij", "llave de AWS": "AK" + "IA" + "ABCDEFGHIJKLMNOP",
              "llave de Google": "AI" + "za" + "A" * 35, "llave privada": "-----BEGIN " + "RSA PRIVATE KEY-----", "DNI con su palabra": "Cliente: " + DNI_REAL,
              "DNI en minúsculas": "el d" + "ni es 4" + "0123456", "contraseña etiquetada": CLAVE, "contraseña en español": "contra" + "seña = " + "Hunter2Hunter2",
              "contraseña entre comillas": "pass" + 'word="' + "Zx9Kq2Lm7Pw" + '"',
              "contraseña con un paréntesis adentro": "pass" + "word=Abc(1234xyz",
              "1.0.2 · clave del banco": "cla" + "ve de la banca por internet: " + "4471" + "-0098",
              "1.0.2 · pin largo": "pi" + "n del celular: " + "9988" + "7766",
              "1.0.3 · DNI de ejemplo (057e328e: entró a git)": "DN" + "I 12345678", "1.0.3 · DNI trivial": "DN" + "I: " + "0" * 8,
              "1.0.3 · D.N.I. con puntos": "D.N" + ".I. N° 4" + "0123456", "1.0.3 · DNI con dígito verificador": "DN" + "I 4" + "0123456-7",
              "1.0.3 · contrasena sin ñ (Windows)": "contra" + "sena: " + "1234abcd", "1.0.3 · CONTRASEÑA en mayúsculas": "CONTRA" + "SEÑA = " + "Hunter2Hunter2",
              "1.0.3 · contraseña con tilde combinada": "contrase" + "n\u0303a: " + "Zx9Kq2Lm7Pw", "1.0.3 · pass: con cifra": "pa" + "ss: " + "Zx9Kq2Lm7Pw",
              "1.0.3 · pwd=": "pw" + "d=" + "Hunter2Hunter2",
              "1.1 · contraseña: (ARGOS 47)": "contra" + "seña: " + "Prueba1234x", "1.1 · password = (ARGOS 47)": "pass" + "word = " + "Abcdef1234",
              "1.1 · contraseña con espacio (ARGOS 47)": "contra" + "seña " + "Prueba1234x",
              "1.1 · en una lista (ARGOS 47)": "- wifi del taller: contra" + "seña " + "Prueba1234x",
              "1.1 · clave del banco es (ARGOS 47)": "mi cla" + "ve del banco es " + "1234" + "5678",
              "1.1 · password con espacio": "pass" + "word " + "Abcdef1234", "1.1 · pwd con espacio": "pw" + "d " + "Hunter2Hunter2",
              "1.1 · contrasena sin ñ, con espacio": "contra" + "sena " + "1234abcd", "1.1 · passphrase:": "pass" + "phrase: " + "Abcdef1234",
              "1.1 · es, entre comillas": "la contra" + "seña del router es «" + "Zx9Kq2Lm7Pw" + "»"}
    pasan = {"número de pedido": "pedido 30528833", "fecha pegada": "fecha 20261024", "sin cifra": "la palabra DNI sola",
             "contraseña por llenar": "pass" + "word: (por llenar)", "contraseña de plantilla": "contra" + "seña: <tu clave>", "valor corto": "pass" + "word = None", "contraseña como variable": "pass" + "word: $DB_PASSWORD_VALOR",
             "1.0.2 · la clave como idea": "la cla" + "ve del éxito: trabajar duro", "1.0.2 · una fecha": "la cla" + "ve fue: 27-oct",
             "ocho dígitos lejos del DNI": "DN" + "I pendiente. " + "x" * 20 + " pedido 40123456", "llave corta": "gh" + "p_abc", "prosa": "la contraseña se guarda aparte",
             "1.0.3 · hash junto a DNI": "DN" + "I sha:9f" + "40123456" + "c1", "1.0.3 · hora junto a DNI": "DN" + "I 12:30:45 · 08:00",
             "1.0.3 · fecha con guiones junto a DNI": "DN" + "I vence 2027-03-15", "1.0.3 · nueve dígitos junto a DNI": "DN" + "I y cel. 9" + "87654321",
             "1.0.3 · ADN no es DNI": "AD" + "NI 4" + "0123456", "1.0.3 · placeholder": "DN" + "I <8 dígitos>",
             "1.0.3 · pwd con una ruta": "pw" + "d: /home/rosa/proyecto2", "1.0.3 · pwd con una ruta de Windows": "pw" + "d: C:\\Users\\rosa\\nucleo2",
             "1.0.3 · pass: palabra sin cifra": "pa" + "ss: completed", "1.0.3 · pass: una fecha": "pa" + "ss: 2026-11-01",
             "1.0.3 · bypass no es pass": "byp" + "ass: " + "Zx9Kq2Lm7Pw", "1.0.3 · pass: resultado corto": "pa" + "ss: 12/12 casos",
             "1.1 · la elijo yo (ARGOS 47)": "la contra" + "seña nueva la elijo yo", "1.1 · del wifi mañana (ARGOS 47)": "cambiar la contra" + "seña del wifi mañana",
             "1.1 · policy (ARGOS 47)": "pass" + "word policy: 12 chars minimum", "1.1 · la regla 3 (ARGOS 47)": "la cla" + "ve es la regla 3",
             "1.1 · es, corta": "mi cla" + "ve es 1234", "1.1 · es, una fecha": "la cla" + "ve es 2026-11-03",
             "1.1 · es, una idea": "la cla" + "ve del éxito es trabajar duro", "1.1 · es, una ruta": "mi contra" + "seña ahora es /home/rosa/x2",
             "1.1 · espacio, plantilla": "contra" + "seña <tu-clave-2>", "1.1 · espacio, variable": "cla" + "ve $CLAVE_DB_2",
             "1.1 · pwd con redirección": "pw" + "d 2>/dev/null", "1.1 · pass con un conteo": "the tests pa" + "ss 1000/1000",
             "1.1 · bypass con espacio": "byp" + "ass " + "Zx9Kq2Lm7Pw"}
    for nombre, texto in frenan.items():
        r = revisar(_en_diff(texto))[0]
        if not r:
            fallas.append(f"debía frenar y pasó: {nombre}")
        elif any(x in str(r) for x in (GHP, "40123456", "Zx9Kq2Lm7Pw", "4471-0098", "Prueba1234x", "12345678", "Abcdef1234")):
            fallas.append(f"imprimió el dato: {nombre}")
    for nombre, texto in pasan.items():
        if revisar(_en_diff(texto))[0]:
            fallas.append(f"debía pasar y frenó: {nombre}")
    quitada = ["diff --git a/v.md b/v.md", "+++ b/v.md", "@@ -1 +1 @@", "-" + GHP, "+limpio"]
    if revisar(quitada)[0]:
        fallas.append("una línea quitada con una llave frenó (solo debe mirar lo que entra)")
    if revisar(["diff --git a/f.png b/f.png", "Binary files /dev/null and b/f.png differ"])[0]:
        fallas.append("un binario frenó")
    propio = Path(__file__).read_text(encoding="utf-8")                  # este archivo se commitea en tu repo: no puede frenarse a sí mismo
    if revisar(_en_diff(propio, "secret_scan.py"))[0]:
        fallas.append(f"secret_scan.py frena su propio texto: {revisar(_en_diff(propio, 'secret_scan.py'))[0][:3]}")
    r = revisar(_en_diff("a\nb\n" + GHP + "\n"))[0]
    if r != [("nota.md", 3, "llave de GitHub")]:
        fallas.append(f"el archivo y la línea no son los esperados: {r}")
    casos_de_texto.n = len(frenan) + len(pasan) + 4                                  # 1.0.3: cuántos casos, para ver que no se pierde ninguno
    return fallas


def _repo_temporal():
    d = Path(tempfile.mkdtemp(prefix="secretos_"))
    ok = subprocess.run(["git", "init", "-q", str(d)], capture_output=True).returncode == 0
    return d if ok else None


def _git(d, *a):
    return subprocess.run(["git", "-C", str(d), "-c", "user.name=p", "-c", "user.email=p@p", "-c", "commit.gpgsign=false", *a],
                          capture_output=True, text=True, encoding="utf-8", errors="replace")


def _paquete(tipo):
    """Un .tar.gz o un .zip con una llave adentro, armado en memoria (para el límite: no lee dentro de paquetes)."""
    import io, tarfile, zipfile
    b, dato = io.BytesIO(), ("mi clave " + GHP + "\n").encode()
    if tipo == "zip":
        with zipfile.ZipFile(b, "w", zipfile.ZIP_STORED) as z:
            z.writestr("nota.md", dato)
    else:
        with tarfile.open(fileobj=b, mode="w:gz") as tf:
            info = tarfile.TarInfo("nota.md")
            info.size = len(dato)
            tf.addfile(info, io.BytesIO(dato))
    return b.getvalue()


def hook_de_punta_a_punta():
    """Con el hook de verdad puesto en un repositorio temporal y git commit de verdad. Devuelve la lista de fallas."""
    d = _repo_temporal()
    if d is None:
        return ["no hay git: no se puede probar el hook"]
    hook = d / ".git" / "hooks" / "pre-commit"
    hook.write_text('#!/bin/sh\nexec "%s" -I -B "%s" --pre-commit\n' % (sys.executable, Path(__file__).resolve()), encoding="utf-8")
    hook.chmod(0o755)
    fallas, cuenta = [], [4]                                                             # (los 4 casos de abajo, sin commit())
    def commit(nombre, contenido, debe_pasar, binario=False):
        cuenta[0] += 1
        p = d / nombre
        p.write_bytes(contenido) if binario else p.write_text(contenido, encoding="utf-8")
        _git(d, "add", "-A")
        r = _git(d, "commit", "-qm", "prueba " + nombre)
        if (r.returncode == 0) != debe_pasar:
            fallas.append(f"{nombre}: {'debía pasar y frenó' if debe_pasar else 'debía frenar y pasó'} (rc {r.returncode})")
        if not debe_pasar:
            if "no entró" not in r.stderr or "--no-verify" not in r.stderr or any(x in r.stderr for x in (GHP, "40123456")):
                fallas.append(f"{nombre}: el mensaje no es el esperado: {r.stderr[:120]!r}")
            _git(d, "reset", "-q")
            p.write_text("vacío\n", encoding="utf-8")                                 # (nada se borra: se neutraliza el archivo)
    commit("normal.md", "hola\n", True)
    commit("token.md", "mi clave de GitHub es " + GHP + "\n", False)
    commit("dni.md", DNI_REAL + "\n", False)
    commit("foto.png", b"\x89PNG\x00\x00" + GHP.encode(), True, binario=True)           # un binario no se mira
    commit("enorme.txt", ("x" * 99 + "\n") * 110000 + GHP + "\n", True)                   # pasado el tope por archivo, no se mira (y avisa)
    commit("larga.txt", GHP + " " + "y" * 30000 + "\n", False)
    commit("paquete.tar.gz", _paquete("tar.gz"), True, binario=True)                      # 1.0.3: no abre paquetes (límite escrito)
    commit("paquete.zip", _paquete("zip"), True, binario=True)
    (d / "viejo.md").write_text(GHP + "\n", encoding="utf-8"); _git(d, "add", "-A"); _git(d, "commit", "-qm", "ya estaba", "--no-verify")
    (d / "viejo.md").write_text("limpio\n", encoding="utf-8"); _git(d, "add", "-A")
    if _git(d, "commit", "-qm", "se quitó").returncode != 0:
        fallas.append("quitar una llave que ya estaba frenó el commit (solo debe mirar lo que entra)")
    (d / "c.md").write_text(GHP + "\n", encoding="utf-8")
    if _git(d, "commit", "-aqm", "con -a (c.md sin preparar)").returncode == 0 and "c.md" in _git(d, "ls-files").stdout:
        fallas.append("git commit -a dejó pasar una llave")
    (d / "d.md").write_text(GHP + "\n", encoding="utf-8"); _git(d, "add", "d.md")
    if _git(d, "commit", "-qm", "solo la ruta", "--", "d.md").returncode == 0:
        fallas.append("git commit -- ruta dejó pasar una llave")
    fuera = Path(tempfile.mkdtemp(prefix="secretos_fuera_"))                              # falla cerrada: sin repositorio, el revisor frena
    r = subprocess.run([sys.executable, "-I", "-B", str(Path(__file__).resolve()), "--pre-commit"], cwd=str(fuera), capture_output=True, text=True,
                       env={**os.environ, "GIT_DIR": str(fuera / "no_existe")})
    if r.returncode != 1 or "frena" not in r.stderr:
        fallas.append(f"falla cerrada: sin repositorio debía frenar y salió rc {r.returncode}")
    hook_de_punta_a_punta.n = cuenta[0]
    return fallas


def selftest():
    global PATRONES, DNI
    f1, f2 = casos_de_texto(), hook_de_punta_a_punta()
    for f in f1 + f2:
        print(f"  FALLA: {f}")
    n = len(f1) + len(f2)
    total = getattr(casos_de_texto, "n", 0) + getattr(hook_de_punta_a_punta, "n", 0)
    print(f"secretos: {'todos los casos bien' if not n else str(n) + ' falla(s)'}, {total - n}/{total} (llaves, DNI, contraseñas; lo que debe pasar; solo lo que entra; binarios; tope; falla cerrada; git commit de verdad con el hook)")
    guardado, guardado_dni = PATRONES, DNI
    PATRONES, DNI = [], re.compile(r"(?!)")                       # falla sembrada: el revisor «olvida» todos los patrones
    atrapada = len(casos_de_texto()) > 0
    PATRONES, DNI = guardado, guardado_dni
    print(f"  falla sembrada (sin patrones, no ve nada): {'✅ atrapada' if atrapada else '🔴 NO atrapada: los casos no sirven'}")
    return 0 if not n and atrapada else 1


def main(argv):
    if "--selftest" in argv:
        return selftest()
    if "--pre-commit" in argv:
        try:
            return pre_commit(Path(argv[argv.index("--root") + 1]) if "--root" in argv else Path.cwd())
        except Exception as e:
            print(f"🔴 el commit no entró: el revisor de secretos falló ({e!r}). Por seguridad, frena.", file=sys.stderr)
            return 1
    print("uso: secret_scan.py --pre-commit [--root CARPETA]  ·  secret_scan.py --selftest", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
