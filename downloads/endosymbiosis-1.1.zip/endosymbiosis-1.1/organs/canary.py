#!/usr/bin/env python3
"""
canary.py — Endosimbiosis v1 (1.1 candidata). Pasa lista al empezar cada sesión. Uno solo para todas las versiones.

Una memoria falla de dos maneras: olvida y miente. El canario lo cuenta; nunca arregla nada solo.
  LISTA 1, el olvido: faltan notas del núcleo; un pendiente (P, C o H con número) que estaba en core/state.md en el
           último commit ya no está, ni con ✔ en DONE, ni con [CLOSED] en vault/ o decisions.md, ni en diferidos;
           un diferido (DEF-n) que desapareció.
  LISTA 2, la mentira: tachaduras (~~, «ya no vale»); un [CLOSED sin evidence:/reason:; una segunda marca de cierre
           ([CERRADO, [DONE:); un ID repetido; un ID citado (needs:, items:, URGENT) que no está vivo; «ver P<n>»;
           un due: vencido sin OVERDUE; un ID vivo que ya está cerrado; un número de ID ya usado (si state.md lleva
           «siguiente ID libre»); más de diez reglas en el trato; un posible secreto en el núcleo.
  DIFERIDOS (plans/DEFERRED_INDEX.md o plans/DEFERRED.md): until: vencido o sin until:/when: → 🔴; when: → ⏳.
  CARPETA: si la IA se abrió fuera de la carpeta del núcleo → 🔴 (el guardián no vigilaría donde trabaja).
  CHEQUEOS PROPIOS (organs/checks.txt, jaula): `nombre | comando | lo que debe decir`; el que no lo dice → 🔴.
  SECRETOS: 🔴 si el hook pre-commit de git (la segunda puerta del guardián, organs/secret_scan.py) no está puesto o no es ejecutable:
           sin él, una llave, una contraseña o un DNI puede entrar a un commit. Arreglo: python3 install.py --hook.
  EL MURO: 🔒 si organs/ tiene candado del sistema (lsattr / ls -lO / attrib), 🟡 si no; 🟡 si hace más de 7 días que
           nada entra a git, si no hay remoto o si lo local va adelante del remoto.
  RECORDATORIOS: 🟡 si _QUARANTINE/ tiene algo de más de 30 días o pesa más de 500 MB (lo vacías tú), y si denied.txt
           sigue sin carpetas propias a los 7 días del primer commit.
  PRUEBA DE VIDA: le manda al guardián registrado (organs/guardian.py, o manos_guardia.py mientras conviven) cuatro
           eventos falsos (rm desde el home, rm desde el espacio, leer ~/.ssh y, en Claude Code, escribir en organs/
           por ruta relativa); si alguno pasa → 🔴 GUARDIÁN DESCONECTADO y sale con error.
  MODO PROSA (1.0.3, elegido al instalar o con install.py --guardian off; queda en .endo/guardian_modo.json): el guardián
           no está registrado y no frena; el canario dice «⚪ guardián en prosa (elegido)» y mira dos cosas: que organs/
           siga igual a su huella (sha256 de cada archivo, tomada por install.py) y que nada que estaba en git en el
           arranque anterior haya desaparecido sin pasar por _QUARANTINE/ (quarantine.py mueve con git mv: eso no es borrar; mover
           a otra carpeta tampoco). Si encuentra algo → 🔴 y recomienda activar el guardián en código, en ese arranque y en
           los siguientes mientras siga; `install.py --guardian off` otra vez es «lo vi, sigo en prosa» (huella y punto
           de partida nuevos). Lo corre la persona en su terminal.
NOMBRES VIEJOS (D230): si encuentra nucleo/ sin core/ (u organos/ sin organs/) → 🔴 «corre python3 install.py --migrate-names»
           y no sigue con el resto (con esos nombres no vería nada).
CARGA AL ARRANCAR (D230): los bytes de las 8 notas + vault/INDEX.md + los diferidos, / 4, como % de la ventana (200 000 tokens;
           otra con una línea «window: N» en core/start.md). Siempre lo dice; 🟡 sobre el 15 % (Marco: «el máximo permitido es 15 %»).
CABINA Y COLA (1.1): `--dashboard` muestra los pendientes agrupados por misión (m:<nombre>), con vencidos, el más viejo y el
           próximo; en cada arranque, 🟡 si la cola pasa de 40, si entraron más de los que se cerraron en la semana (≥3), si
           hay más de 7 misiones abiertas, pendientes sin misión cuando ya hay alguna misión (o más de 15 sueltos), una
           misión con más de 10, o un due: con una fecha que no existe. Avisa, no frena.
Lee los dos formatos: el de la Lite (`- P1 · …`, cierres en vault/ o decisions.md, DEFERRED.md) y el de Marco
(`- P1 · m:… ·`, ✔ en DONE, vault/closed/, DEFERRED_INDEX.md).

Qué cuida del trato: que ningún pendiente se pierda y que las notas no mientan (regla de cierre de start.md).
Su límite: cuenta lo que se puede contar con texto y git; «listo» lo sigue diciendo la persona. Sin git, la lista 1
dice ⚪, nunca ✅.
Cómo se prueba: python3 organs/canary.py --selftest   ·   uso: python3 organs/canary.py [--root CARPETA] [--no-life-test]
"""
import sys, os, re, json, hashlib, subprocess, tempfile, datetime
from pathlib import Path

sys.dont_write_bytecode = True                          # con candado, organs/ no puede tener __pycache__

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

AQUI = Path(__file__).resolve().parent
PY = "python" if os.name == "nt" else "python3"          # 1.0.3, prueba en Windows: el comando como lo escribe esta persona
NOTAS = ["start", "canary", "state", "profile", "context", "agreement", "course", "decisions"]
ID = r"[PCH]\d{1,4}"
LINEA_ID = re.compile(r"^\s*(?:[-*]|\d+[.)])\s*(?:\[[ xX]\]\s*)?\**(" + ID + r")\b")
LINEA_DEF = re.compile(r"^\s*[-*]\s*\**(DEF-\d{1,4})\b(.*)$")
TACHADO = re.compile(r"~~|dejó de valer|invalidado D|ya no vale")
SECRETO = re.compile(r"(sk-[A-Za-z0-9]{10,}|ghp_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{12,}|-----BEGIN .*PRIVATE KEY)")
VIEJOS = {"nucleo": "core", "organos": "organs"}       # D230: los nombres de antes; los migra `install.py --migrate-names`
VENTANA = 200_000                                        # D230: tokens de la ventana de contexto, por defecto (otra: «window: N» en core/start.md)
TOPE_CARGA = 15                                          # D230 (Marco): «el máximo permitido es 15 %» de la ventana al arrancar
MODO = Path(".endo") / "guardian_modo.json"          # 1.0.3: el modo del guardián, la huella de organs/ y el punto de partida (fuera de organs/)


def leer(p):
    try:
        return Path(p).read_text(encoding="utf-8-sig", errors="replace")
    except OSError:
        return ""


def git(raiz, *args):
    try:
        r = subprocess.run(["git", "-C", str(raiz), *args], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30)
        return r.returncode, r.stdout
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return 127, ""


def sin_citas(l):
    """Nombrar una marca entre `…` o «…» no es usarla."""
    return re.sub(r"`[^`]*`|«[^»]*»", "", l)


def ids(texto):
    return [m.group(1) for m in map(LINEA_ID.match, texto.splitlines()) if m]


def seccion(texto, prefijo):
    dentro, res = False, []
    for n, l in enumerate(texto.splitlines(), 1):
        if l.startswith("## "):
            dentro = l[3:].startswith(prefijo)
        elif dentro:
            res.append((n, l))
    return res


# 1.1 · la cabina: los pendientes agrupados por misión, y el tope de cola (crear es gratis; cerrar cuesta)
TOPE_COLA = 40                                           # más pendientes vivos que esto → 🟡
TOPE_MISION = 10                                         # una misión con más que esto → 🟡 «¿la partimos en un plan?»
TOPE_MISIONES = 7                                        # más misiones abiertas que esto → 🟡 «júntalas»: submisiones que se abren solas
MISION = re.compile(r"\bm:([^\s·]+)")
DUE = re.compile(r"\bdue:(\d{4}-\d{2}-\d{2})")
DIAS = ["lun", "mar", "mié", "jue", "vie", "sáb", "dom"]
MESES = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"]


def pendientes(texto):
    """Los pendientes vivos del estado: (id, misión o None, due o None, qué es). DONE y FOCUS no cuentan."""
    res, aparte = [], False
    for l in texto.splitlines():
        if l.startswith("## "):
            aparte = l[3:].strip().upper().startswith(("DONE", "FOCUS"))
            continue
        m = None if aparte else LINEA_ID.match(l)
        if not m:
            continue
        mi, du = MISION.search(l), DUE.search(l)
        que = re.sub(r"\b(m|due|needs|waiting|until|when):[^\s·]*", "", l[m.end():])
        que = re.sub(r"\s*·(\s*·)+", " ·", que).strip(" ·*")
        que = next((t.strip(" *") for t in que.split(" · ") if t.strip() and not t.strip().startswith("(")), que) or "(sin texto)"   # qué es, sin notas entre paréntesis
        res.append((m.group(1), mi.group(1) if mi else None, du.group(1) if du else None, que))
    return res


def nacimientos(raiz):
    """La primera fecha en que cada ID entró al estado, según git (una sola pasada por la historia)."""
    rc, out = git(raiz, "log", "-p", "--follow", "--reverse", "--format=#FECHA %ad", "--date=short", "-U0", "--", "core/state.md")
    nac, fecha = {}, None
    for l in out.splitlines() if rc == 0 else []:
        if l.startswith("#FECHA "):
            fecha = l[7:].strip()
        elif l.startswith("+") and not l.startswith("+++"):
            m = LINEA_ID.match(l[1:])
            if m and fecha and m.group(1) not in nac:
                nac[m.group(1)] = fecha
    return nac


def cola(raiz, hoy, dias=7):
    """Cuántos pendientes entraron y cuántos salieron en los últimos `dias`, comparando con el estado de entonces."""
    corte = (hoy - datetime.timedelta(days=dias)).isoformat() + " 23:59"
    rc, viejo = git(raiz, "rev-list", "-1", f"--before={corte}", "HEAD")
    if rc or not viejo.strip():
        return None
    rc, antes = git(raiz, "show", f"{viejo.strip()}:./core/state.md")    # ./: el núcleo puede vivir en una subcarpeta del repo
    if rc:
        return None
    a = {p[0] for p in pendientes(antes)}
    b = {p[0] for p in pendientes(leer(Path(raiz) / "core" / "state.md"))}
    return len(b - a), len(a - b)


def fecha_valida(iso):
    """¿El due: es una fecha que existe? (2026-13-01 o 2026-11-31 tienen la forma, pero no existen: Fable 1.1 H2)"""
    try:
        datetime.date.fromisoformat(iso)
        return True
    except ValueError:
        return False


def fecha_corta(iso):
    if not fecha_valida(iso):
        return f"{iso}, mal escrita"
    d = datetime.date.fromisoformat(iso)
    return f"{DIAS[d.weekday()]} {d.day}-{MESES[d.month - 1]}"


def avisos_cola(raiz, hoy=None, pend=None, c=None):
    """El tope de cola: avisa (🟡), nunca frena."""
    hoy = hoy or datetime.date.today()
    pend = pendientes(leer(Path(raiz) / "core" / "state.md")) if pend is None else pend
    c = cola(raiz, hoy) if c is None else c
    av, grupos = [], {}
    for p in pend:
        grupos.setdefault(p[1], []).append(p)
    if len(pend) > TOPE_COLA:
        av.append(f"la cola tiene {len(pend)} pendientes (tope {TOPE_COLA}): cierra o pasa a diferidos lo que ya no va")
    if c and c[0] > c[1] and c[0] - c[1] >= 3:
        av.append(f"esta semana entraron {c[0]} pendientes y se cerraron {c[1]}: la cola crece")
    malas = [f"{p[0]} ({p[2]})" for p in pend if p[2] and not fecha_valida(p[2])]
    if malas:                                                  # 1.1 (Fable H2): una fecha que no existe se dice, no tumba nada
        av.append(f"due mal escrito: {', '.join(malas[:5])}{'…' if len(malas) > 5 else ''} → corrígelo con una fecha que exista (AAAA-MM-DD)")
    sin = grupos.get(None, [])
    if sin and len(grupos) > 1:
        lista = ", ".join(p[0] for p in sin[:5]) + ("…" if len(sin) > 5 else "")
        av.append(f"sin misión: {len(sin)} ({lista}) → cuélgalos de una misión (m:<nombre>) o pásalos a diferidos")
    elif sin and len(sin) > 15:
        av.append(f"{len(sin)} pendientes y ninguno con misión: agrúpalos con m:<nombre> (python3 organs/canary.py --dashboard)")
    abiertas = [g for g in grupos if g]
    if len(abiertas) > TOPE_MISIONES:
        av.append(f"hay {len(abiertas)} misiones abiertas (tope {TOPE_MISIONES}): las que son parte de otra, júntalas; una misión nueva la abre la persona")
    grandes = [(mi, len(ps)) for mi, ps in sorted(grupos.items(), key=lambda x: -len(x[1])) if mi and len(ps) > TOPE_MISION]
    if len(grandes) > 3:
        av.append(f"{len(grandes)} misiones pasan de {TOPE_MISION} pendientes ({', '.join(m for m, _ in grandes[:4])}…): ¿las partimos en planes con su propia lista?")
    else:
        av += [f"{mi} tiene {n}: ¿la partimos en un plan con su propia lista?" for mi, n in grandes]
    return av


def cabina(raiz, hoy=None):
    """La vista agrupada: una línea por misión, y debajo los avisos de la cola."""
    hoy = hoy or datetime.date.today()
    pend = pendientes(leer(Path(raiz) / "core" / "state.md"))
    if not pend:
        return ["🧭 cabina — no hay pendientes vivos en core/state.md"]
    c, nac, grupos = cola(raiz, hoy), nacimientos(raiz), {}
    for p in pend:
        grupos.setdefault(p[1], []).append(p)
    con = [g for g in grupos if g]
    cab = f"🧭 cabina — {len(pend)} pendientes en {len(con)} misi{'ón' if len(con) == 1 else 'ones'}"
    lineas = [cab + (f" · esta semana: entraron {c[0]}, se cerraron {c[1]}" if c else "")]
    ancho = max((len(g) for g in con), default=10)
    for mi, ps in sorted(((g, grupos[g]) for g in con), key=lambda x: -len(x[1])):
        vencidos = [p for p in ps if p[2] and fecha_valida(p[2]) and p[2] < hoy.isoformat()]
        partes = [f"{mi:<{ancho}}  {len(ps):>3}", f"{len(vencidos)} vencido{'s' if len(vencidos) != 1 else ''}" if vencidos else "al día"]
        edades = [(hoy - datetime.date.fromisoformat(nac[p[0]])).days for p in ps if p[0] in nac]
        if edades and max(edades) >= 7:
            partes.append(f"el más viejo: {max(edades)} días")
        futuros = sorted((p for p in ps if p[2] and fecha_valida(p[2]) and p[2] >= hoy.isoformat()), key=lambda p: p[2])
        if futuros:
            partes.append(f"próximo: {futuros[0][0]} {futuros[0][3][:50]} ({fecha_corta(futuros[0][2])})")
        lineas.append("  " + " · ".join(partes))
    sin = grupos.get(None, [])
    if sin:                                                    # los sueltos también se ven: con pocos, cuáles son
        lista = ", ".join(f"{p[0]} {p[3][:30]}" for p in sin[:3]) + (f" y {len(sin) - 3} más" if len(sin) > 3 else "")
        lineas.append(f"  {'(sin misión)':<{ancho}}  {len(sin):>3} · {lista}")
    lineas += ["  🟡 " + a for a in avisos_cola(raiz, hoy, pend, c)]
    return lineas


def nombres_viejos(raiz):
    """D230 (inglés como base): una carpeta con el nombre de antes y sin la nueva → 🔴. Con esos nombres el resto del
    chequeo no ve nada (diría que falta todo), así que el canario lo dice y no sigue."""
    raiz = Path(raiz)
    viejas = [f"{v}/" for v, n in VIEJOS.items() if (raiz / v).is_dir() and not (raiz / n).is_dir()]
    return [f"nombres viejos ({', '.join(viejas)}): corre {PY} install.py --migrate-names"] if viejas else []


def carga(raiz):
    """D230 (Marco: «nuestra ventana de contexto al iniciar es 11 %, el máximo permitido es 15 %»): los bytes de las 8 notas
    de core/, vault/INDEX.md y los diferidos, en tokens estimados (bytes / 4), como porcentaje de la ventana (200 000 por
    defecto; otra, con una línea «window: N» en core/start.md). Devuelve (porcentaje, línea, avisos 🟡)."""
    raiz = Path(raiz)
    dif = next((raiz / r for r in ("plans/DEFERRED_INDEX.md", "plans/DEFERRED.md") if (raiz / r).exists()), raiz / "plans" / "DEFERRED.md")
    archivos = [raiz / "core" / f"{n}.md" for n in NOTAS] + [raiz / "vault" / "INDEX.md", dif]
    b = sum(a.stat().st_size for a in archivos if a.is_file())
    m = re.search(r"^\s*window:\s*(\d[\d_]*)\s*$", leer(raiz / "core" / "start.md"), re.M)
    ventana = max(int(m.group(1).replace("_", "")), 1) if m else VENTANA
    pct = 100 * (b / 4) / ventana
    linea = f"carga al arrancar: {pct:.0f} % de {ventana / 1000:g}k (≈{b // 4} tokens: {b} bytes / 4)"
    avisos = [f"la carga al arrancar es {pct:.0f} % de la ventana (tope {TOPE_CARGA} %): poda core/state.md y baja lo cerrado a vault/"] if pct > TOPE_CARGA else []
    return pct, linea, avisos


def pasar_lista(raiz, hoy=None):
    raiz, hoy = Path(raiz), hoy or datetime.date.today()
    rojos, avisos, lineas = [], [], []
    estado = leer(raiz / "core" / "state.md")
    if not estado:
        return ["no encuentro core/state.md: no hay nada que vigilar"], [], []
    rojos += [f"falta o está vacía core/{n}.md" for n in NOTAS if not leer(raiz / "core" / f"{n}.md").strip()]
    cierres = sorted((raiz / "vault" / "closed").glob("*.md")) or sorted((raiz / "vault").rglob("*.md"))
    decisiones = leer(raiz / "core" / "decisions.md")
    cerrado = "\n".join(t for t in map(leer, cierres) if "[CLOSED" in t) + "\n" + "\n".join(l for l in decisiones.splitlines() if "[CLOSED" in l)
    lineas_closed = [(f"vault/{p.relative_to(raiz / 'vault').as_posix()}", n, l) for p in cierres
                     for n, l in enumerate(leer(p).splitlines(), 1) if "[CLOSED" in sin_citas(l)]
    lineas_closed += [("core/decisions.md", n, l) for n, l in enumerate(decisiones.splitlines(), 1) if "[CLOSED" in sin_citas(l)]
    hechos = set(re.findall(r"✔(" + ID + ")", "\n".join(l for _, l in seccion(estado, "DONE"))))
    vivos = ids(estado)

    # DIFERIDOS
    rel_dif = next((r for r in ("plans/DEFERRED_INDEX.md", "plans/DEFERRED.md") if (raiz / r).exists()), "plans/DEFERRED.md")
    diferidos = leer(raiz / rel_dif)
    defs, dif_rojos = [], []
    for n, l in enumerate(diferidos.splitlines(), 1):
        m = LINEA_DEF.match(l)
        if not m:
            continue
        did, resto = m.groups()
        defs.append(did)
        if "[CLOSED" in resto:
            lineas_closed.append((rel_dif, n, l))
            continue
        u, w = re.search(r"until:\s*(\d{4}-\d{2}-\d{2})", resto), re.search(r"when:\s*([^·]+)", resto)
        if u:
            try:
                fecha = datetime.date.fromisoformat(u.group(1))
            except ValueError:
                dif_rojos.append(f"{rel_dif}:{n} {did} tiene una fecha que no se entiende ({u.group(1)})")
                continue
            if fecha < hoy:
                dif_rojos.append(f"{did} venció el {fecha} («{re.sub(r'until:[^·]*·?', '', resto).strip(' ·')[:110]}»): vuelve a core/state.md como pendiente nuevo y aquí se cierra con [CLOSED {hoy} · reactivated as P<n>]")
            elif (fecha - hoy).days <= 7:
                avisos.append(f"{did} vence el {fecha} (en {(fecha - hoy).days} días)")
        elif w:
            lineas.append(f"⏳ gatillo {did}: cuando {w.group(1).strip()[:90]}")
        else:
            dif_rojos.append(f"{rel_dif}:{n} {did} no tiene until: ni when: — un diferido sin gatillo es un pendiente perdido")
    dif_rojos += [f"{d} aparece dos veces en {rel_dif}: un ID es un solo diferido" for d in sorted({x for x in defs if defs.count(x) > 1})]

    # LISTA 1 — el olvido
    rc, antes = git(raiz, "log", "-p", "--follow", "--format=", "-U0", "--", "core/state.md")      # todo lo que alguna vez entró al estado
    alguna_vez = {m.group(1) for l in antes.splitlines() if l[:1] == "+" for m in [LINEA_ID.match(l[1:])] if m}
    perdidos = []
    if rc == 127:
        lineas.append("⚪ lista 1 (olvido): no hay git, no puedo comparar con el estado anterior")
    elif rc != 0 or not antes.strip():
        lineas.append("⚪ lista 1 (olvido): todavía no hay un commit con core/state.md")
    else:
        ultima = {}                                                    # P1: la última línea que tuvo cada ID (git log va del más nuevo al más viejo)
        for l in antes.splitlines():
            m = LINEA_ID.match(l[1:]) if l[:1] == "+" else None
            if m and m.group(1) not in ultima:
                ultima[m.group(1)] = re.sub(r"^\s*[-*]\s*", "", sin_citas(l[1:])).strip()[:140]
        perdidos = [f"{i} entró alguna vez al estado y ya no está (ni ✔, ni [CLOSED], ni diferido); su última línea decía: «{ultima.get(i, '?')}»"
                    for i in sorted(alguna_vez - set(vivos)) if i not in hechos
                    and not re.search(rf"\b{i}\b", cerrado + "\n" + diferidos)]
        rc_d, hist_d = git(raiz, "log", "-p", "--follow", "--format=", "-U0", "--", rel_dif)      # todo lo que alguna vez entró a los diferidos
        perdidos += [f"{d} entró alguna vez a {rel_dif} y ya no está" for d in sorted({m.group(1) for l in hist_d.splitlines() if l[:1] == "+" for m in [LINEA_DEF.match(l[1:])] if m} - set(defs))] if rc_d == 0 else []
        lineas.append(f"{'🔴' if perdidos else '✅'} lista 1 (olvido): vivos {len(vivos)} · perdidos {len(perdidos)}")
    rojos += perdidos

    # LISTA 2 — la mentira
    malos = []
    for p in sorted((raiz / "core").glob("*.md")):
        malos += [f"core/{p.name}:{n} tiene una tachadura o una frase de invalidación: lo que terminó baja a la bóveda; la línea dice «{re.sub(r'~~', '', l).strip(' -')[:240]}»"
                  for n, l in enumerate(leer(p).splitlines(), 1) if TACHADO.search(sin_citas(l))]
        malos += [f"core/{p.name}:{n} tiene un posible secreto (no lo imprimo)" for n, l in enumerate(leer(p).splitlines(), 1) if SECRETO.search(l)]
        malos += [f"core/{p.name}:{n} usa una segunda marca de cierre ([CERRADO o [DONE:): la única es [CLOSED"
                  for n, l in enumerate(leer(p).splitlines(), 1) if re.search(r"\[CERRADO|\[DONE:", sin_citas(l))]
        malos += [f"core/{p.name}:{n} tiene un ítem que cita a otro para entenderse («ver P<n>»): cada línea se entiende sola"
                  for n, l in enumerate(leer(p).splitlines(), 1) if re.search(r"\bver [PC]\d+", re.sub(r"(needs|items):[^·]*", "", sin_citas(l)))]
    reglas = len(re.findall(r"^\d+\.\s", leer(raiz / "core" / "agreement.md"), re.M))
    malos += [f"core/agreement.md tiene {reglas} reglas: diez como máximo"] if reglas > 10 else []
    malos += [f"{r}:{n} [CLOSED sin evidence: ni reason: → «{l.strip()[:70]}»" for r, n, l in lineas_closed
              if not re.search(r"evidence:|reason:|reactivated as", l)]
    malos += [f"{i} aparece en dos líneas del estado: un ID es un solo pendiente" for i in sorted({x for x in vivos if vivos.count(x) > 1})]
    citados = [(n, x) for n, l in enumerate(estado.splitlines(), 1) for m in re.finditer(r"(needs|items):((?:\s*" + ID + r")+)", l) for x in re.findall(ID, m.group(2))]
    citados += [(n, x) for n, l in seccion(estado, "URGENT") for x in re.findall(r"\b" + ID + r"\b", l)]
    malos += [f"core/state.md:{n} cita {x}, que no está vivo en el estado ni en diferidos" for n, x in citados if x not in vivos and x not in defs]
    for n, l in enumerate(estado.splitlines(), 1):
        m = re.search(r"\bdue:\s*(\d{4}-\d{2}-\d{2})", l)
        if LINEA_ID.match(l) and m and m.group(1) < hoy.isoformat() and "OVERDUE" not in l:
            malos.append(f"core/state.md:{n} venció (due:{m.group(1)}) y le falta la marca OVERDUE")
    cerradas = "\n".join(sin_citas(l) for r, _, l in lineas_closed if r.startswith("vault/"))
    def historia(i):                                                   # P6b: todas las líneas de la bóveda que nombran el ID, en orden
        ls = [f"{p.relative_to(raiz).as_posix()}:{n} «{l.strip(' -')[:240]}»" for p in cierres for n, l in enumerate(leer(p).splitlines(), 1)
              if re.search(rf"\b{i}\b", sin_citas(l))]
        return ("; en la bóveda, en orden: " + " · ".join(ls[:6]) + (f" · (y {len(ls) - 6} más)" if len(ls) > 6 else "")) if ls else ""
    malos += [f"{i} está vivo y a la vez {'con ✔ en DONE' if i in hechos else 'con [CLOSED] en la bóveda' + historia(i)}"
              for i in sorted(set(vivos)) if i in hechos or re.search(rf"\b{i}\b", cerradas)]
    sig = re.search(r"siguiente ID libre:\s*P(\d+)\s*·\s*C(\d+)", estado)
    if sig:
        for k, tope in (("P", int(sig.group(1))), ("C", int(sig.group(2)))):
            usado = max([int(i[1:]) for i in set(vivos) | hechos if i[0] == k], default=0)
            if usado >= tope:
                malos.append(f"el ID {k}{usado} ya está usado y la cabecera dice que el siguiente libre es {k}{tope}")
    rojos += malos
    lineas.append(f"{'🔴' if malos else '✅'} lista 2 (mentira): {len(malos)} hallazgos")
    if diferidos:
        lineas.append(f"{'🔴' if dif_rojos else '✅'} diferidos: postergados {len([1 for l in diferidos.splitlines() if LINEA_DEF.match(l) and '[CLOSED' not in l])} · para mirar hoy {len(dif_rojos)}")
    rojos += dif_rojos
    avisos += [f"core/{p.name} todavía tiene partes «(por llenar)»" for p in sorted((raiz / "core").glob("*.md")) if "(por llenar)" in leer(p)]
    return rojos, avisos, lineas


def checks(raiz, tope=10):
    """organs/checks.txt: corre cada `nombre | comando | lo que debe decir` (tope de segundos). Devuelve (rojos, líneas)."""
    filas = [[l.split("|", 1)[0].strip(), l.split("|", 1)[1].rsplit("|", 1)[0].strip(), l.rsplit("|", 1)[1].strip()]
             for l in leer(Path(raiz) / "organs" / "checks.txt").splitlines()     # el comando puede llevar «|»
             if l.strip() and not l.lstrip().startswith("#") and l.count("|") >= 2]
    malas = [f"organs/checks.txt:{n} está mal escrita (hacen falta nombre | comando | lo que debe decir)"
             for n, l in enumerate(leer(Path(raiz) / "organs" / "checks.txt").splitlines(), 1) if l.strip() and not l.lstrip().startswith("#") and l.count("|") < 2]
    fallan = []
    for nombre, cmd, espera in filas:
        p = subprocess.Popen(cmd, shell=True, cwd=str(raiz), stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True,
                             start_new_session=os.name != "nt")          # su propio grupo: si se cuelga, se corta entero
        try:
            salida = p.communicate(timeout=tope)[0]
        except subprocess.TimeoutExpired:
            if os.name == "nt":
                subprocess.run(["taskkill", "/T", "/F", "/PID", str(p.pid)], capture_output=True)
            else:
                os.killpg(p.pid, 9)
            p.communicate()
            fallan.append(f"chequeo «{nombre}» no respondió en {tope} s")
            continue
        if espera.lower() not in salida.lower():
            fallan.append(f"chequeo «{nombre}» no dijo «{espera}» (dijo «{salida.strip()[:50]}»)")
    rojos = malas + fallan
    return rojos, ([f"{'🔴' if rojos else '✅'} chequeos propios: {len(filas) - len(fallan)}/{len(filas)}"] if filas or malas else [])


def atributos(p):
    """El candado del sistema sobre p, en texto: lsattr (Linux), ls -lO (Mac) o attrib (Windows)."""
    cmd = ["attrib", str(p)] if os.name == "nt" else ["ls", "-lOd", str(p)] if sys.platform == "darwin" else ["lsattr", "-d", str(p)]
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=10).stdout
    except Exception:
        return ""


def cerrado(a):
    """¿Los atributos (lsattr / ls -lO / attrib) dicen candado? Devuelve (con candado, es el muro «i» de Linux).
    La usan muro() y el instalador (también sobre la carpeta de antes, al migrar los nombres)."""
    cab = (a.split() or [""])[0]
    muro_i = "i" in cab and "-" in cab                    # lsattr: «----i---------e-------»
    return bool(muro_i or re.search(r"\b[us]chg\b", a) or (os.name == "nt" and re.search(r"^\s*(?:\w\s+)*R\s", a))), muro_i


def muro(raiz, ahora=None, attr=atributos):
    """El candado de organs/, la copia en git y lo que solo la persona hace a mano. Devuelve (avisos 🟡, líneas)."""
    raiz, ahora, avisos, lineas = Path(raiz), ahora or datetime.datetime.now().timestamp(), [], []
    con, muro_i = cerrado(attr(raiz / "organs" / "guardian.py"))
    if con:
        lineas.append("🔒 jaula con candado" + ("" if muro_i else " (seguro de puerta: lo quita el mismo usuario)"))
    else:
        avisos.append("jaula sin candado: corre python3 install.py --close (en Linux pide tu clave; en Windows, python en vez de python3)")
    rc, ult = git(raiz, "log", "-1", "--format=%ct")
    if rc == 0 and ult.strip():
        dias = (ahora - int(ult.strip())) / 86400
        avisos += [f"hace {int(dias)} días que nada entra a git: haz commit (la copia es el muro, no el guardián)"] if dias > 7 else []
        if not git(raiz, "remote")[1].strip():
            avisos.append("tu repositorio no tiene remoto: si el disco falla, no hay copia")
        else:
            rc_a, adelante = git(raiz, "rev-list", "--count", "@{u}..HEAD")
            avisos += ["tu rama no sigue a un remoto (git push -u)"] if rc_a else [f"lo local va {adelante.strip()} commits adelante del remoto: haz push"] if adelante.strip() not in ("", "0") else []
    else:
        avisos.append("el espacio no está en git (o no tiene ningún commit): no hay historia ni copia")
    viejos, peso = 0, 0
    for d, _, fs in os.walk(raiz / "_QUARANTINE"):
        for f in fs:
            try:
                st = os.stat(os.path.join(d, f))
            except OSError:
                continue
            viejos, peso = viejos + (ahora - st.st_mtime > 30 * 86400), peso + st.st_size
    if viejos or peso > 500 * 2**20:
        avisos.append(f"_QUARANTINE/ pesa {peso // 2**20} MB y tiene {viejos} archivos de más de 30 días: revísalo y vacíalo tú")
    rc, prim = git(raiz, "log", "--reverse", "--format=%ct")
    nacio = int(prim.split()[0]) if rc == 0 and prim.strip() else ahora
    if not (raiz / "organs" / "denied.txt").exists():
        avisos.append("🔴 falta organs/denied.txt: tus carpetas privadas quedaron sin cuidar (solo ~/.ssh y ~/.secretos); vuelve a correr install.py")
    propias = [l for l in leer(raiz / "organs" / "denied.txt").splitlines() if l.strip() and not l.lstrip().startswith("#")]
    if not propias and ahora - nacio > 7 * 86400:
        avisos.append("organs/denied.txt sigue sin carpetas propias: ¿dónde guardas los datos de tus clientes?")
    falta_hook = hook_secretos(raiz)
    if falta_hook:
        avisos.append(falta_hook)
    return avisos, lineas


def hook_secretos(raiz):
    """El hook pre-commit de git (organs/secret_scan.py): ¿está puesto, nombra a secret_scan.py y se puede ejecutar? Devuelve un aviso 🔴 o ''."""
    rc, ruta = git(raiz, "rev-parse", "--git-path", "hooks/pre-commit")
    if rc != 0 or not ruta.strip():
        return ""                                          # sin git no hay commits que cuidar (el aviso de «sin git» ya sale aparte)
    hook = Path(raiz) / ruta.strip()
    try:
        ok = "secret_scan.py" in hook.read_text(encoding="utf-8", errors="replace") and (os.name == "nt" or os.access(hook, os.X_OK))
    except OSError:
        ok = False
    return "" if ok else "🔴 falta el hook pre-commit de secretos: una llave, una contraseña o un DNI podría entrar a un commit; corre python3 install.py --hook (en Windows, python)"


def registrados(raiz):
    """Los comandos del guardián que Claude Code, Antigravity y Codex tienen registrados (usuario y proyecto). Mientras conviven,
    también vale el guardián de hoy de Marco (manos_guardia.py)."""
    home, raiz, res = Path.home(), Path(raiz), []
    for casa, p in (("claude", home / ".claude" / "settings.json"), ("claude", raiz / ".claude" / "settings.json"),
                    ("claude", raiz / ".claude" / "settings.local.json"),
                    ("antigravity", home / ".gemini" / "config" / "hooks.json"), ("antigravity", raiz / ".agents" / "hooks.json"),
                    ("codex", home / ".codex" / "hooks.json"), ("codex", raiz / ".codex" / "hooks.json")):      # Codex (1.1)
        try:
            texto = json.dumps(json.loads(p.read_text(encoding="utf-8")))
        except (OSError, ValueError):
            continue
        res += [(casa, c.encode().decode("unicode_escape")) for c in re.findall(r'"command": "((?:[^"\\]|\\.)*(?:guardian|manos_guardia)\.py(?:[^"\\]|\\.)*)"', texto)]
    return list(dict.fromkeys(res))


def leer_modo(raiz):
    """.endo/guardian_modo.json: {"modo": "prosa"|"codigo", "fecha", "nota", "huella", "ref"}. Sin archivo (1.0.2): {}."""
    try:
        d = json.loads((Path(raiz) / MODO).read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def huella(raiz):
    """El sha256 de cada archivo de organs/ (sin __pycache__), por ruta relativa."""
    org, res = Path(raiz) / "organs", {}
    for p in sorted(org.rglob("*")) if org.is_dir() else []:
        if p.is_file() and "__pycache__" not in p.parts:
            try:
                res[p.relative_to(org).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
            except OSError:
                res[p.relative_to(org).as_posix()] = "ilegible"
    return res


def cabeza(raiz):
    rc, h = git(raiz, "rev-parse", "--verify", "-q", "HEAD")
    return h.strip() if rc == 0 else ""


def guardar_modo(raiz, modo, nota, datos=None):
    """Lo llama install.py (la persona) al instalar o al cambiar de modo: el modo, la huella de organs/ y el punto de
    partida para ver borrados (el commit de hoy). Con `datos`, solo guarda esos datos (el canario mueve el punto de partida)."""
    d = datos or {"modo": modo, "fecha": datetime.date.today().isoformat(), "nota": nota, "huella": huella(raiz), "ref": cabeza(raiz)}
    p = Path(raiz) / MODO
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(d, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    return d


def blobs(p):
    """Los hashes con que git puede guardar el contenido de un archivo (sha1 de «blob <largo>\\0<contenido>»): el de los bytes
    tal cual y, si es texto con CRLF, el de LF (1.0.3, prueba en Windows: Git for Windows trae core.autocrlf=true, guarda LF
    y deja CRLF en el disco)."""
    try:
        c = Path(p).read_bytes()
    except OSError:
        return set()
    res = {hashlib.sha1(b"blob %d\x00" % len(c) + c).hexdigest()}
    if b"\r\n" in c and b"\x00" not in c:
        lf = c.replace(b"\r\n", b"\n")
        res.add(hashlib.sha1(b"blob %d\x00" % len(lf) + lf).hexdigest())
    return res


def borrados(raiz, ref):
    """Lo que estaba en git en `ref` y hoy no está en la carpeta ni pasó por _QUARANTINE/. No cuenta: lo que quarantine.py movió (con
    git mv git lo ve como renombre; si no, lo encuentra en un _QUARANTINE/), lo de adentro de _QUARANTINE/ (lo vacía la persona) y un
    archivo que se movió o se renombró sin git (el mismo contenido sigue en la carpeta). Devuelve la lista de rutas, o None si
    git no pudo comparar."""
    raiz = Path(raiz)
    rc, out = git(raiz, "-c", "core.quotepath=off", "diff", "-M", "--name-status", "--diff-filter=D", ref, "--")
    if rc != 0:
        return None
    faltan = [l.split("\t", 1)[1] for l in out.splitlines() if l.startswith("D\t")]
    faltan = [f for f in faltan if "_QUARANTINE" not in Path(f).parts and not os.path.lexists(raiz / f)]
    if not faltan:
        return []
    rc, arbol = git(raiz, "-c", "core.quotepath=off", "ls-tree", "-r", "-l", ref)      # «modo blob hash tamaño\truta»
    en_ref = {l.split("\t", 1)[1]: l.split("\t", 1)[0].split()[2:4] for l in arbol.splitlines() if "\t" in l and len(l.split("\t", 1)[0].split()) >= 4}
    en_borrar, tamanos = set(), []
    for d, dirs, fs in os.walk(raiz):
        dirs[:] = [x for x in dirs if x != ".git"]
        apartado = "_QUARANTINE" in Path(d).relative_to(raiz).parts
        for f in fs:
            if apartado:
                en_borrar.add(re.sub(r"\.\d+$", "", f))              # quarantine.py pone «nota.md.2» si ya había una
            try:
                tamanos.append((os.lstat(os.path.join(d, f)).st_size, os.path.join(d, f)))
            except OSError:
                pass
    def sigue(f):
        if Path(f).name in en_borrar:
            return True
        b, tam = en_ref.get(f, ["", "-1"])
        tam = int(tam) if tam.isdigit() else -1            # con CRLF en el disco el archivo pesa entre 1 y 2 veces su blob
        return bool(b) and any(b in blobs(p) for t, p in tamanos if tam <= t <= 2 * tam)
    return [f for f in faltan if not sigue(f)]


def vigilar_prosa(raiz, datos=None):
    """Modo prosa: la huella de organs/ y los borrados que no pasaron por _QUARANTINE/ desde el arranque anterior.
    Devuelve (hallazgos, líneas). Si no hubo borrados, el punto de partida pasa a este arranque; si los hubo, se queda
    donde estaba, y el hallazgo vuelve en cada arranque hasta que el archivo vuelva o la persona diga «lo vi, sigo en prosa»."""
    raiz, datos = Path(raiz), datos if datos is not None else leer_modo(raiz)
    hallazgos, lineas = [], []
    antes, ahora = datos.get("huella") or {}, huella(raiz)
    if not antes:
        hallazgos.append("no hay huella de organs/ guardada: no puedo saber si alguien la cambió")
    for n in sorted(set(antes) | set(ahora)) if antes else []:
        if antes.get(n) != ahora.get(n):
            que = "apareció" if n not in antes else "desapareció" if n not in ahora else "cambió"
            hallazgos.append(f"organs/{n} {que} desde la huella del {datos.get('fecha', '?')} (en prosa nada frena que se escriba en la jaula)")
    ref, head, perdidos = datos.get("ref") or "", cabeza(raiz), []
    if not head:
        lineas.append("⚪ prosa: todavía no hay commits; los borrados los miro desde el primero")
    elif not ref or git(raiz, "cat-file", "-e", ref + "^{commit}")[0] != 0:
        lineas.append("⚪ prosa: los borrados los miro desde este arranque")
    else:
        perdidos = borrados(raiz, ref)
        if perdidos is None:
            lineas.append("⚪ prosa: git no pudo comparar con el arranque anterior")
            perdidos = []
        en_head = set(git(raiz, "-c", "core.quotepath=off", "ls-tree", "-r", "--name-only", "HEAD")[1].splitlines()) if perdidos else set()
        hallazgos += [f"{f} estaba en git y desapareció sin pasar por _QUARANTINE/ (git lo guarda: commit {ref[:8]})"
                      + (f" · sin commit: «lo vi» ({PY} install.py --guardian off) no lo calla hasta que hagas commit del borrado"
                         " o restaures el archivo" if f in en_head else "") for f in perdidos[:10]]     # Fable, kit § B.4
        hallazgos += [f"… y {len(perdidos) - 10} archivos más que desaparecieron igual"] if len(perdidos) > 10 else []
    if head and not perdidos and head != ref and datos:
        try:
            guardar_modo(raiz, None, None, {**datos, "ref": head})
        except OSError:
            pass
    if not hallazgos:
        lineas.append("✅ prosa: organs/ igual a su huella · nada borrado fuera de _QUARANTINE/")
    return hallazgos, lineas


RECOMIENDA = (f"→ Te recomendamos activar el guardián en código. Activar, en tu terminal (no la IA): {PY} install.py --guardian on\n"
              f"    «Lo vi, sigo en prosa» (o el cambio en organs/ lo hiciste tú): {PY} install.py --guardian off")


def prueba_de_vida(raiz):
    """Cuatro eventos falsos al guardián registrado (el cuarto, solo en Claude Code y Codex; en Codex, un quinto: borrar con
    un parche de apply_patch). Devuelve (vive, líneas).
    Sin guardián registrado y con el modo prosa elegido, no es una desconexión: dice «⚪ guardián en prosa (elegido)»."""
    try:
        sys.path.insert(0, str(AQUI))
        import free
        con_llave = bool(free.vigente())
    except Exception:
        con_llave = False
    eventos = [("rm desde el home", "Bash", {"command": "rm __prueba_de_vida__.txt"}, Path.home(), False),
               ("rm desde el espacio", "Bash", {"command": "rm __prueba_de_vida__.txt"}, Path(raiz), False),
               ("leer ~/.ssh", "Read", {"file_path": str(Path.home() / ".ssh" / "__prueba_de_vida__")}, Path.home(), con_llave),
               ("escribir en organs/ por ruta relativa", "Bash", {"command": "echo x > organs/__prueba_de_vida__.txt"}, Path(raiz), False),
               ("borrar con un parche (Codex)", "apply_patch",
                {"command": "*** Begin Patch\n*** Delete File: __prueba_de_vida__.txt\n*** End Patch"}, Path(raiz), False)]
    cmds = registrados(raiz)
    m = leer_modo(raiz)
    if not cmds and m.get("modo") == "prosa":
        nota = m.get("nota") or "sin nota"
        nota = nota if nota.startswith("elegido") else "elegido; " + nota          # sin «elegido; elegido al instalar»
        return True, [f"⚪ guardián en prosa ({nota}, {m.get('fecha', '?')}): no frena nada; sus reglas están "
                      "escritas en AGENTS.md y en el trato"]
    if not cmds:
        return False,["🔴 GUARDIÁN DESCONECTADO: no está registrado ni en Claude Code (~/.claude/settings.json) ni en Antigravity ni en Codex"]
    vive, lineas = True, []
    for casa, cmd in cmds:
        for nombre, tool, args, cwd, debe_pasar in eventos:
            if "relativa" in nombre and (casa == "antigravity" or (Path(raiz) / "organs" / "guardian.py").as_posix() not in cmd.replace("\\", "/")):
                continue            # solo Claude Code y Codex (Antigravity no manda la carpeta de trabajo) y solo al guardián de ESTA carpeta (puede haber otros instalados)
            if tool == "apply_patch" and casa != "codex":
                continue            # el parche, solo a Codex (es su herramienta de edición)
            if casa in ("claude", "codex"):
                ev = {"tool_name": tool, "tool_input": args, "cwd": str(cwd)}
                ev.update({"turn_id": "__prueba_de_vida__", "hook_event_name": "PreToolUse"} if casa == "codex" else {})
            else:
                ev = {"toolCall": {"name": "run_command" if tool == "Bash" else "view_file",
                                   "args": {"CommandLine": args["command"]} if tool == "Bash" else {"AbsolutePath": args["file_path"]}}}
            try:
                r = subprocess.run(cmd, shell=True, input=json.dumps(ev), capture_output=True, text=True, encoding="utf-8",
                                   errors="replace", cwd=str(cwd), timeout=20,                # el guardián escribe en utf-8 (también en Windows)
                                   env={**os.environ, "CLAUDE_PROJECT_DIR": str(raiz)})
                # 1.1 (Fable, auditoría del 2-nov; un usuario, entrega 2b: «mirar la salida»): el código 2 solo no basta. Si la
                # carpeta se mudó, python no encuentra guardian.py y también sale con 2; frenar de verdad es 2 y su «frené».
                frena = (r.returncode == 2 and "frené" in r.stderr) if casa == "claude" else \
                        (r.returncode == 0 and '"permissionDecision": "deny"' in r.stdout and "frené" in r.stderr) if casa == "codex" else \
                        '"deny"' in r.stdout   # D231: a Codex el guardián le contesta con el JSON y salida 0 (en Windows ignora el 2)
            except Exception:
                frena = False
            if frena == debe_pasar:
                vive = False
                lineas.append(f"🔴 GUARDIÁN DESCONECTADO: en {casa}, «{nombre}» {'pasó' if not frena else 'se frenó'} ({cmd[:60]})")
    otras, llave_txt = sorted({c for c, _ in cmds} - {"codex"}), " (la lectura pasó: hay llave libre abierta)" if con_llave else ""
    if vive and otras:
        lineas.append(f"✅ guardián vivo: frenó las pruebas (borrado, ~/.ssh y jaula) en {', '.join(otras)}" + llave_txt)
    if vive and any(c == "codex" for c, _ in cmds):       # Fable, capa 1: que responda no prueba que Codex lo corra
        lineas.append("✅ guardián responde (codex) · ⚪ Codex solo lo corre si lo aprobaste con /hooks; eso no lo puedo ver desde aquí" + llave_txt)
    return vive, lineas


def main(argv):
    raiz = Path(argv[argv.index("--root") + 1]).resolve() if "--root" in argv else AQUI.parent
    viejos = nombres_viejos(raiz)
    if viejos:                                                 # D230: con los nombres de antes no se sigue
        print("🐤 canario — pasa lista")
        print("  🔴 " + viejos[0])
        print("  → No sigo con el resto del chequeo: con esos nombres no vería nada. Díselo a tu humano; lo corre la persona.")
        return 1
    if "--dashboard" in argv:                                     # 1.1 · la vista agrupada por misión; solo mira, nunca falla
        print("\n".join(cabina(raiz)))
        return 0
    rojos, avisos, lineas = pasar_lista(raiz)
    _, l_carga, a_carga = carga(raiz)                          # D230: el tope de carga al arrancar (avisa, no frena)
    lineas, avisos = lineas + [l_carga], avisos + a_carga
    avisos = avisos + avisos_cola(raiz)                        # 1.1 · el tope de cola: avisa, no frena
    if Path.cwd().resolve() != raiz.resolve():
        rojos.append(f"la IA está abierta en {Path.cwd()} y el núcleo vive en {raiz}: ciérrala y ábrela en la carpeta del núcleo")
    vive, lv = (True, []) if "--no-life-test" in argv else prueba_de_vida(raiz)
    r2, l2 = checks(raiz)
    a2, l3 = muro(raiz)
    modo = leer_modo(raiz)
    prosa = modo.get("modo") == "prosa"
    hp, lp = vigilar_prosa(raiz, modo) if prosa else ([], [])
    if prosa:                                                  # en prosa organs/ no lleva candado: la cuida la huella
        a2 = [a for a in a2 if "jaula sin candado" not in a]
    rojos, avisos, lineas = rojos + r2 + [a[2:].strip() for a in a2 if a.startswith("🔴")] + hp, [a for a in a2 if not a.startswith("🔴")] + avisos, lineas + l2 + l3 + lp
    print("🐤 canario — pasa lista")
    for l in lineas + lv:
        print("  " + l)
    for r in rojos:
        print("  🔴 " + r)
    if hp:
        print("  " + RECOMIENDA)
    for a in avisos:
        print("  🟡 " + a)
    if rojos or not vive:
        print("  → Díselo a tu humano antes de trabajar. No lo arregles solo: decide la persona.")
    return 1 if rojos or not vive else 0


def extras():
    """Casos de los agregados de Marco (D223): chequeos propios, candado, copia y recordatorios."""
    d, fallas = Path(tempfile.mkdtemp(prefix="canario_extra_")), []
    (d / "organs").mkdir()
    if os.name == "nt":                                   # cmd de Windows: sin cat ni sleep (D226, probado en Windows 11)
        casos = "sí | echo ok | findstr ok | ok\nno | echo mal | ok\ncolgado | ping -n 31 127.0.0.1 > nul & echo ok | ok\n"
    else:
        casos = "sí | echo ok | cat | ok\nno | echo mal | ok\ncolgado | sleep 30; echo ok | ok\n"
    (d / "organs" / "checks.txt").write_text("# ejemplo\n" + casos, encoding="utf-8")
    t0 = datetime.datetime.now()
    r, l = checks(d, tope=2)
    seg = (datetime.datetime.now() - t0).total_seconds()
    if len(r) != 2 or not any("«no»" in x for x in r) or not any("no respondió" in x for x in r) or "1/3" not in l[0] or seg > 8:
        fallas.append(f"chequeos propios: {r} {l} en {seg:.0f} s")
    c = ["-c", "user.name=p", "-c", "user.email=p@p", "-c", "commit.gpgsign=false"]
    (d / "nota.md").write_text("x\n", encoding="utf-8")
    (d / "organs" / "denied.txt").write_text("# solo comentarios\n", encoding="utf-8")
    hay_git = git(d, "init", "-q")[0] == 0 and git(d, "add", "-A")[0] == 0 and git(d, *c, "commit", "-qm", "x")[0] == 0
    ahora = datetime.datetime.now().timestamp()
    sin, _ = muro(d, ahora, attr=lambda p: "--------------e------- x")
    con, lc = muro(d, ahora, attr=lambda p: "----i---------e------- x")
    if not any("sin candado" in x for x in sin) or any("sin candado" in x for x in con) or not lc or "🔒" not in lc[0]:
        fallas.append("candado: no distingue con y sin")
    if hay_git:                                             # bloque 3: la segunda puerta (hook pre-commit de secretos)
        sin_gancho, _ = muro(d, ahora, attr=lambda p: "")
        gancho = d / ".git" / "hooks" / "pre-commit"
        gancho.write_text('#!/bin/sh\nexec python3 -I -B organs/secret_scan.py --pre-commit\n', encoding="utf-8")
        gancho.chmod(0o755)
        con_gancho, _ = muro(d, ahora, attr=lambda p: "")
        gancho.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")                   # un hook que no nombra a secret_scan.py no vale
        ajeno, _ = muro(d, ahora, attr=lambda p: "")
        if not any(x.startswith("🔴") and "pre-commit" in x for x in sin_gancho) or any("pre-commit" in x for x in con_gancho) \
                or not any("pre-commit" in x for x in ajeno):
            fallas.append(f"hook pre-commit: sin hook {sin_gancho[:1]} / con hook {con_gancho[:1]} / hook ajeno {ajeno[:1]}")
    if hay_git and not any("no tiene remoto" in x for x in sin):
        fallas.append("copia: un repositorio sin remoto no dio 🟡")
    r = d.parent / (d.name + "_remoto.git")                 # un remoto en el mismo disco: sin red
    if hay_git and git(d.parent, "init", "-q", "--bare", str(r))[0] == 0 and git(d, "remote", "add", "origin", str(r))[0] == 0 \
            and git(d, "push", "-q", "-u", "origin", "HEAD")[0] == 0:
        al_dia, _ = muro(d, ahora, attr=lambda p: "")
        (d / "nota.md").write_text("y\n", encoding="utf-8")
        git(d, *c, "commit", "-qam", "y")
        adelante, _ = muro(d, ahora, attr=lambda p: "")
        if any("adelante" in x or "remoto" in x for x in al_dia) or not any("1 commits adelante" in x for x in adelante):
            fallas.append(f"copia: al día {al_dia} / un commit sin push {adelante}")
    elif hay_git:
        fallas.append("copia: no pude armar el remoto local de prueba")
    viejo, _ = muro(d, ahora + 9 * 86400, attr=lambda p: "")
    if hay_git and not (any("nada entra a git" in x for x in viejo) and any("denied.txt sigue" in x for x in viejo)):
        fallas.append("copia y vedadas: a los 9 días sin commit ni vedadas no dio 🟡")
    (d / "_QUARANTINE").mkdir()
    (d / "_QUARANTINE" / "viejo.csv").write_text("x", encoding="utf-8")
    os.utime(d / "_QUARANTINE" / "viejo.csv", (ahora - 40 * 86400, ahora - 40 * 86400))
    b, _ = muro(d, ahora, attr=lambda p: "")
    if not any("_QUARANTINE/ pesa" in x for x in b) or any("denied.txt sigue" in x for x in b):
        fallas.append("_QUARANTINE/ viejo no dio 🟡 (o vedadas avisó antes de los 7 días)")
    sv = Path(tempfile.mkdtemp(prefix="canario_sin_denied_"))                       # bloque 2: sin denied.txt el canario lo grita
    (sv / "organs").mkdir()
    falta, _ = muro(sv, ahora, attr=lambda p: "")
    if not any(x.startswith("🔴") and "denied.txt" in x for x in falta):
        fallas.append("sin organs/denied.txt no dio 🔴")
    (d / "organs" / "checks.txt").write_text("mal | echo ok\nmayus | echo OK | ok\n", encoding="utf-8")          # bloque 2: dos campos y mayúsculas
    r, l = checks(d, tope=2)
    if len(r) != 1 or "mal escrita" not in r[0] or "1/1" not in l[0]:
        fallas.append(f"chequeo con dos campos o con mayúsculas distintas: {r} {l}")
    formas = "# STATE\n- P1 · a\n* P2 · b\n- [ ] P3 · c\n- [x] P4 · d\n1. P5 · e\n2) P6 · f\n- **P7** · g\n"       # bloque 2: viñetas de una persona que escribe como quiere
    if ids(formas) != [f"P{i}" for i in range(1, 8)]:
        fallas.append(f"viñetas: vio {ids(formas)}")
    for f in fallas:
        print(f"  FALLA: {f}")
    print(f"canario, agregados: {10 - len(fallas)}/10 casos bien (chequeos con tope de 2 s: {seg:.1f} s)" + ("" if hay_git else " (sin git: 3 no corren)"))
    return fallas


def casos_prosa(hablar=True):
    """1.0.3 · el modo prosa: la línea ⚪, la huella de organs/ y los borrados fuera de _QUARANTINE/, sin falsos positivos con el
    uso normal (apartar, mover, editar, vaciar _QUARANTINE/). Devuelve (fallas, cuántos casos)."""
    global registrados
    d = Path(tempfile.mkdtemp(prefix="canario_prosa_")).resolve()
    for rel, t in (("organs/denied.txt", "# x\n"), ("core/state.md", "# STATE\n"), ("notas.md", "a\n"), ("informe.md", "b\n"),
                   ("plano.md", "c\n"), ("mover.md", "m\n"), ("renombrar.md", "r\n"), ("carpeta con espacio/ñandú.md", "ñ\n"),
                   ("_QUARANTINE/.keep", "")):
        (d / rel).parent.mkdir(parents=True, exist_ok=True)
        (d / rel).write_text(t, encoding="utf-8")
    c = ["-c", "user.name=p", "-c", "user.email=p@p", "-c", "commit.gpgsign=false"]
    hay_git = git(d, "init", "-q")[0] == 0 and git(d, "add", "-A")[0] == 0 and git(d, *c, "commit", "-qm", "inicio")[0] == 0
    fallas, n = [], 0
    def caso(nombre, ok):
        nonlocal n
        n += 1
        if not ok:
            fallas.append(nombre)
            if hablar:
                print(f"  FALLA: prosa · {nombre}")
    def mirar():
        return vigilar_prosa(d)[0]
    def commit(msg):
        git(d, "add", "-A")
        git(d, *c, "commit", "-qm", msg)
    guardar_modo(d, "prosa", "elegido al instalar")
    caso("recién instalado: sin hallazgos", mirar() == [])
    bueno = registrados
    try:
        registrados = lambda raiz: []                                  # sin ningún guardián registrado en la máquina
        vive, l = prueba_de_vida(d)
        caso("sin registro y en prosa: «⚪ guardián en prosa (elegido)», no desconectado", vive and l and l[0].startswith("⚪ guardián en prosa (elegido"))
        sin_modo = Path(tempfile.mkdtemp(prefix="canario_sinmodo_"))
        vive, l = prueba_de_vida(sin_modo)
        caso("sin registro y sin modo elegido (una 1.0.2): sigue siendo 🔴 GUARDIÁN DESCONECTADO", not vive and "DESCONECTADO" in l[0])
    finally:
        registrados = bueno
    (d / "organs" / "denied.txt").write_text("# x\n~/Clientes\n", encoding="utf-8")
    (d / "organs" / "nuevo.py").write_text("print(1)\n", encoding="utf-8")
    h = mirar()
    caso("organs/ cambia: lo dice (cambió y apareció)", any("denied.txt cambió" in x for x in h) and any("nuevo.py apareció" in x for x in h))
    caso("el hallazgo sigue en el arranque siguiente", any("denied.txt cambió" in x for x in mirar()))
    guardar_modo(d, "prosa", "lo vi, sigo en prosa")
    caso("«lo vi, sigo en prosa» (huella nueva): sin hallazgos", mirar() == [])
    if hay_git:
        r = subprocess.run([sys.executable, "-B", str(AQUI / "quarantine.py"), str(d / "notas.md"), "prueba"], capture_output=True, text=True)
        (d / "informe.md").write_text("b editado\n", encoding="utf-8")
        (d / "sub").mkdir()
        os.replace(d / "mover.md", d / "sub" / "mover.md")                # mover a otra carpeta, sin git
        os.replace(d / "renombrar.md", d / "renombrado.md")               # renombrar en la misma carpeta, sin git
        (d / "nuevo.md").write_text("n\n", encoding="utf-8")
        h1 = mirar()
        commit("uso normal")
        caso("uso normal (apartar con git mv, editar, mover y renombrar sin git, crear y commit): sin hallazgos",
             r.returncode == 0 and h1 == [] and mirar() == [])
        os.remove(d / "plano.md")                                      # un borrado de verdad, sin pasar por _QUARANTINE/
        os.remove(d / "carpeta con espacio" / "ñandú.md")
        h = mirar()
        caso("un borrado sin _QUARANTINE/: lo dice (también con espacio y ñ en la ruta), y sin commit avisa que «lo vi» no lo calla",
             any("plano.md estaba en git" in x and "sin commit" in x for x in h) and any("carpeta con espacio/ñandú.md estaba en git" in x for x in h) and len(h) == 2)
        commit("se fue el plano")
        h = mirar()
        caso("el borrado commiteado sigue en el arranque siguiente (ya sin el aviso de «sin commit»)",
             any("plano.md estaba en git" in x and "sin commit" not in x for x in h))
        guardar_modo(d, "prosa", "lo vi, sigo en prosa")
        caso("«lo vi, sigo en prosa» con el borrado: sin hallazgos", mirar() == [])
        for f in (d / "_QUARANTINE").rglob("*"):                          # la persona vacía _QUARANTINE/ (lo apartado estaba en git)
            if f.is_file() and f.name != ".keep":
                os.remove(f)
        commit("vacié _QUARANTINE")
        caso("vaciar _QUARANTINE/ no es un borrado", mirar() == [])
        w = Path(tempfile.mkdtemp(prefix="canario_crlf_")).resolve()   # 1.0.3, prueba en Windows: Git for Windows de fábrica
        for rel in ("core/state.md", "organs/denied.txt", "mover.md", "renombrar.md", "plano.md"):
            (w / rel).parent.mkdir(parents=True, exist_ok=True)
            (w / rel).write_bytes(b"# " + rel.encode() + b"\r\nuna linea\r\notra linea\r\n")   # CRLF en el disco, como en Windows
        ok = git(w, "init", "-q")[0] == 0 and git(w, "config", "core.autocrlf", "true")[0] == 0
        git(w, "add", "-A")
        git(w, *c, "commit", "-qm", "inicio")
        crlf = ok and "\r\n" not in git(w, "show", "HEAD:mover.md")[1]       # git guardó LF: el caso de Windows
        guardar_modo(w, "prosa", "elegido al instalar")
        (w / "sub").mkdir()
        os.replace(w / "mover.md", w / "sub" / "mover.md")
        os.replace(w / "renombrar.md", w / "renombrado.md")
        h1 = vigilar_prosa(w)[0]
        os.remove(w / "plano.md")
        h2 = vigilar_prosa(w)[0]
        caso("core.autocrlf=true (CRLF en el disco, LF en git): mover y renombrar sin git no es un borrado; borrar, sí",
             crlf and h1 == [] and len(h2) == 1 and "plano.md estaba en git" in h2[0])
    return fallas, n


def casos_cabina(hablar=True):
    """1.1 · la cabina agrupada y el tope de cola, sobre un estado de ensayo con historia en git."""
    d, fallas, hoy = Path(tempfile.mkdtemp(prefix="canario_cabina_")), [], datetime.date(2026, 11, 2)
    (d / "core").mkdir()
    est = d / "core" / "state.md"
    c = ["-c", "user.name=p", "-c", "user.email=p@p"]
    hay_git = git(d, "init", "-q")[0] == 0

    def linea(i, m=None, due=None, que="tarea"):
        return f"- P{i} · " + (f"m:{m} · " if m else "") + (f"due:{due} · " if due else "") + f"{que} {i}\n"

    def commit(texto, fecha):
        est.write_text(texto, encoding="utf-8")
        os.environ["GIT_AUTHOR_DATE"] = os.environ["GIT_COMMITTER_DATE"] = f"{fecha}T12:00:00"
        try:
            git(d, *c, "add", "-A"); git(d, *c, "commit", "-qm", fecha)
        finally:
            os.environ.pop("GIT_AUTHOR_DATE", None); os.environ.pop("GIT_COMMITTER_DATE", None)

    tesis = [linea(i, "TESIS") for i in range(1, 9)] + [linea(9, "TESIS", "2026-10-30", "corregir la bibliografía"),
                                                         linea(10, "TESIS", "2026-11-06", "entregar el capítulo 2"), linea(11, "TESIS")]
    clientes = [linea(i, "CLIENTES") for i in range(12, 19)]
    casa = [linea(19, "CASA"), linea(20, "CASA")]
    sueltos = [linea(21), linea(22), linea(23)]
    viejo = "# STATE\n## PENDING\n" + "".join(tesis[:8] + clientes[:6] + casa[:2] + sueltos[:0]) + linea(98, "CASA") + linea(99, "CASA")
    nuevo = "# STATE\n## PENDING\n" + "".join(tesis + clientes + casa + sueltos) + "## DONE THIS SESSION\n- P97 · ya hecho\n"
    if hay_git:
        commit(viejo, "2026-10-23")
        commit(nuevo, "2026-11-02")
    else:
        est.write_text(nuevo, encoding="utf-8")
    vista = cabina(d, hoy)
    texto = "\n".join(vista)
    v1 = vista[1] if len(vista) > 1 else ""

    def caso(nombre, ok):
        if not ok:
            fallas.append(nombre)
            if hablar:
                print(f"  FALLA: {nombre}")

    caso("cuenta 23 pendientes en 3 misiones (DONE no cuenta)", "23 pendientes en 3 misiones" in vista[0])
    caso("la misión más grande va primero", v1.strip().startswith("TESIS") and " 11 " in v1)
    caso("cuenta el vencido y el próximo con su fecha", "1 vencido" in v1 and "próximo: P10 entregar el capítulo 2 10 (vie 6-nov)" in v1)
    caso("misión sin vencidos dice «al día»", any(l.strip().startswith("CLIENTES") and "al día" in l for l in vista))
    caso("pendientes sin misión, con sus IDs", "sin misión: 3 (P21, P22, P23)" in texto)
    caso("una misión grande propone partirla", "TESIS tiene 11" in texto)
    if hay_git:
        caso("la cola de la semana: entraron 7, se cerraron 2", "entraron 7, se cerraron 2" in vista[0] and "la cola crece" in texto)
        caso("el más viejo, según git", "el más viejo: 10 días" in v1)
    caso("el tope de cola salta con 45", any("la cola tiene 45" in a for a in avisos_cola(d, hoy, [("P%d" % i, "X", None, "x") for i in range(45)], (0, 0))))
    muchas = [("P%d" % i, "M%d" % (i % 9), None, "x") for i in range(9 * 12)]
    av = avisos_cola(d, hoy, muchas, (0, 0))
    caso("muchas misiones: un solo aviso de «júntalas» y uno de grandes", any("hay 9 misiones abiertas" in a for a in av) and sum("pasan de" in a for a in av) == 1 and not any(" tiene 12:" in a for a in av))
    caso("un estado sano no avisa nada", avisos_cola(d, hoy, [("P1", "A", None, "x"), ("P2", "B", None, "y")], (1, 1)) == [])
    caso("sin misiones y pocos pendientes: no molesta", avisos_cola(d, hoy, [("P%d" % i, None, None, "x") for i in range(5)], (0, 0)) == [])
    # 1.1 (Fable H2): un due: que no existe (mes 13, 31 de noviembre) no tumba la cabina; se marca 🟡 y lo demás sigue
    mala = Path(tempfile.mkdtemp(prefix="canario_due_"))
    (mala / "core").mkdir()
    (mala / "core" / "state.md").write_text("## PENDING\n- P1 · m:A · tarea · due:2026-13-01\n- P2 · m:A · otra · due:2026-11-31\n"
                                              "- P3 · m:A · bien · due:2026-11-20\n", encoding="utf-8")
    try:
        vm = "\n".join(cabina(mala, hoy))
    except Exception as e:
        vm = f"se cayó: {e!r}"
    caso("due mal escrito: la cabina no se cae, marca 🟡 los dos y sigue con el bueno",
         "🟡 due mal escrito: P1 (2026-13-01), P2 (2026-11-31)" in vm and "próximo: P3 bien (vie 20-nov)" in vm)
    caso("due mal escrito: también en el arranque (avisos_cola)", any(a.startswith("due mal escrito: P1") for a in avisos_cola(mala, hoy)))
    return fallas, (13 if hay_git else 11)


def casos_mudanza(hablar=True):
    """1.1 · el verde falso al mudar la carpeta: un guardián registrado que ya no está (python sale con 2 sin «frené»)
    tiene que dar DESCONECTADO; el guardián de verdad, vivo. Devuelve (fallas, cuántos casos)."""
    global registrados
    d, fallas, bueno = Path(tempfile.mkdtemp(prefix="canario_mudanza_")), [], registrados
    mudo = d / "sale_con_2.py"
    mudo.write_text("import sys\nsys.exit(2)\n", encoding="utf-8")
    py = f'"{sys.executable}" -I -B'
    casos = [("guardián que ya no está (la carpeta se mudó)", f'{py} "{d / "se_mudo" / "guardian.py"}"', False, "claude"),
             ("algo que sale con 2 sin decir «frené»", f'{py} "{mudo}"', False, "claude"),
             ("el guardián de verdad", f'{py} "{AQUI / "guardian.py"}"', True, "claude"),
             ("Codex (1.1): el guardián de verdad, también con el parche", f'{py} "{AQUI / "guardian.py"}"', True, "codex"),
             ("Codex (1.1): algo que sale con 2 sin decir «frené»", f'{py} "{mudo}"', False, "codex")]
    try:
        for nombre, cmd, vivo, casa in casos:
            registrados = lambda raiz, c=cmd, k=casa: [(k, c)]
            v, l = prueba_de_vida(d)
            if v != vivo or (not vivo and not any("DESCONECTADO" in x for x in l)):
                fallas.append(nombre)
                if hablar:
                    print(f"  FALLA: mudanza · {nombre} → {'vivo' if v else 'desconectado'} {l[:1]}")
    finally:
        registrados = bueno
    return fallas, len(casos)


def casos_d230(hablar=True):
    """D230 · los nombres viejos (🔴 y no sigue) y el tope de carga al arrancar (🟡 sobre el 15 %). Devuelve (fallas, cuántos casos)."""
    import io, contextlib
    fallas, n = [], 0
    def caso(nombre, ok):
        nonlocal n
        n += 1
        if not ok:
            fallas.append(nombre)
            if hablar:
                print(f"  FALLA: D230 · {nombre}")
    v = Path(tempfile.mkdtemp(prefix="canario_viejos_"))
    (v / "nucleo").mkdir(); (v / "organos").mkdir()
    (v / "nucleo" / "state.md").write_text("# STATE\n- P1 · algo\n", encoding="utf-8")
    caso("nucleo/ y organos/ sin core/ ni organs/: 🔴 con el comando que migra", any("--migrate-names" in x and "nucleo/" in x for x in nombres_viejos(v)))
    with contextlib.redirect_stdout(io.StringIO()) as salida:
        rc = main(["--root", str(v), "--no-life-test"])
    caso("con nombres viejos, main sale con 1 y no sigue con el resto", rc == 1 and "🔴 nombres viejos" in salida.getvalue() and "lista 1" not in salida.getvalue())
    (v / "core").mkdir()
    caso("organos/ sin organs/ (aunque ya haya core/): sigue en 🔴", any("organos/" in x and "nucleo/" not in x for x in nombres_viejos(v)))
    (v / "organs").mkdir()
    caso("con core/ y organs/ ya no es 🔴 (aunque quede una carpeta vieja)", nombres_viejos(v) == [])
    d = Path(tempfile.mkdtemp(prefix="canario_carga_"))
    (d / "core").mkdir()
    for nota in NOTAS:
        (d / "core" / f"{nota}.md").write_text(f"# {nota}\n" + "x" * 3000 + "\n", encoding="utf-8")
    pct, linea, av = carga(d)
    caso("un núcleo chico: dice el porcentaje y no avisa", "carga al arrancar: " in linea and " % de 200k" in linea and av == [] and 0 < pct < 15)
    (d / "core" / "state.md").write_text("- P1 · x\n" * 13000, encoding="utf-8")        # ~117 KB: con las demás pasa del 15 %
    pct, linea, av = carga(d)
    caso("un estado gordo (más del 15 % de 200k): 🟡 con el tope", pct > 15 and any("tope 15 %" in a for a in av))
    (d / "core" / "start.md").write_text("# start\nwindow: 1000000\n", encoding="utf-8")
    pct, linea, av = carga(d)
    caso("«window: 1000000» en core/start.md cambia la ventana: ya no avisa", "de 1000k" in linea and av == [])
    (d / "core" / "state.md").write_text("- P1 · x\n", encoding="utf-8")
    (d / "core" / "start.md").write_text("# start\n", encoding="utf-8")
    (d / "vault").mkdir(); (d / "plans").mkdir()
    (d / "vault" / "INDEX.md").write_text("y" * 70000, encoding="utf-8")
    (d / "plans" / "DEFERRED.md").write_text("z" * 70000, encoding="utf-8")
    pct, linea, av = carga(d)
    caso("cuenta también vault/INDEX.md y plans/DEFERRED.md", pct > 15 and av != [])
    return fallas, n


def selftest():
    global LINEA_ID, borrados
    def casos(hablar=True):
        d = Path(tempfile.mkdtemp(prefix="canario_"))
        for n in NOTAS:
            (d / "core").mkdir(exist_ok=True)
            (d / "core" / f"{n}.md").write_text(f"# {n}\n", encoding="utf-8")
        est = d / "core" / "state.md"
        est.write_text("# STATE\n- P1 · regar el lote 3\n- P2 · informe de suelos\n- C1 · ordenar fotos\n", encoding="utf-8")
        hay_git = git(d, "init", "-q")[0] == 0
        c = ["-c", "user.name=p", "-c", "user.email=p@p"]
        git(d, *c, "add", "-A")
        git(d, *c, "commit", "-qm", "inicio")
        fallas = []
        def caso(nombre, texto_estado, espera, extra=None):
            est.write_text(texto_estado, encoding="utf-8")
            for rel, t in (extra or {}).items():
                (d / rel).parent.mkdir(parents=True, exist_ok=True)
                (d / rel).write_text(t, encoding="utf-8")
            rojos, _, lineas = pasar_lista(d, datetime.date(2026, 10, 24))
            if not (espera(rojos, lineas)):
                fallas.append(nombre)
                if hablar:
                    print(f"  FALLA: {nombre} → {rojos}")
        base = "# STATE\n- P1 · regar el lote 3\n- C1 · ordenar fotos\n"
        if hay_git:
            caso("se perdió P2 sin cerrarse", base, lambda r, l: any("P2 entró" in x for x in r))
            git(d, *c, "commit", "-qam", "se fue P2")                                   # la pérdida ya está en un commit
            caso("P2 perdido y commiteado se sigue viendo", base, lambda r, l: any("P2 entró" in x for x in r))
            caso("1.0.2 · el perdido dice qué era", base, lambda r, l: any("P2 entró" in x and "informe de suelos" in x for x in r))
        caso("P2 cerrado en la bóveda con evidencia: nada", base, lambda r, l: not r,
             {"vault/cerrados.md": "- P2 · informe [CLOSED 2026-10-22 · done · evidence: informe.pdf]\n"})
        caso("tachadura y cita rota", "# STATE\n- P1 · regar · needs:P9\n- C1 · ~~ordenar fotos~~\n", lambda r, l: any("tachadura" in x for x in r) and any("P9" in x for x in r))
        caso("vencido sin OVERDUE y ID repetido", "# STATE\n- P1 · due:2026-10-01 · regar\n- P1 · otro\n- C1 · x\n", lambda r, l: any("OVERDUE" in x for x in r) and any("dos líneas" in x for x in r))
        caso("diferidos sanos: nada, y se ve el gatillo", "# STATE\n- C1 · ordenar fotos\n", lambda r, l: not r and any("gatillo DEF-2" in x for x in l),
             {"plans/DEFERRED.md": "- DEF-1 · was:P1 · until:2027-01-01 · regar\n- DEF-2 · when: llegue el dron · fotos\n"})
        caso("diferido vencido y sin gatillo", "# STATE\n- C1 · ordenar fotos\n", lambda r, l: any("DEF-1 venció" in x and "regar" in x for x in r) and any("DEF-2 no tiene" in x for x in r),
             {"plans/DEFERRED.md": "- DEF-1 · was:P1 · until:2020-01-01 · regar\n- DEF-2 · fotos\n- DEF-3 · x [CLOSED 2026-10-01 · reactivated as P7]\n"})
        if hay_git:                                                                   # bloque 2: lo mismo para los diferidos
            dp = d / "plans" / "DEFERRED.md"
            dp.parent.mkdir(exist_ok=True)
            dp.write_text("- DEF-5 · was:P1 · until:2099-01-01 · regar\n- DEF-6 · when: llueva · fotos\n", encoding="utf-8")
            git(d, *c, "add", "-A"); git(d, *c, "commit", "-qm", "dos diferidos")
            dp.write_text("- DEF-6 · when: llueva · fotos [CLOSED 2026-10-24 · reactivated as P9]\n", encoding="utf-8")
            git(d, *c, "commit", "-qam", "se fue DEF-5")
            caso("DEF borrado y commiteado se ve; el cerrado con [CLOSED no", "# STATE\n- P1 · m:X · regar\n## DONE THIS SESSION\n✔P1 ✔C1\n",
                 lambda r, l: any("DEF-5 entró" in x for x in r) and not any("DEF-6" in x for x in r))
        caso("formato de Marco: ✔ en DONE evita «perdido»; vivo y cerrado a la vez", "# STATE\n- P1 · m:X · regar\n## DONE THIS SESSION\n✔P1 ✔C1\n",
             lambda r, l: any("P1 está vivo" in x for x in r) and not any("C1 estaba" in x for x in r))
        caso("1.0.2 · vivo y cerrado muestra todas sus líneas de la bóveda, en orden", "# STATE\n- P3 · comprar harina\n- C1 · x\n",
             lambda r, l: any("P3 está vivo" in x and "boleta 51" in x and "REABIERTO" in x and x.index("boleta 51") < x.index("REABIERTO") for x in r),
             {"vault/cerrados.md": "- P3 · comprar harina [CLOSED 2026-10-20 · done · evidence: boleta 51]\n- P3 · REABIERTO 2026-10-22 · la boleta era de otro pedido\n"})
        if hablar:
            print(f"canario: {11 - len(fallas)}/11 casos bien" + ("" if hay_git else " (sin git: 3 casos no corren)"))
        return fallas
    fallas = casos()
    fallas += extras()
    fc, nc = casos_cabina()
    fallas += fc
    print(f"canario, cabina y cola (1.1): {nc - len(fc)}/{nc} casos bien")
    fm, nm = casos_mudanza()
    fallas += fm
    print(f"canario, carpeta mudada (1.1): {nm - len(fm)}/{nm} casos bien")
    fp, n = casos_prosa()
    fallas += fp
    print(f"canario, modo prosa (1.0.3): {n - len(fp)}/{n} casos bien")
    fd, nd = casos_d230()
    fallas += fd
    print(f"canario, nombres viejos y carga al arrancar (D230): {nd - len(fd)}/{nd} casos bien")
    bueno, LINEA_ID = LINEA_ID, re.compile(r"(?!)")          # falla sembrada: el canario deja de ver los IDs
    atrapada = len(casos(hablar=False)) > 0
    LINEA_ID = bueno
    print(f"  falla sembrada (no ve los IDs): {'✅ atrapada' if atrapada else '🔴 NO atrapada'}")
    bueno, borrados = borrados, lambda raiz, ref: []          # falla sembrada 1.0.3: en prosa no ve ningún borrado
    atrapada_p = len(casos_prosa(hablar=False)[0]) > 0
    borrados = bueno
    print(f"  falla sembrada (en prosa no ve los borrados): {'✅ atrapada' if atrapada_p else '🔴 NO atrapada'}")
    global pendientes
    bueno, pendientes = pendientes, lambda texto: []          # falla sembrada 1.1: la cabina no ve ningún pendiente
    atrapada_c = len(casos_cabina(hablar=False)[0]) > 0
    pendientes = bueno
    print(f"  falla sembrada (la cabina no ve los pendientes): {'✅ atrapada' if atrapada_c else '🔴 NO atrapada'}")
    global fecha_valida
    bueno, fecha_valida = fecha_valida, lambda iso: True       # falla sembrada 1.1 (Fable H2): toda fecha con forma «existe»
    atrapada_f = len(casos_cabina(hablar=False)[0]) > 0
    fecha_valida = bueno
    print(f"  falla sembrada (cree que 2026-13-01 existe): {'✅ atrapada' if atrapada_f else '🔴 NO atrapada'}")
    global TOPE_CARGA, nombres_viejos
    bueno, TOPE_CARGA = TOPE_CARGA, 100                        # falla sembrada D230: el tope de carga no avisa nunca
    atrapada_t = len(casos_d230(hablar=False)[0]) > 0
    TOPE_CARGA = bueno
    print(f"  falla sembrada (el tope de carga no avisa): {'✅ atrapada' if atrapada_t else '🔴 NO atrapada'}")
    bueno, nombres_viejos = nombres_viejos, lambda raiz: []    # falla sembrada D230: no ve los nombres viejos
    atrapada_v = len(casos_d230(hablar=False)[0]) > 0
    nombres_viejos = bueno
    print(f"  falla sembrada (no ve los nombres viejos): {'✅ atrapada' if atrapada_v else '🔴 NO atrapada'}")
    return 0 if not fallas and atrapada and atrapada_p and atrapada_c and atrapada_f and atrapada_t and atrapada_v else 1


if __name__ == "__main__":
    sys.exit(selftest() if "--selftest" in sys.argv else main(sys.argv[1:]))
