#!/usr/bin/env python3
"""
quarantine.py — Endosimbiosis v1. En vez de borrar, aparta: mueve a _QUARANTINE/<fecha>-<motivo>/ del espacio.

Qué hace. `quarantine.py <ruta> [motivo]` busca el _QUARANTINE/ más cercano subiendo desde la ruta hasta la raíz del espacio
(la carpeta que tiene core/, o la raíz de git, o tu carpeta personal); si no hay ninguno, lo crea en la raíz.
Si la ruta está en git, usa `git mv` (la historia la sigue) y avisa que el traslado quedó preparado en el índice, para
commitearlo aparte (1.0.3); si no, la mueve. Dice a dónde fue. Nunca borra.
Cada espacio tiene su _QUARANTINE/, personal y auditable: lo revisa y lo vacía su dueño, a mano (Marco D223).

Qué cuida del trato: la regla 1 (nada se borra). Es el camino que el guardián nombra en cada freno.
Su límite: no aparta la jaula (organs/ y los hooks): eso lo mueve solo la persona.
Cómo se prueba: python organs/quarantine.py --selftest
"""
import sys, os, re, io, shutil, contextlib, subprocess, datetime, tempfile
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
AQUI = Path(__file__).resolve().parent


def git(cwd, *args):
    try:
        r = subprocess.run(["git", "-C", str(cwd), *args], capture_output=True, text=True, encoding="utf-8")
        return r.returncode, r.stdout.strip()
    except FileNotFoundError:
        return 127, ""


def raiz_del_espacio(p):
    for d in [p, *p.parents]:
        if (d / "core").is_dir():
            return d
    rc, top = git(p if p.is_dir() else p.parent, "rev-parse", "--show-toplevel")
    return Path(top).resolve() if rc == 0 and top else Path.home().resolve()


def apartar(ruta, motivo="apartado"):
    p = Path(ruta).expanduser()
    p = p.parent.resolve() / p.name                       # un enlace se aparta como enlace, no su destino
    if not p.exists() and not p.is_symlink():
        raise SystemExit(f"no existe: {ruta}")
    if p == AQUI or AQUI in p.parents or re.search(r"\.claude/(settings|hooks)|\.agents/hooks|\.gemini/config/hooks", p.as_posix()):
        raise SystemExit("eso es la jaula (organs/ o los hooks): lo aparta solo la persona, a mano")
    raiz = raiz_del_espacio(p)
    borrar = next((d / "_QUARANTINE" for d in [p.parent, *p.parent.parents] if (d / "_QUARANTINE").is_dir()
                   and (d == raiz or raiz in d.parents)), raiz / "_QUARANTINE")
    if borrar in [p, *p.parents]:
        raise SystemExit("ya está en _QUARANTINE/: se vacía a mano")
    etiqueta = re.sub(r"[^\w-]+", "-", motivo).strip("-") or "apartado"
    destino = borrar / f"{datetime.date.today()}-{etiqueta}" / p.name
    n = 1
    while destino.exists():
        n += 1
        destino = destino.with_name(f"{p.name}.{n}")
    destino.parent.mkdir(parents=True, exist_ok=True)
    en_git = git(p.parent, "ls-files", "--error-unmatch", str(p))[0] == 0
    con_git = en_git and git(p.parent, "mv", str(p), str(destino))[0] == 0
    if not con_git:
        try:
            shutil.move(str(p), str(destino))
        except OSError as e:
            raise SystemExit(f"no pude apartar {p}: {e.strerror or e}. El original sigue donde estaba"
                             + (f"; quedó una copia en {destino} (no la borro)" if destino.exists() else ""))
    print(f"apartado{' (git mv)' if con_git else ''}: {p} → {destino}")
    if con_git:                                           # 1.0.3: el commit mezclado del 31-oct
        print("   git: el traslado quedó preparado en el índice; haz con él un commit aparte, para que no se mezcle con otro trabajo")
    return destino


def casos(hablar=True):
    d = Path(tempfile.mkdtemp(prefix="apartar_")).resolve()
    (d / "core").mkdir()
    (d / "proyecto" / "_QUARANTINE").mkdir(parents=True)
    (d / "proyecto" / "sub").mkdir()
    (d / "viejo.csv").write_text("x", encoding="utf-8")
    (d / "proyecto" / "sub" / "nota.md").write_text("y", encoding="utf-8")
    hoy, fallas = datetime.date.today(), []
    a = apartar(d / "viejo.csv", "duplicado")
    if a != d / "_QUARANTINE" / f"{hoy}-duplicado" / "viejo.csv" or not a.exists() or (d / "viejo.csv").exists():
        fallas.append("sin _QUARANTINE cercano: debía crearlo en la raíz del espacio, y el archivo debía seguir existiendo")
    b = apartar(d / "proyecto" / "sub" / "nota.md", "otra versión")
    if b != d / "proyecto" / "_QUARANTINE" / f"{hoy}-otra-versión" / "nota.md" or not b.exists():
        fallas.append("debía usar el _QUARANTINE/ más cercano (proyecto/)")
    if git(d, "init", "-q")[0] == 0:
        (d / "seguido.md").write_text("z", encoding="utf-8")
        git(d, "add", "seguido.md")
        git(d, "-c", "user.name=p", "-c", "user.email=p@p", "commit", "-qm", "x")
        salida = io.StringIO()
        with contextlib.redirect_stdout(salida):
            c = apartar(d / "seguido.md", "git")
        if "R" not in git(d, "status", "--porcelain")[1] or not c.exists():
            fallas.append("en git debía usar git mv (git lo ve como renombre)")
        (d / "suelto.txt").write_text("s", encoding="utf-8")                                 # 1.0.3: fuera de git no hay índice que avisar
        suelto = io.StringIO()
        with contextlib.redirect_stdout(suelto):
            apartar(d / "suelto.txt", "suelto")
        if "commit aparte" not in salida.getvalue() or "(git mv)" not in salida.getvalue() or "commit aparte" in suelto.getvalue():
            fallas.append(f"1.0.3 · el aviso del índice: con git mv {salida.getvalue()!r} / sin git {suelto.getvalue()!r}")
    try:
        apartar(AQUI / "guardian.py")
        fallas.append("apartó la jaula")
    except SystemExit:
        pass
    (d / "destino.txt").write_text("d", encoding="utf-8")                                  # bloque 2: un enlace se aparta como enlace
    try:
        os.symlink(d / "destino.txt", d / "enlace.txt")
        e = apartar(d / "enlace.txt", "enlace")
        if not e.is_symlink() or (d / "enlace.txt").is_symlink() or not (d / "destino.txt").exists():
            fallas.append("un enlace se apartó mal: debía moverse el enlace y quedar el destino")
    except OSError:
        pass                                                                                   # sin permiso para crear enlaces (Windows): el caso no aplica
    if os.name != "nt" and hasattr(os, "geteuid") and os.geteuid() != 0:                       # bloque 2: sin permiso, un mensaje y no un traceback
        sp = d / "sinpermiso"
        sp.mkdir()
        (sp / "a.txt").write_text("x", encoding="utf-8")
        sp.chmod(0o555)
        try:
            apartar(sp / "a.txt", "sin permiso")
            fallas.append("sin permiso: debía avisar y no avisó")
        except SystemExit as e:
            if "no pude apartar" not in str(e) or not (sp / "a.txt").exists():
                fallas.append(f"sin permiso: el mensaje o el original no están bien ({e})")
        finally:
            sp.chmod(0o755)
    for f in fallas if hablar else []:
        print("  FALLA:", f)
    return fallas


def selftest():
    global raiz_del_espacio
    fallas = casos()
    print(f"apartar: {7 - len(fallas)}/7 casos bien")
    bueno, raiz_del_espacio = raiz_del_espacio, lambda p: Path(tempfile.mkdtemp(prefix="otro_"))   # falla sembrada: raíz equivocada
    with contextlib.redirect_stdout(io.StringIO()):
        atrapada = len(casos(hablar=False)) > 0
    raiz_del_espacio = bueno
    print(f"  falla sembrada (raíz del espacio equivocada): {'✅ atrapada' if atrapada else '🔴 NO atrapada'}")
    return 0 if not fallas and atrapada else 1


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)
    apartar(sys.argv[1], " ".join(sys.argv[2:]) or "apartado")
