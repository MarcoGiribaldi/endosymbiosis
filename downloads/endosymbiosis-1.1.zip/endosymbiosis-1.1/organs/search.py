#!/usr/bin/env python3
"""
search.py — Endosimbiosis v1. Busca en toda la memoria en una sola llamada y termina con un veredicto citable.

Qué hace. Busca en dos lugares:
  VIVO       todos los archivos de texto de hoy en el espacio (núcleo, planes, bóveda, _QUARANTINE/, código, notas) y en
             las carpetas que agregues con --also.
  HISTORIAL  todo lo que alguna vez se escribió y después cambió o se borró, en todas las ramas de git
             (fecha · commit · archivo · ± texto).
No distingue mayúsculas; | separa sinónimos («riego|regar|goteo»). Al final dice «existe» o «no existe» con dónde
buscó, para que la IA lo cite tal cual.

Qué cuida del trato: «no existe» solo después de buscar, y diciendo dónde (regla del voto honesto).
Su límite: busca texto, no significado (si se dijo con otra palabra, hay que darle el sinónimo); y no ve lo que
nunca entró a git ni está en disco.
Cómo se prueba: python organs/search.py --selftest
Uso:  python organs/search.py "riego|goteo" [desde AAAA-MM-DD] [hasta AAAA-MM-DD] [--also CARPETA] [--all]
"""
import sys, re, subprocess, datetime, tempfile
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

AQUI = Path(__file__).resolve().parent
FUERA = {".git", "__pycache__", "node_modules", ".endo", "symbiosis-manual"}   # 1.1: el manual de Simbiosis es consulta, no tus notas
PROPIOS = {"install.py", "ENDOSYMBIOSIS.md", "README.md", "MIGRATE.md"}        # el kit no se cita a sí mismo
TOPE = 60


def git(raiz, *args):
    try:
        r = subprocess.run(["git", "-C", str(raiz), *args], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
        return r.returncode, r.stdout
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return 127, ""


def corta(t, rx, largo=200):
    """1.1 (prueba de tokens del 2-nov): una línea larga se corta a ~200 caracteres; si lo buscado cae lejos, se muestra ese tramo."""
    t = t.strip()
    if len(t) <= largo:
        return t
    m = rx.search(t)
    if m and m.start() > largo - 60:
        return "… " + t[m.start() - 60:m.start() + largo - 60] + " …"
    return t[:largo] + " …"


def vivo(carpetas, rx, base):
    hallados = []
    for c in carpetas:
        for p in sorted(Path(c).rglob("*")):
            if not p.is_file() or FUERA & set(p.parts) or p.stat().st_size > 20_000_000 or p.name in PROPIOS or (p.parent.name == "organs" and p.suffix == ".py"):
                continue
            try:
                datos = p.read_bytes()
            except OSError:
                continue
            if b"\0" in datos[:8192]:                        # binario: se salta, como grep -I
                continue
            nombre = p.relative_to(base).as_posix() if base in p.parents else str(p)
            for n, l in enumerate(datos.decode("utf-8", "replace").splitlines(), 1):
                if rx.search(l):
                    hallados.append(f"{nombre}:{n}: {corta(l, rx)}")
    return hallados


def historial(raiz, rx, patron, desde=None, hasta=None):
    args = ["log", "--all", "-i", "-E", f"-G{patron}", "-p", "-U0", "--no-color", "--format=@@C %h %as", "--diff-filter=AMD"]
    args += [f"--since={desde}"] if desde else []
    args += [f"--until={hasta} 23:59"] if hasta else []
    rc, out = git(raiz, *args, "--", ".", ":!organs/*.py", *(":!" + n for n in PROPIOS), ":!symbiosis-manual/*")   # 1.1: ni el manual de Simbiosis
    if rc == 127:
        return None
    hallados, vistos, cabeza, archivo = [], set(), "", ""
    for l in out.splitlines():
        if l.startswith("@@C "):
            cabeza = " · ".join(l.split()[1:][::-1])
        elif l.startswith(("--- a/", "+++ b/")):
            archivo = l[6:]
        elif l[:1] and l[:1] in "+-" and not l.startswith(("+++", "---")) and rx.search(l[1:]) and l[1:] not in vistos:
            vistos.add(l[1:])
            hallados.append(f"{cabeza} · {archivo} · {l[0]} {corta(l[1:], rx, 180)}")
    return hallados


def mostrar(titulo, filas, todo):
    print(f"== {titulo}")
    for f in (filas if todo else filas[:TOPE]) or ["(sin coincidencias)"]:
        print("  " + f)
    if not todo and len(filas) > TOPE:
        print(f"  (+{len(filas) - TOPE} más: afina el patrón o agrega --all)")


def main(argv):
    raiz = Path(argv[argv.index("--root") + 1]).resolve() if "--root" in argv else AQUI.parent
    extras = [Path(argv[i + 1]).expanduser().resolve() for i, a in enumerate(argv) if a == "--also"]
    resto = [a for i, a in enumerate(argv) if not a.startswith("--") and (i == 0 or argv[i - 1] not in ("--also", "--root"))]
    if not resto:
        print(__doc__)
        return 2
    patron, fechas = resto[0], (resto[1:3] + [None, None])[:2]
    if not patron.strip():
        print("dime qué buscar: palabras separadas por | para sinónimos")
        return 2
    try:
        rx = re.compile(patron, re.I)
    except re.error as e:
        print(f"la búsqueda no se entiende ({e}); usa palabras y | para sinónimos")
        return 2
    rc, top = git(raiz, "rev-parse", "--show-toplevel")
    top = Path(top.strip()).resolve() if rc == 0 and top.strip() else raiz
    donde = [raiz] + [e for e in extras if e.exists()]
    v = vivo(donde, rx, top)
    mostrar(f"VIVO  («{patron}» en {', '.join(str(d) for d in donde)})", v, "--all" in argv)
    h = historial(top, rx, patron, *fechas)
    if h is None:
        print("== HISTORIAL\n  ⚪ no hay git: solo se buscó en lo vivo")
    else:
        mostrar(f"HISTORIAL git de {top}, todas las ramas{' desde ' + fechas[0] if fechas[0] else ''}{' hasta ' + fechas[1] if fechas[1] else ''} (fecha · commit · archivo · ± texto)", h, "--all" in argv)
    hoy = datetime.date.today()
    if v or h:
        print(f"VEREDICTO: existe · {len(v)} en lo vivo, {len(h or [])} en el historial · primera cita: {(v or h)[0][:150]}")
    else:
        print(f"VEREDICTO: no existe · 0 en lo vivo ({', '.join(str(d) for d in donde)}) y 0 en el historial "
              f"{'git de ' + str(top) if h is not None else '(sin git)'} · buscado el {hoy} con «{patron}»")
    return 0


def casos(hist=None):
    hist = hist or historial
    d = Path(tempfile.mkdtemp(prefix="buscar_"))
    (d / "core").mkdir()
    nota = d / "core" / "decisions.md"
    nota.write_text("- 2026-10-01 · DECISION · riego por goteo en el lote 3\n", encoding="utf-8")
    fallas = []
    if git(d, "init", "-q")[0] != 127:
        c = ["-c", "user.name=p", "-c", "user.email=p@p"]
        git(d, *c, "add", "-A"); git(d, *c, "commit", "-qm", "uno")
        nota.write_text("- 2026-10-02 · DECISION · se cambió a aspersión\n", encoding="utf-8")
        git(d, *c, "add", "-A"); git(d, *c, "commit", "-qm", "dos")
        h = hist(d, re.compile("GOTEO", re.I), "GOTEO") or []
        if not any("goteo" in x and " · - " in x for x in h):
            fallas.append("el historial no encontró lo que se borró (sin distinguir mayúsculas)")
    if not vivo([d], re.compile("ASPERSIÓN", re.I), d):
        fallas.append("no encontró en lo vivo sin distinguir mayúsculas")
    if vivo([d], re.compile("goteo", re.I), d):
        fallas.append("encontró en lo vivo algo que ya no está")
    (d / "organs").mkdir()                                                           # bloque 2: el kit no se cita a sí mismo
    (d / "organs" / "search.py").write_text("# riego por goteo\n", encoding="utf-8")
    (d / "README.md").write_text("riego por goteo\n", encoding="utf-8")
    (d / "symbiosis-manual").mkdir()                                                  # 1.1: ni el manual de Simbiosis
    (d / "symbiosis-manual" / "Simbiosis_2.1.md").write_text("riego por goteo\n", encoding="utf-8")
    (d / "organs" / "denied.txt").write_text("~/riego\n", encoding="utf-8")
    hallado = vivo([d], re.compile("riego|goteo", re.I), d)
    if any("search.py" in x or "README.md" in x or "symbiosis-manual" in x for x in hallado) or not any("denied.txt" in x for x in hallado):
        fallas.append(f"el buscador se citó a sí mismo (o dejó de ver denied.txt): {hallado}")
    larga = "x" * 900 + " palabra rara " + "y" * 900                                # 1.1: líneas largas cortadas, con lo buscado a la vista
    (d / "core" / "larga.md").write_text(larga + "\n", encoding="utf-8")
    h = [x for x in vivo([d], re.compile("palabra rara"), d) if "larga.md" in x]
    if not h or len(h[0]) > 260 or "palabra rara" not in h[0]:
        fallas.append(f"una línea de 1 800 caracteres no se cortó con lo buscado a la vista: {h[0][:80] if h else 'no la encontró'}")
    if git(d, "init", "-q")[0] != 127:                                              # D231: el historial tampoco cita el manual
        c = ["-c", "user.name=p", "-c", "user.email=p@p"]
        git(d, *c, "add", "-A"); git(d, *c, "commit", "-qm", "tres")
        if any("symbiosis-manual" in x for x in hist(d, re.compile("goteo", re.I), "goteo") or []):
            fallas.append("el historial citó el manual de Simbiosis")
    try:
        hist(d, re.compile(".*"), ".*")                                               # bloque 2: «.*» no es un error
    except Exception as e:
        fallas.append(f"buscar «.*» explotó: {e!r}")
    return fallas


def vacio():
    import io, contextlib
    with contextlib.redirect_stdout(io.StringIO()):
        return main([""])


def selftest():
    fallas = casos() + ([] if vacio() == 2 else ["buscar «» no dijo «dime qué buscar» con salida 2"])
    print(f"buscar: {7 - len(fallas)}/7 casos bien" + "".join(f"\n  FALLA: {f}" for f in fallas))
    ciego = lambda *a: [x for x in historial(*a) if " · - " not in x]       # falla sembrada: no ve lo borrado
    atrapada = len(casos(ciego)) > 0
    print(f"  falla sembrada (historial que no ve lo borrado): {'✅ atrapada' if atrapada else '🔴 NO atrapada'}")
    return 0 if not fallas and atrapada else 1


if __name__ == "__main__":
    sys.exit(selftest() if "--selftest" in sys.argv else main(sys.argv[1:]))
