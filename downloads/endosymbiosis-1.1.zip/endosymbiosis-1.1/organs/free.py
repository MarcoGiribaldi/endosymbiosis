#!/usr/bin/env python3
"""
free.py — Endosimbiosis v1. La llave de la persona: abre las carpetas vedadas por unos minutos.

Qué hace. `free.py 30` deja pasar durante 30 minutos lo que el guardián frena por carpeta vedada (~/.ssh, ~/.secretos y
las de organs/denied.txt), para que la persona trabaje ahí con la IA mirando. La jaula (organs/ y los hooks) no se
abre: cambia solo por parche, con o sin llave (Marco D223: «que la llave no abra la jaula»). La regla 1 (nada se borra) tampoco: con
llave, un borrado sigue siendo «usa quarantine.py» (Marco D223: «si hay un rm, se va a _borrar, siempre»). `free.py end` la
cierra antes. Vence sola.

Por qué la IA no puede abrirla. La llave es un archivo con la hora de vencimiento en un lugar que solo el
administrador escribe:
  Linux y Mac: /var/run/endosimbiosis-libre, de root; se escribe con sudo (pide tu clave) y desaparece al reiniciar.
  Windows:     %ProgramData%\\Endosimbiosis\\libre.txt; hay que abrir la terminal «como administrador», y free.py deja
               esa carpeta con dueño Administradores y solo lectura para los demás.
El guardián la acepta solo si él mismo NO puede crear archivos en esa carpeta (lo prueba cada vez) y, en Linux y Mac,
si el archivo es de root. Una llave que la IA pudiera escribir no vale.

Qué cuida del trato: que la regla 1 (nada se borra y la jaula no se toca) quede siempre en pie y que abrir una vedada lo decida la persona, con su clave.
Su límite: si la IA corre como administrador (root, o una terminal elevada en Windows) puede escribir la llave: no
abras tu IA como administrador. La parte de Windows NO está probada en una máquina real (sin verificar). Tope: 8 horas.
Cómo se prueba: python organs/free.py --selftest (una llave que escribe la IA no vale; una vencida tampoco).
Uso: python organs/free.py 30   ·   python organs/free.py end   ·   python organs/free.py   (dice si hay llave)
"""
import sys, os, time, subprocess, tempfile
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

TOPE = 8 * 3600
if os.name == "nt":
    CARPETA = Path(os.environ.get("ProgramData", r"C:\ProgramData")) / "Endosimbiosis"
    LLAVE = CARPETA / "libre.txt"
else:
    CARPETA, LLAVE = Path("/var/run"), Path("/var/run/endosimbiosis-libre")


def segura(llave):
    """La llave vale solo si este programa no puede crear archivos junto a ella (y, fuera de Windows, si es de root)."""
    if os.name != "nt" and llave.stat().st_uid != 0:
        return False
    try:
        fd, prueba = tempfile.mkstemp(dir=llave.parent, prefix=".prueba-libre-")
    except OSError:
        return True
    os.close(fd)
    os.remove(prueba)                       # el único archivo que se quita es la prueba que este mismo programa creó
    return False


def vigente(llave=LLAVE, es_segura=segura):
    """Hasta cuándo vale la llave (segundos desde 1970), o None si no hay, venció o no es segura."""
    try:
        hasta = float(llave.read_text(encoding="utf-8").strip() or 0)
        if not es_segura(llave):
            return None
    except (OSError, ValueError):
        return None
    return hasta if time.time() < hasta <= time.time() + TOPE else None


def escribir(texto):
    if os.name == "nt":
        import ctypes
        if not ctypes.windll.shell32.IsUserAnAdmin():
            print("Abre PowerShell como administrador (clic derecho → «Ejecutar como administrador») y corre esto otra vez.")
            return False
        CARPETA.mkdir(exist_ok=True)
        for args in (["/setowner", "*S-1-5-32-544"], ["/inheritance:r", "/grant:r", "*S-1-5-32-544:(OI)(CI)F",
                                                       "*S-1-5-18:(OI)(CI)F", "*S-1-5-32-545:(OI)(CI)RX"]):
            subprocess.run(["icacls", str(CARPETA), *args], check=True, capture_output=True)
        LLAVE.write_text(texto, encoding="utf-8")
        return True
    r = subprocess.run(["sudo", "tee", str(LLAVE)], input=texto + "\n", text=True, stdout=subprocess.DEVNULL)
    return r.returncode == 0


def main(args):
    if not args:
        h = vigente()
        print(f"🔓 llave libre abierta hasta las {time.strftime('%H:%M', time.localtime(h))}" if h else "🔒 sin llave: el guardián cuida las dos reglas")
        return 0
    if args[0] == "end":
        ok = escribir("0")
        print("🔒 llave cerrada: el guardián vuelve a cuidar las dos reglas" if ok else "no pude cerrarla (¿sin clave?)")
        return 0 if ok else 1
    try:
        minutos = int(args[0])
    except ValueError:
        print(f"dime los minutos con un número, entre 1 y {TOPE // 60}: free.py 30")
        return 1
    if not 0 < minutos * 60 <= TOPE:
        print(f"entre 1 y {TOPE // 60} minutos")
        return 1
    hasta = time.time() + minutos * 60
    if not escribir(str(hasta)):
        print("no se abrió la llave (hace falta tu clave de administrador)")
        return 1
    print(f"🔓 llave libre abierta hasta las {time.strftime('%H:%M', time.localtime(hasta))}. La regla 1 sigue: nada se borra.")
    return 0


def selftest():
    d = Path(tempfile.mkdtemp(prefix="libre_"))
    llave = d / "llave"
    fallas = []
    def caso(nombre, cond):
        if not cond:
            fallas.append(nombre)
    llave.write_text(str(time.time() + 600), encoding="utf-8")
    caso("una llave que escribe la IA (carpeta suya) no vale", vigente(llave) is None)
    confiar = lambda p: True                       # como si la carpeta fuera de root
    caso("llave segura y vigente vale", vigente(llave, confiar) is not None)
    llave.write_text(str(time.time() - 1), encoding="utf-8")
    caso("llave vencida no vale", vigente(llave, confiar) is None)
    llave.write_text(str(time.time() + TOPE + 60), encoding="utf-8")
    caso("llave de más de 8 horas no vale", vigente(llave, confiar) is None)
    llave.write_text("abierta para siempre", encoding="utf-8")
    caso("llave ilegible no vale", vigente(llave, confiar) is None)
    caso("sin llave, nada", vigente(d / "no_existe", confiar) is None)
    import io, contextlib                                                                     # bloque 2: «free.py abc» avisa y no explota
    with contextlib.redirect_stdout(io.StringIO()) as salida:
        try:
            rc = main(["abc"])
        except Exception as e:
            rc = repr(e)
    caso("«free.py abc» se explica y sale con 1", rc == 1 and "número" in salida.getvalue())
    llave.write_text(str(time.time() + 600), encoding="utf-8")
    sembrada = vigente(llave, lambda p: True) is not None   # falla sembrada: un guardián que confía en cualquier archivo
    print(f"libre: {7 - len(fallas)}/7 casos bien" + "".join(f"\n  FALLA: {f}" for f in fallas))
    print(f"  falla sembrada (confiar en una llave de la IA): {'✅ atrapada' if sembrada and vigente(llave) is None else '🔴 NO atrapada'}")
    return 0 if not fallas and sembrada else 1


if __name__ == "__main__":
    sys.exit(selftest() if "--selftest" in sys.argv else main(sys.argv[1:]))
