#!/usr/bin/env python3
"""
daisy.py — Endosimbiosis v1. Transparencia: quién hizo qué, según git. Una sola pieza para todas las versiones.

Qué hace. Lee los commits desde el último cierre de la bóveda (la fecha [CLOSED más nueva; si no hay, 7 días) y cuenta:
cuántos llevan una IA coautora (línea `Co-Authored-By: <modelo> <correo>`), cuántos citan textual una decisión de la
persona («…» junto a su nombre), cuántos registran una revisión de otro modelo (no-autor), cuántos hizo la persona
sola (`[humano]`) y cuántos quedaron SIN ATRIBUCIÓN. Si hay uno solo sin atribución, frena el cierre (sale con 1).
Con --declaration escribe además el borrador de declaración DAISY (Ahmetoglu, Constantinides y Cox, CHIWORK '26)
en vault/daisy/<hoy>.md: lo que git muestra y lo que no puede mostrar (cuánto criterio humano entró: «sin medir»).
Es nuestra propuesta para Anna Cox (Marco D223: «DAISY se queda en ambos»).

Qué cuida del trato: que cada commit diga quién lo hizo (la IA firma; la persona lleva [humano]).
Salida cómoda (bloque 3): si un commit quedó sin firma y ya no es el último, un commit posterior que diga
`atribuye <hash>: …` y vaya firmado él mismo (Co-Authored-By o [humano]) da por atribuido ese hash (un hash por commit, y solo
si existe en la historia). Un commit de atribución sin firma no resuelve nada.
Su límite: solo ve lo que entra a git; el trabajo con IA fuera del repositorio no deja rastro aquí.
Cómo se prueba: python3 organs/daisy.py --selftest
Uso: python3 organs/daisy.py [--since AAAA-MM-DD] [--person Nombre] [--declaration [CARPETA]] [--root CARPETA]
"""
import sys, re, subprocess, datetime, tempfile, collections
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

AQUI = Path(__file__).resolve().parent
MODELO = re.compile(r"^Co-Authored-By:\s*(.+?)\s*<", re.I | re.M)
AUTOMATICO = re.compile(r"^(archivador:|ops-dispatch:|wip: auto-checkpoint|research-batch:)")   # commits de scripts del proyecto
ATRIBUYE = re.compile(r"^atribuye\s+([0-9a-f]{7,40})\b", re.I | re.M)          # «atribuye <hash>: …» en un commit firmado
TRAILER = re.compile(r"^(Co-Authored-By:|Claude-Session:)", re.I)
NO_AUTOR, FALTA = re.compile(r"no-autor|12\.d|12\(c\)", re.I), re.compile(r"pendiente|falta", re.I)
ACTIVIDADES = [("coding assistance", re.compile(r"\.(py|sh|js|ts|css|html|json|toml|service|timer)$")),
               ("literature search and summarisation", re.compile(r"(^|/)_research/")),
               ("writing and drafting", re.compile(r"\.md$"))]


def git(raiz, *args):
    try:
        r = subprocess.run(["git", "-C", str(raiz), *args], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120)
        return r.returncode, r.stdout
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return 127, ""


def desde_por_defecto(raiz, hoy):
    """La fecha del último cierre en la bóveda; si no hay, hace 7 días."""
    carpeta = raiz / "vault" / "closed" if (raiz / "vault" / "closed").is_dir() else raiz / "vault"
    fechas = [f for p in carpeta.rglob("*.md") for f in re.findall(r"\[CLOSED (\d{4}-\d{2}-\d{2})", p.read_text(encoding="utf-8", errors="replace"))]
    fechas = [f for f in fechas if f <= hoy.isoformat()]
    return max(fechas) if fechas else (hoy - datetime.timedelta(days=7)).isoformat()


def persona_de(raiz):
    t = (raiz / "core" / "profile.md").read_text(encoding="utf-8", errors="replace") if (raiz / "core" / "profile.md").exists() else ""
    m = re.search(r"Nombre[^:\n]*:\s*(?!\(por llenar)([A-ZÁÉÍÓÚÑ]\w+)", t) or re.search(r"^- \*\*([A-ZÁÉÍÓÚÑ]\w+)", t, re.M)
    return m.group(1) if m else ""


def cita_de(cuerpo, persona):
    """Una cita «…» atribuible a la persona: su nombre en los 40 caracteres antes o en los 30 después."""
    return bool(persona) and any(re.search(persona, cuerpo[max(0, m.start() - 40):m.start()] + cuerpo[m.end():m.end() + 30])
                                 for m in re.finditer(r"«[^»]{3,}»", cuerpo))


def revision_no_autor(cuerpo):
    texto = "\n".join(l for l in cuerpo.splitlines() if not TRAILER.match(l.strip()))
    return any(not FALTA.search(texto[m.end():m.end() + 20]) for m in NO_AUTOR.finditer(texto))


def medir(raiz, desde, persona):
    rc, out = git(raiz, "log", "--no-merges", f"--since={desde} 00:00",
                  "--format=%h%x1f%as%x1f%s%x1f%(trailers:key=Co-Authored-By,valueonly)%x1f%B%x1e")
    if rc != 0:
        return None
    m = {"total": 0, "ia": 0, "cita": 0, "revision": 0, "humano": 0, "sin": [], "modelos": collections.Counter(),
         "actividad": collections.Counter(), "fechas": []}
    atrib = []                                              # hashes que un commit posterior, firmado, dio por atribuidos
    for reg in out.split("\x1e"):
        partes = reg.strip("\n").split("\x1f")
        if len(partes) < 5:
            continue
        h, fecha, asunto, trailer, cuerpo = partes
        m["total"] += 1
        m["fechas"].append(fecha)
        if MODELO.search(cuerpo):
            m["ia"] += 1
            m["modelos"].update(x.strip() for x in MODELO.findall(cuerpo))
            m["cita"] += cita_de(cuerpo, persona)
            m["revision"] += revision_no_autor(cuerpo)
        if trailer.strip() or "[humano]" in cuerpo:
            a = ATRIBUYE.search(cuerpo)
            if a:
                atrib.append(a.group(1).lower())
        if trailer.strip() or AUTOMATICO.match(asunto):
            continue
        if "[humano]" in asunto or "[humano]" in cuerpo:
            m["humano"] += 1
        else:
            m["sin"].append(f"{h} {asunto[:100]}")
    m["sin"] = [s for s in m["sin"] if not any(s.split()[0].startswith(a) or a.startswith(s.split()[0]) for a in atrib)]
    rc, nombres = git(raiz, "log", "--no-merges", f"--since={desde} 00:00", "--name-only", "--format=@@%B%x1e")
    for reg in nombres.split("@@")[1:]:
        cuerpo, _, archivos = reg.partition("\x1e")
        if MODELO.search(cuerpo):
            m["actividad"].update({next((n for n, rx in ACTIVIDADES if rx.search(f)), "") for f in archivos.split()} - {""})
    return m


def pct(n, d):
    return f"{100 * n / d:.0f}%" if d else "-"


def declaracion(m, desde, hoy):
    f = sorted(m["fechas"])
    lineas = [f"# AI disclosure draft, generated from the project's git history (DAISY fields)", "",
              f"Period: {f[0] if f else desde} to {f[-1] if f else hoy} · {m['total']} commits · {m['ia']} with an AI co-author line ({pct(m['ia'], m['total'])}) "
              f"· {m['humano']} marked [humano] (the person alone) · {len(m['sin'])} without attribution.", "",
              "## What the record provides", "", "**Tools used** (from `Co-Authored-By` lines):"]
    lineas += [f"- {k}: {v} commits" for k, v in m["modelos"].most_common()]
    lineas += ["", "**Activities with evidence** (files touched in AI co-authored commits; the level is the author's call):"]
    lineas += [f"- {n}: {m['actividad'][n]} commits ({pct(m['actividad'][n], m['ia'])})" for n, _ in ACTIVIDADES]
    lineas += ["", "**Human validation steps:**",
               f"- {m['cita']} AI co-authored commits ({pct(m['cita'], m['ia'])}) quote the person's decision verbatim («…»).",
               f"- {m['revision']} ({pct(m['revision'], m['ia'])}) record a review by a different model (non-author review).", "",
               "## What the record does NOT provide (fill in by hand)", "",
               "- How much human judgement went into each commit: not measured (never 0).",
               "- Level of AI use per activity, ideation, prompts and data shared with the AI: not in git.",
               "- Work done with AI outside this repository leaves no trace here."]
    return "\n".join(lineas) + "\n"


def main(argv):
    raiz = Path(argv[argv.index("--root") + 1]).resolve() if "--root" in argv else AQUI.parent
    hoy = datetime.date.today()
    desde = argv[argv.index("--since") + 1] if "--since" in argv else desde_por_defecto(raiz, hoy)
    persona = argv[argv.index("--person") + 1] if "--person" in argv else persona_de(raiz)
    m = medir(raiz, desde, persona)
    if m is None:
        print("⚪ DAISY: no hay git o todavía no hay commits: no hay nada que declarar")
        return 2
    cita = pct(m["cita"], m["ia"]) if persona else "sin medir (no sé el nombre de la persona: --person)"
    print(f"🌼 DAISY desde {desde} · {m['total']} commits · IA coautora {pct(m['ia'], m['total'])} · decisión humana citada {cita} · "
          f"revisión no-autor {pct(m['revision'], m['ia'])} · [humano] {m['humano']} · sin atribución {len(m['sin'])}")
    print("   lo que git no puede mostrar: cuánto criterio humano entró en cada commit → sin medir")
    if "--declaration" in argv:
        i = argv.index("--declaration")
        carpeta = Path(argv[i + 1]) if len(argv) > i + 1 and not argv[i + 1].startswith("--") else raiz / "vault" / "daisy"
        carpeta.mkdir(parents=True, exist_ok=True)
        (carpeta / f"{hoy}.md").write_text(declaracion(m, desde, hoy), encoding="utf-8")
        print(f"   declaración: {carpeta / f'{hoy}.md'}")
    for s in m["sin"]:
        print(f"   🔴 sin atribución: {s}")
    if m["sin"]:
        print("   → FRENA el cierre: si lo hizo una IA, falta su Co-Authored-By; si lo hizo la persona sola, lleva [humano].")
        print("     Si no es el último commit: git commit --allow-empty -m \"atribuye <hash>: faltó la firma\" con su Co-Authored-By (o [humano]).")
        print("     Si es el último y la persona está presente, ella puede correr git commit --amend desde su terminal.")
        return 1
    print(f"   🟢 todo atribuido desde {desde}")
    return 0


def casos(medidor):
    d = Path(tempfile.mkdtemp(prefix="daisy_"))
    if git(d, "init", "-q")[0] == 127:
        return []
    c = ["-c", "user.name=p", "-c", "user.email=p@p"]
    def commit(msg):
        with open(d / "a.md", "a", encoding="utf-8") as f:
            f.write("x")
        git(d, *c, "add", "-A"); git(d, *c, "commit", "-qm", msg)
    commit("mapa de riego (Ana: «hazlo por lotes»)\n\nCo-Authored-By: Gemini 3.1 Pro <noreply@google.com>")
    commit("notas de campo [humano]")
    commit("archivador: índice")
    hoy = datetime.date.today().isoformat()
    fallas = []
    m = medidor(d, hoy, "Ana")
    if not m or (m["total"], m["ia"], m["cita"], m["humano"], len(m["sin"])) != (3, 1, 1, 1, 0):
        fallas.append(f"conteo con todo firmado: {m and (m['total'], m['ia'], m['cita'], m['humano'], m['sin'])}")
    commit("arreglo rápido")
    m = medidor(d, hoy, "Ana")
    if not m or len(m["sin"]) != 1:
        fallas.append("no vio el commit sin atribución")
    h = git(d, "rev-parse", "--short", "HEAD")[1].strip()
    commit(f"atribuye {h}: faltó la firma\n\nCo-Authored-By: Gemini 3.1 Pro <noreply@google.com>")
    m = medidor(d, hoy, "Ana")
    if not m or len(m["sin"]) != 0:
        fallas.append(f"un commit de atribución firmado no dio por atribuido el anterior: {m and m['sin']}")
    commit("arreglo 2")                                       # contracaso: una atribución SIN firma no resuelve nada
    h2 = git(d, "rev-parse", "--short", "HEAD")[1].strip()
    commit(f"atribuye {h2}: x")
    m = medidor(d, hoy, "Ana")
    if not m or len(m["sin"]) != 2:
        fallas.append(f"una atribución sin firma resolvió algo (o falló): {m and m['sin']}")
    commit(f"atribuye {h2}: ahora sí\n\nCo-Authored-By: Gemini 3.1 Pro <noreply@google.com>")      # firmada, pero solo da un hash: el otro sigue
    m = medidor(d, hoy, "Ana")
    if not m or len(m["sin"]) != 1:
        fallas.append(f"una atribución resolvió más de un hash o ninguno: {m and m['sin']}")
    return fallas


def selftest():
    fallas = casos(medir)
    print(f"daisy: {3 - len(fallas)}/3 casos bien" + "".join(f"\n  FALLA: {f}" for f in fallas))
    def ciego(*a):                                            # falla sembrada: un DAISY que nunca ve commits sin firma
        m = medir(*a)
        return m and {**m, "sin": []}
    atrapada = len(casos(ciego)) > 0
    print(f"  falla sembrada (no ve los sin atribución): {'✅ atrapada' if atrapada else '🔴 NO atrapada'}")
    return 0 if not fallas and atrapada else 1


if __name__ == "__main__":
    sys.exit(selftest() if "--selftest" in sys.argv else main(sys.argv[1:]))
