# MIGRATE — cuando tu humano ya tenía un sistema

> Para la IA que lee esto. Úsalo cuando la carpeta donde se instaló Endosimbiosis ya tenía memoria propia: un arranque, perfiles, reglas, misiones (*workstream*), una bitácora o una bóveda de notas.
> La meta es **una cosa, un lugar** (*single source of truth*): al terminar, cada hecho vive en una sola nota y las demás apuntan a ella, sin perder nada de lo viejo.
> Tu humano te ve trabajar, pero **no tiene que supervisarte paso a paso**. Le preguntas todo junto al principio, haces lo reversible por tu cuenta y al final le entregas un informe con lo que espera su palabra.
> **Si lo de antes es una Endosimbiosis con los nombres en español** (`nucleo/`, `organos/`, `boveda/`, `planes/`, `_BORRAR/`), esto no es para ti: tu humano corre en su terminal `python3 install.py --migrate-names <carpeta>` desde este kit (el canario lo pide en 🔴), y después sigues aquí solo si además había otra memoria.
> Antes de empezar, lee `ENDOSYMBIOSIS.md` y `core/start.md`. En Windows escribe `python` donde diga `python3`. Escribe en el idioma de las notas de tu humano.

## 0 · Las preguntas, todas juntas y una sola vez
Antes de tocar nada, haz estas cuatro preguntas en un solo mensaje y espera la respuesta:
1. ¿Cuáles son los **1 a 3 proyectos en foco** hoy?
2. ¿Qué carpetas o archivos son **privados** (clientes, datos personales, finanzas)? Esas rutas las anota tu humano en `organs/denied.txt`, no tú. En prosa (*modo pasivo*), las anota y corre `python3 install.py --guardian off` para que el canario (*startup integrity check*) tome la huella (*integrity hash*) de nuevo; en código (*modo enforcing*), corre `python3 install.py --open`, las anota y corre `python3 install.py --close`. Si no lo hace, el canario sale en 🔴 por `organs/` cambiado: ese rojo no es tuyo, lo anotas en el informe y sigues.
3. ¿Existe una **copia afuera** (GitHub, nube, disco)? Tú no subes nada; solo lo anotas.
4. ¿Algo de lo viejo **no se toca**?

Si contesta pero deja una pregunta en blanco, o dice «decide tú», usa su valor seguro:
- foco → el que marque el sistema viejo como activo; si no hay uno claro, el FOCUS queda vacío y todas las misiones van a diferidos (*deferred item with trigger*);
- privado → lo que parezca privado por su nombre (§ 1);
- copia afuera → lo que diga `git remote -v`;
- no se toca → nada más que lo de la § 3.

Desde aquí no vuelves a preguntar: cada duda nueva va a la lista final y sigues.

## 1 · Inventario (solo lectura)
Escribe `plans/migracion-<AAAA-MM-DD>.md` con una tabla de cada lugar donde vive memoria. Columnas: ruta · qué guarda · ¿en git? · última modificación · qué repite de otro lugar · qué harás (según la tabla de abajo).
Si la carpeta es grande, lista primero y lee solo lo necesario para clasificar.
**Un archivo que parece privado por su nombre no se abre**: se anota su ruta y sigues. Cuentan como privados, sin importar mayúsculas ni tildes: `cliente`, `dni`, `padron`, `.env`, `.pem`, `id_rsa`, `clave`, `password`, `token`, `secreto`, `credencial`, `banco`, `factura`, y lo que haya nombrado tu humano en la pregunta 2.
Si la carpeta no tenía git (el instalador hizo `git init`), todo está «fuera de git»: el primer commit de la § 3 es la línea base. Si la carpeta está dentro de un repositorio más grande, trabajas solo en ella y lo dices en el informe.

## 2 · Qué haces con cada cosa (los valores seguros)
| Lo que encuentras | Lo que haces |
|---|---|
| **Arranque viejo** (`BOOTSTRAP.md`, un `README` de inicio) | Hay un solo arranque, `core/start.md`. El viejo se queda, con una primera línea: «Ya no es el arranque: ver `core/start.md` (<fecha>)». Sus rutas y scripts que sirvan, `context.md` los apunta. |
| **Perfil o contexto viejo** | Pasa al núcleo solo lo que una IA necesita en cada sesión, sobre tu humano y su oficio, con su procedencia: «(de CONTEXTO-USUARIO.md)». `profile.md` y `context.md` no pasan de unas 60 líneas cada una; lo demás se apunta. **Los datos de otras personas** (clientes, contactos, DNI) **no pasan**: anotas «hay datos de terceros en <archivo>:<línea>» sin repetirlos. El viejo se queda **congelado** (*read-only*), con una primera línea: «Congelado el <fecha>: lo vivo está en `core/profile.md`». No se vuelve a editar. |
| **Reglas propias** (`AGENTS.md`) | Se conservan. Si una choca con el trato (*operating policy*) (por ejemplo «borra los temporales»), no la borras: le agregas al lado «(choca con la regla 1 del trato: se aparta, no se borra)» y va a la lista final. Mientras tanto gana el trato. |
| **Notas técnicas estables** (doctrinas, convenciones) | Se quedan donde están. `context.md` las apunta, una línea por carpeta. |
| **Bóveda externa** (Obsidian u otra, fuera de la carpeta) y **lo que no se toca** | No se copia, no se mueve, no se edita, tampoco sus enlaces. `vault/INDEX.md` la apunta con su ruta. Si un enlace suyo apuntaba a algo que moviste, va a la lista final con la ruta vieja y la nueva. |
| **Bitácora de errores vieja** | Queda como histórico congelado (con la primera línea de «congelado»). Desde hoy, un fallo que importa va a `core/decisions.md`. Un registro que escribe un programa solo (un CSV, un log) no es memoria: se queda y `context.md` dice dónde está. |
| **Misiones del foco** | Una línea por misión en el FOCUS de `state.md`, con `plan:` apuntando a su archivo. Sus pendientes vivos pasan a `state.md` con ID y `m:`, como en la fila de pendientes sueltos. Los dos de fábrica del kit (P1 y C1) reciben `m:` de la primera misión del FOCUS, o bajan a la bóveda si ya se hicieron. |
| **Misiones fuera del foco** | No se cierran ni se reactivan: se quedan donde están. Si son diez o menos, una línea por misión en `plans/DEFERRED.md`: `- DEF-n · when: <persona> revisa si sigue · misión <NOMBRE> (<archivo>) · estado viejo: <el que tenía>`. Si son más de diez, **una sola línea**: `- DEF-n · until:<hoy + 30 días> · revisar las <N> misiones viejas · lista en plans/migracion-<fecha>.md`. Si su archivo dice `done` o `hecho`, va a `vault/INDEX.md` con `[CLOSED <fecha> · done · evidence: <archivo> dice estado: done]`. |
| **Pendientes sueltos** (una lista sin IDs) | Cada uno recibe un ID: `P` si lo hace tu humano, `C` solo si la nota dice que lo hace la IA. Lleva `m:<misión>`. Si ya tenía un ID viejo, lo anotas: «(era T-14)». Los marcados como hechos van a la bóveda con su evidencia. Si dos dicen lo mismo con casi las mismas palabras, queda uno y lo anotas en `decisions.md`; si podrían ser trabajos distintos, quedan los dos y la pareja va a la lista final. Los de misiones fuera del foco van a `DEFERRED.md` con `was:`. Un `due:` ya vencido entra con la marca `OVERDUE` y va al informe. La lista vieja queda congelada. |
| **Dos carpetas para lo mismo** (`MISIONES/` y `missions/`, `_Borrar/` y `_QUARANTINE/`) | Usa el nombre del kit (`_QUARANTINE`) o el que más se usa. Lo que está en git se mueve con `git mv`; lo que no, con `mv`. Si solo cambian las mayúsculas, hazlo en dos pasos con un nombre intermedio (Windows y Mac no distinguen mayúsculas). Si dos archivos chocan por nombre o por tema, **no los fusionas**: el que viene de la otra carpeta entra con el sufijo `_antes` y la pareja va a la lista final. Compara el hash de cada archivo movido antes y después (`git hash-object <archivo>` sirve en los tres sistemas). |
| **Un mismo dato en dos lugares** (teléfono, correo, umbral) | Su casa es una nota del núcleo, si es de tu humano. En las notas vivas lo cambias por «ver `core/<nota>`». En las congeladas lo dejas como está. |
| **Lo que está fuera de git** | Clasifícalo **sin abrirlo**: rastreable · temporal · pesado (más de 50 MB) · privado por su nombre · repositorio anidado. Agrega al `.gitignore` los temporales, los pesados, los privados y los anidados. |
| **Algo privado que ya está en git** | No lo abres ni lo sacas: sacarlo de la historia es reescribirla. Va a la lista final: «<ruta> está en la historia de git». |
| **Una copia afuera** (remoto de git) | `git fetch` sí, porque solo lee. Push, pull y merge, no. Si la historia del remoto no tiene relación con la local (`git merge-base` falla), lo anotas en la lista final. |

## 3 · Aplicar
Primero, un commit solo con lo que puso el instalador: los órganos (*deterministic guardrail*), `core/`, `vault/`, `plans/`, `install.py`, `README.md`, `ENDOSYMBIOSIS.md`, `MIGRATE.md`, `.gitignore` y los cambios del instalador en `AGENTS.md` o `CLAUDE.md`. Agregar los órganos a git **no es tocarlos**: tocar es escribir dentro. En el mensaje del commit escribe «los órganos», no la ruta de su carpeta (en modo código, el guardián (*PreToolUse hook*) frena escrituras en la jaula (*immutable files*): editar, `>`, `chattr`; no frena mensajes de commit). Así el canario cuida el kit desde el principio y tus cambios quedan aparte.

Después aplica en tandas chicas: nombres, después arranque y perfil, misiones y pendientes, enlaces, y al final `.gitignore`. Tus archivos de trabajo (listas de hashes, borradores) van dentro de `plans/`, nunca fuera de la carpeta.
- Después de cada tanda: `python3 organs/canary.py`.
- Después, un commit local que nombra los archivos uno por uno. Nunca `git add -A` ni `git add .`. El commit va firmado con `Co-Authored-By: <tu modelo> <noreply@…>`.
- Corrige los enlaces **dentro de esta carpeta** que apuntaban a lo que moviste. Los textos que cuentan algo del pasado los dejas como están.

**Te detienes y avisas solo si pasa una de estas tres cosas:**
- el canario sale en 🔴 por algo que hiciste tú en esta migración (*legacy memory integration*) y no lo puedes revertir con git (un 🔴 heredado, como un `due:` vencido o `organs/` cambiado por tu humano, no te detiene: va al informe);
- necesitas abrir algo privado;
- la única salida sería borrar.

En cualquier otra duda, eliges el valor seguro, la anotas y sigues.

**Nunca:** borrar (lo que sobra se aparta (*quarantine*) con `python3 organs/quarantine.py <ruta> <motivo>`) · escribir dentro de `organs/` · abrir lo privado · cambiar el foco · cerrar o reactivar una misión que no diga «hecho» · subir nada a un remoto.

## 4 · El informe final
Al terminar, corre `python3 organs/canary.py` y `python3 organs/daisy.py`, y escríbele a tu humano en un solo mensaje:
- **Qué se movió, qué se enlazó, qué quedó congelado.** Una línea cada uno, con cifras (cuántos archivos, hashes iguales sí o no).
- **Cómo quedó:** la salida del canario y de DAISY (*AI disclosure*) en una línea.
- **Espera tu palabra:** la lista de dudas, una por línea, en palabras, **cada una con tu voto** («mi voto: X porque Y»), también cuando preguntas a qué misión va algo: propón una. Ahí van los choques del trato, las parejas `_antes`, las misiones diferidas que conviene revisar primero, la copia afuera, lo privado que encontraste y los enlaces de afuera que quedaron viejos.
- **Qué no hiciste y por qué.**

Agrega una línea en `core/decisions.md`: «Migración del sistema anterior (<fecha>): <cifras>; dudas en `plans/migracion-<fecha>.md`».
