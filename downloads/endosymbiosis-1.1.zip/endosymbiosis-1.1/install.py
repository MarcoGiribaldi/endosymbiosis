#!/usr/bin/env python3
"""
install.py — Endosimbiosis 1.1. Lo corre la PERSONA, no la IA. Cinco pasos, y nunca borra nada.

(Los comandos están con python3, que es el nombre en Mac y Linux. En Windows escribe python.)
  python3 install.py                     instala en la carpeta donde está este archivo
  python3 install.py C:/proyectos/mi-nucleo
  python3 install.py --yes               no pregunta (para repetir la instalación; el guardián queda en prosa)
  python3 install.py --guardian on       pasa el guardián a CÓDIGO: registrado, frena a la IA antes de cada acción, con candado
  python3 install.py --guardian off      lo pasa a PROSA (sus reglas escritas, sin frenar); otra vez en prosa = «lo vi, sigo en prosa»
  python3 install.py --open              quita el candado de organs/ (para reinstalar, editar denied.txt o checks.txt, o un parche)
  python3 install.py --close             lo vuelve a poner y lo comprueba
  python3 install.py --hook              solo pone (o repone) el hook pre-commit de git que llama a organs/secret_scan.py
  python3 install.py --uninstall         quita lo que puso la instalación (antes de mover o borrar la carpeta); pide escribir «quitar» (o remove)
  python3 install.py --migrate-names <carpeta>   D230: un núcleo con los nombres de antes (en español) pasa a los de ahora
                                         (core/, organs/, vault/, plans/, _QUARANTINE/…); nunca borra. Ver migrar_nombres().
Las respuestas: si / yes / y para aceptar; codigo / code para el guardián en código.

Los cinco pasos:
  1. Revisa: Python, git, Claude Code, Antigravity y Codex; y si ya tienes un sistema (núcleo, órganos u otro guardián),
     lo dice y no lo toca sin preguntarte.
  2. Copia: el núcleo de 8 notas (solo si no tienes uno), los órganos, plans/, vault/ y crea _QUARANTINE/. Si hay git, pone el hook
     pre-commit que llama a organs/secret_scan.py (la segunda puerta del guardián: una llave, una contraseña o un DNI no entran a un commit).
     Si ya tenías otro hook pre-commit, lo guarda en _QUARANTINE/ y lo deja como pre-commit.anterior: el nuevo lo llama primero.
  3. El modo del guardián (1.0.3). PROSA, por defecto: el guardián se copia pero no se registra; sus reglas quedan escritas
     (AGENTS.md y core/agreement.md) y el canario toma la huella de organs/ y mira los borrados que no pasaron por _QUARANTINE/.
     CÓDIGO: lo registra a nivel de USUARIO, en Claude Code (~/.claude/settings.json, con "onFailure": "block" desde la
     versión 2.1.295), en Antigravity (~/.gemini/config/hooks.json) y, si tienes Codex, en ~/.codex/hooks.json (1.1; Codex
     pide aprobarlo una vez con /hooks): vigila en cualquier carpeta donde abras la IA. Si esos
     archivos ya existen, pregunta antes y guarda una copia del anterior en _QUARANTINE/<hoy>-instalacion/.
  4. Prueba: cada órgano con su --selftest (también secretos), y el nacimiento: `quarantine.py` tiene que mover un archivo a _QUARANTINE/ y,
     en código, el guardián registrado tiene que frenar un borrado de prueba.
  5. Listo: en código, pone el candado del sistema sobre organs/ (Linux: chattr +i con tu clave, es un muro; Mac: chflags uchg y
     Windows: attrib +r, que son un seguro de puerta: los quita el mismo usuario), te pide activar las instantáneas de tu sistema, anotar tus carpetas privadas en organs/denied.txt
     (a mano: la IA no puede escribir ese archivo) y te dice cómo empezar.
"""
import sys, os, re, json, shutil, subprocess, datetime, importlib.util
from pathlib import Path

sys.dont_write_bytecode = True                          # con candado, organs/ no puede tener __pycache__

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

KIT = Path(__file__).resolve().parent
HOY = datetime.date.today().isoformat()
HOME = Path.home()
PY = "python" if os.name == "nt" else "python3"           # el nombre con el que esta persona corre Python (como hace el guardián con APARTAR)
SI = "--yes" in sys.argv
ONFAILURE_DESDE = (2, 1, 295)                             # Claude Code: con "onFailure": "block", un guardián que vence o falla frena
INI, FIN = "<!-- endosimbiosis:inicio -->", "<!-- endosimbiosis:fin -->"
MANUAL = ("symbiosis-manual/Simbiosis_2.1_Marco_Giribaldi.md", "symbiosis-manual/Symbiosis_2.1_Marco_Giribaldi.md")   # D231: el libro, para consulta
CODEX_HOOKS = "Codex: abre Codex en esta carpeta y aprueba el guardián con /hooks (una vez; si el guardián cambia, otra vez)"
BLOQUE = f"""{INI}
## Endosimbiosis v1
Antes de hacer nada, lee `core/start.md` y síguelo. La guía está en `ENDOSYMBIOSIS.md`.
El porqué del método está en el manual de Simbiosis 2.1, en `symbiosis-manual/` (español e inglés). La primera vez, antes de armar el núcleo con tu humano, léelo entero en su idioma; en los arranques siguientes no se carga: se consulta cuando una regla o un paso no se entiende.
Los órganos están en `organs/` (guardián `guardian.py`, apartar `quarantine.py`, libre `free.py`, canario `canary.py`, buscador `search.py`, DAISY `daisy.py`; y `secret_scan.py`, que git llama antes de cada commit). Los cambia solo tu humano; tú no.
Una llave, una contraseña o un DNI no entran a un commit: si `secret_scan.py` frena el tuyo, díselo a tu humano; no uses `--no-verify`.
Las reglas del guardián: no borras (apartas), no reescribes la historia de git, no entras a ~/.ssh, ~/.secretos ni a las carpetas de `organs/denied.txt`, no escribes en `organs/`, en `.endo/guardian_modo.json` (la huella del modo prosa, en prosa y sin candado) ni en los hooks, y no saltas el filtro de secretos. En prosa (el modo por defecto) nadie te frena: las cumples tú, y el canario mira si se rompió alguna. En código, además te frena: si te frena, no busques otro camino; lee su motivo y díselo a tu humano.
Nada se borra: `{PY} organs/quarantine.py <ruta> <motivo>` lo mueve a `_QUARANTINE/`. Antes de decir «no existe»:
`{PY} organs/search.py "palabra|sinónimo"`.
{FIN}
"""


def decir(s=""):
    print(s, flush=True)


def preguntar(texto):
    if SI:
        return True
    return input(f"   {texto} Escribe si (o yes) y Enter: ").strip().lower() in ("si", "sí", "s", "yes", "y")


def copia_de_respaldo(destino, ruta, motivo="instalacion"):
    """Guarda una copia del archivo de antes en _QUARANTINE/<hoy>-<motivo>/ (no lo mueve: el original sigue)."""
    aparte = destino / "_QUARANTINE" / f"{HOY}-{motivo}"
    aparte.mkdir(parents=True, exist_ok=True)
    final = aparte / (ruta.as_posix().strip("/").replace("/", "__").replace(":", ""))
    shutil.copy2(ruta, final)
    return final


def comando_guardian(destino):
    g = (destino / "organs" / "guardian.py").as_posix()
    if os.name == "nt":                                   # probado en Windows con agy (D168): sin comillas, barras /
        return f"python -B {g}"
    py = sys.executable
    return f'"{py}" -B "{g}"' if " " in py + g else f"{py} -B {g}"


def usuario():
    """Los archivos de ganchos de USUARIO donde el guardián se registra: Claude Code, Antigravity y Codex (1.1)."""
    return (HOME / ".claude" / "settings.json", HOME / ".gemini" / "config" / "hooks.json", HOME / ".codex" / "hooks.json")


def hay_codex():
    """¿Esta persona usa Codex? Está en el PATH o ya tiene ~/.codex/ (1.1)."""
    return bool(shutil.which("codex")) or (HOME / ".codex").is_dir()


def version_claude():
    """La versión de Claude Code como tupla (2, 1, 316), o None si no está o no se entiende."""
    if not shutil.which("claude"):
        return None
    rc, out = correr(["claude", "--version"], KIT, timeout=30)
    m = re.search(r"(\d+)\.(\d+)\.(\d+)", out) if rc == 0 else None
    return tuple(int(x) for x in m.groups()) if m else None


def con_onfailure():
    """¿Se puede poner "onFailure": "block"? Solo con Claude Code 2.1.295 o más nuevo (https://code.claude.com/docs/en/hooks)."""
    v = version_claude()
    if v and v >= ONFAILURE_DESDE:
        return True
    decir(f"   ⚪ Claude Code {'.'.join(map(str, v)) if v else '(no encuentro su versión)'}: no pongo \"onFailure\": \"block\" (pide la 2.1.295"
          f" o más nueva; sin él, un guardián que falla o se cuelga deja pasar). Cuando lo actualices: {PY} install.py --guardian on")
    return False


def entradas(datos, cmd):
    """Las entradas de hook de Claude Code (PreToolUse) que corren exactamente este comando."""
    grupos = (datos.get("hooks") or {}).get("PreToolUse") if isinstance(datos.get("hooks"), dict) else None
    return [h for g in (grupos if isinstance(grupos, list) else []) if isinstance(g, dict)
            for h in (g.get("hooks") if isinstance(g.get("hooks"), list) else []) if isinstance(h, dict) and h.get("command") == cmd]


class NoEsObjeto(ValueError):
    """Un archivo de hooks con JSON válido que no es un objeto ({…}): [], null, "hola" (Fable 1.1 H6)."""


AVISADOS = set()                                          # cada archivo raro se avisa una vez, no en cada lectura


def leer_hooks(archivo):
    """El JSON de un archivo de hooks, como objeto. ValueError si no se puede leer; NoEsObjeto (también ValueError: los que
    escriben lo tratan como ilegible y no lo tocan) si es JSON pero no un objeto."""
    datos = json.loads(archivo.read_text(encoding="utf-8") or "{}")
    if not isinstance(datos, dict):
        raise NoEsObjeto(f"{archivo} es JSON pero no un objeto ({type(datos).__name__})")
    return datos


def ganchos(destino, home=None):
    """1.1 (idea de un usuario, entrega 2b: un instalador ajeno le desconectó un gancho sin avisar): todos los ganchos que hay hoy,
    en Claude Code, Antigravity y Codex (del usuario y de esta carpeta) y en git. Solo lee; un archivo ilegible cuenta como un gancho."""
    home, vistos = Path(home or HOME), set()
    for toml in (home / ".codex" / "config.toml", destino / ".codex" / "config.toml"):    # Codex (1.1): [hooks] en config.toml
        try:
            seccion = ""
            for l in (toml.read_text(encoding="utf-8").splitlines() if toml.exists() else []):
                m = re.match(r"\s*\[\[?\s*([^\]]+?)\s*\]\]?", l)
                seccion = m.group(1) if m else seccion
                c = None if m else re.match(r"\s*command\s*=\s*(.+?)\s*$", l)
                if c and seccion.startswith("hooks."):
                    vistos.add(f"Codex · {seccion.split('.')[1]} · {c.group(1).strip(chr(39) + chr(34))}")
        except OSError:
            vistos.add(f"Codex · {toml} (no se puede leer)")
    for casa, archivo in (("Claude Code", home / ".claude" / "settings.json"), ("Claude Code", destino / ".claude" / "settings.json"),
                          ("Antigravity", home / ".gemini" / "config" / "hooks.json"), ("Antigravity", destino / ".agents" / "hooks.json"),
                          ("Codex", home / ".codex" / "hooks.json"), ("Codex", destino / ".codex" / "hooks.json")):
        if not archivo.exists():
            continue
        try:
            datos = leer_hooks(archivo)
        except NoEsObjeto as e:                           # sin ganchos, y se dice una vez (Fable 1.1 H6)
            if str(archivo) not in AVISADOS:
                AVISADOS.add(str(archivo))
                decir(f"   ⚪ {e}: lo cuento como sin ganchos y no lo toco")
            continue
        except (ValueError, OSError):
            vistos.add(f"{casa} · {archivo} (no se puede leer)")
            continue
        grupos = datos.get("hooks") if casa != "Antigravity" else datos           # Codex tiene la forma de Claude Code
        for nombre, eventos in (grupos.items() if isinstance(grupos, dict) else []):
            pares = [(nombre, eventos)] if casa != "Antigravity" else (eventos.items() if isinstance(eventos, dict) else [])
            for evento, lista in pares:
                for g in (lista if isinstance(lista, list) else []):
                    for h in ((g.get("hooks") or []) if isinstance(g, dict) else []):
                        if isinstance(h, dict):
                            vistos.add(f"{casa} · {evento} · {h.get('command', '?')}")
    rc, ruta = correr(["git", "rev-parse", "--git-path", "hooks"], destino)
    carpeta = (destino / ruta.strip()) if rc == 0 and ruta.strip() else None
    if carpeta and carpeta.is_dir():
        vistos |= {f"git · {h.name}" for h in carpeta.iterdir() if h.is_file() and not h.name.endswith(".sample")}
    return vistos


def revisar_ganchos(antes, destino, home=None):
    """Compara los ganchos de antes con los de ahora. Devuelve False si se cayó alguno (lo dice en 🔴)."""
    ahora = ganchos(destino, home)
    faltan, nuevos = sorted(antes - ahora), sorted(ahora - antes)
    for f in faltan:
        decir(f"   🔴 este gancho estaba antes de instalar y ya no está: {f[:150]}")
    if faltan:
        decir("   → Revísalo antes de seguir: la copia de cada archivo que toqué está en _QUARANTINE/.")
        return False
    decir("   ✅ ganchos: " + ((f"los {len(antes)} que ya tenías siguen" if len(antes) > 1 else "el que ya tenías sigue") if antes else "no tenías ninguno")
          + (f"; agregué {len(nuevos)}: {que_agregue(nuevos)}" if nuevos else ""))
    return True


def que_agregue(nuevos):
    """Los ganchos nuevos, en palabras (Fable 1.1 H5: en prosa decía «el guardián y el de secretos» y solo estaba el de secretos)."""
    y = lambda xs: ", ".join(xs[:-1]) + " y " + xs[-1] if len(xs) > 1 else "".join(xs)
    guardian = sorted({n.split(" · ")[0] for n in nuevos if "organs/guardian.py" in n.replace("\\", "/")})
    partes = [f"el guardián en {y(guardian)}"] if guardian else []
    for n in sorted(n for n in nuevos if "organs/guardian.py" not in n.replace("\\", "/")):
        partes.append("el de secretos (git pre-commit)" if n == "git · pre-commit" else   # tu pre-commit de antes sigue: lo llama el nuevo
                      "el de secretos en tu git pre-commit, que corre primero el tuyo de antes (ahora pre-commit.anterior)"
                      if n == "git · pre-commit.anterior" else n[:80])
    return "; ".join(partes)


def registrar(destino, archivo, casa):
    """Agrega el guardián al archivo de hooks de usuario de Claude Code, de Antigravity o de Codex, sin quitar nada de lo que hay."""
    cmd = comando_guardian(destino)
    datos = {}
    if archivo.exists():
        try:
            datos = leer_hooks(archivo)
        except ValueError:
            decir(f"   ⚪ {archivo} no se puede leer: no lo toco. Agrega a mano este hook: {cmd}")
            return False
        if cmd in json.dumps(datos):
            sin_bloqueo = [h for h in entradas(datos, cmd) if h.get("onFailure") != "block"] if casa == "Claude Code" else []
            if sin_bloqueo and con_onfailure():                  # 1.0.3: un registro de antes, sin "onFailure": "block"
                decir(f"   copia del anterior en {copia_de_respaldo(destino, archivo)}")
                for h in sin_bloqueo:
                    h["onFailure"] = "block"
                archivo.write_text(json.dumps(datos, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
                decir(f"   ✅ {casa}: el guardián ya estaba registrado; le agregué \"onFailure\": \"block\" (si falla o se cuelga, frena)")
                return True
            decir(f"   ✅ {casa}: el guardián ya estaba registrado en {archivo}")
            return True
        otros = [h for h in json.dumps(datos).split('"command": ')[1:] if "guardia" in h.lower() or "jaula" in h.lower()]
        if otros:
            decir(f"   ⚪ {casa}: ya tienes otro guardián o jaula registrado; lo dejo como está (los dos van a frenar)")
        if not preguntar(f"{casa}: ¿agrego el guardián a {archivo}? (guardo una copia del anterior en _QUARANTINE/)"):
            decir(f"   ⚪ no lo toqué. Para hacerlo a mano, agrega un hook PreToolUse con matcher \"*\" y comando: {cmd}")
            return False
        decir(f"   copia del anterior en {copia_de_respaldo(destino, archivo)}")
    hook = {"matcher": "*", "hooks": [{"type": "command", "command": cmd, "timeout": 15}]}
    if casa == "Codex":                                   # 1.1: misma forma que Claude Code; timeout en segundos; "*" = todas las herramientas
        hook["hooks"][0]["statusMessage"] = "Endosimbiosis: guardián"
        datos.setdefault("hooks", {}).setdefault("PreToolUse", []).append(hook)
    elif casa == "Claude Code":
        if con_onfailure():
            hook["hooks"][0]["onFailure"] = "block"
        datos.setdefault("hooks", {}).setdefault("PreToolUse", []).append(hook)
    else:
        datos["endosimbiosis-guardian"] = {"PreToolUse": [hook]}
    archivo.parent.mkdir(parents=True, exist_ok=True)
    archivo.write_text(json.dumps(datos, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    decir(f"   ✅ {casa}: guardián registrado en {archivo} (vale para todas tus carpetas)")
    return True


def ruta_guardian(cmd):
    """La ruta de organs/guardian.py que nombra un comando de hook (con o sin comillas), o None."""
    m = re.search(r'"([^"]*organs/guardian\.py)"|(\S*organs/guardian\.py)', cmd)
    return (m.group(1) or m.group(2)) if m else None


def es_nuestro(cmd, propio):
    """¿Este hook es el guardián de ESTA carpeta (con cualquier Python), o el de una carpeta de Endosimbiosis que ya no
    existe? Nunca uno ajeno."""
    if cmd == propio:
        return True
    ruta, mia = ruta_guardian(cmd), ruta_guardian(propio)
    if not ruta:
        return False
    return not Path(ruta).exists() or bool(mia) and Path(ruta).resolve() == Path(mia).resolve()


def limpiar(datos, propio):
    """Saca de un archivo de hooks ya leído (Claude Code o Antigravity) las entradas del guardián propio o muerto.
    Cambia `datos` y devuelve los comandos quitados. Lo que no es nuestro queda igual."""
    quitados = []
    for nombre in ("hooks", "endosimbiosis-guardian"):          # Claude Code · Antigravity
        dueno = datos.get(nombre)
        grupos = dueno.get("PreToolUse") if isinstance(dueno, dict) else None
        if not isinstance(grupos, list):
            continue
        vaciados = []
        for g in grupos:
            hs = g.get("hooks") if isinstance(g, dict) else None
            if not isinstance(hs, list):
                continue
            fuera = [h for h in hs if isinstance(h, dict) and es_nuestro(str(h.get("command", "")), propio)]
            if fuera:
                quitados += [h["command"] for h in fuera]
                g["hooks"] = [h for h in hs if not any(h is f for f in fuera)]
                if not g["hooks"]:
                    vaciados.append(g)
        if vaciados:                                          # solo se quita lo que quedó vacío por nosotros
            dueno["PreToolUse"] = [g for g in grupos if not any(g is v for v in vaciados)]
            if not dueno["PreToolUse"]:
                del dueno["PreToolUse"]
                if not dueno:
                    del datos[nombre]
    return quitados


def desinstalar(destino):
    """Quita lo que puso la instalación: el guardián de esta carpeta (o de una que ya no existe) en los hooks de usuario,
    el hook pre-commit de secretos (vuelve pre-commit.anterior) y el candado. Lo corre la PERSONA en su terminal:
    muestra qué va a quitar y pide escribir «quitar» (no vale --yes, y sin una terminal de verdad no corre)."""
    decir("🌱 Endosimbiosis 1.1 — quitar")
    if not sys.stdin.isatty():
        decir("🔴 Esto lo corre la persona en su propia terminal, no la IA: abre una terminal y escribe el comando tú."); return 1
    propio, plan = comando_guardian(destino), []
    for archivo in usuario():
        if not archivo.exists():
            continue
        try:
            datos = leer_hooks(archivo)
        except ValueError:
            decir(f"   ⚪ {archivo} no se puede leer: no lo toco (busca a mano la línea con organs/guardian.py)"); continue
        quitados = limpiar(datos, propio)
        if quitados:
            plan.append((archivo, datos))
            for q in quitados:
                falta = ruta_guardian(q) and not Path(ruta_guardian(q)).exists()
                decir(f"   se quita de {archivo}: {q}" + (" (esa carpeta no existe ahora; si está en un disco desconectado, conéctalo antes)" if falta else ""))
    hook = anterior = None
    if shutil.which("git") and (destino / ".git").exists():
        rc, ruta = correr(["git", "rev-parse", "--git-path", "hooks/pre-commit"], destino)
        h = (destino / ruta.strip().splitlines()[0]).resolve() if rc == 0 and ruta.strip() else None
        if h and h.exists() and MARCA_HOOK in h.read_text(encoding="utf-8", errors="replace"):
            hook, anterior = h, h.with_name("pre-commit.anterior")
            decir(f"   se aparta el hook de secretos {hook}" + (" y vuelve tu pre-commit de antes" if anterior.exists() else ""))
    abrir = (destino / "organs").is_dir() and con_candado(destino)
    if abrir:
        decir("   se quita el candado de organs/")
    if not plan and not hook and not abrir:
        decir("   ✅ no hay nada de Endosimbiosis puesto para esta carpeta (ni de carpetas que ya no existen)"); return 0
    if input("   Escribe quitar y Enter para hacerlo: ").strip().lower() not in ("quitar", "remove"):
        decir("   No toqué nada."); return 0
    for archivo, datos in plan:
        decir(f"   copia del anterior en {copia_de_respaldo(destino, archivo, 'desinstalacion')}")
        archivo.write_text(json.dumps(datos, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if hook:
        aparte = destino / "_QUARANTINE" / f"{HOY}-desinstalacion"
        aparte.mkdir(parents=True, exist_ok=True)
        shutil.move(str(hook), str(aparte / f"pre-commit-{datetime.datetime.now():%H%M%S}"))
        if anterior.exists():
            anterior.replace(hook)
    if abrir and not candado(destino, False, aviso=False):
        decir(f"   ✅ el guardián ya no está registrado, pero organs/ sigue con candado: quítalo ({PY} install.py --open) antes de moverla.")
        return 1
    decir("   ✅ listo: el guardián ya no está registrado para esta carpeta. Cierra y vuelve a abrir tu IA (lee sus hooks al")
    decir(f"   arrancar); después ya puedes mover o quitar la carpeta. Para volver a instalar, corre {PY} install.py desde donde quede.")
    return 0


def canario_del_kit():
    """El canario del kit (no el del destino, que puede no existir): lee el candado y guarda el modo y la huella."""
    spec = importlib.util.spec_from_file_location("canario_del_kit", KIT / "organs" / "canary.py")
    canario = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(canario)
    return canario


def con_candado(destino):
    """¿organs/ tiene el candado del sistema? Lo lee el canario (lsattr / ls -lO / attrib)."""
    try:
        c = canario_del_kit()
        return c.cerrado(c.atributos(carpeta_organos(destino) / "guardian.py"))[0]
    except Exception:
        return False


def registrado_aqui(destino):
    """¿El guardián de ESTA carpeta ya está registrado (Claude Code, Antigravity o Codex)? Entonces está en código."""
    g = (destino / "organs" / "guardian.py").as_posix()
    for archivo in usuario():
        try:
            if g in archivo.read_text(encoding="utf-8"):
                return True
        except OSError:
            pass
    return False


def elegir_modo(destino):
    """Paso 3 de la instalación: prosa (por defecto) o código. Devuelve True si es código. Si el guardián de esta carpeta ya
    está registrado (una 1.0.2, o una instalación repetida), sigue en código: el instalador no lo baja a prosa sin que se pida."""
    if registrado_aqui(destino):
        decir(f"   el guardián de esta carpeta ya está registrado: sigue en código (para pasarlo a prosa: {PY} install.py --guardian off)")
        return True
    decir("   El guardián tiene dos modos. PROSA (por defecto): sus reglas quedan escritas y la IA las cumple; no frena nada, y el")
    decir("   canario te avisa si se rompió una (algo borrado sin pasar por _QUARANTINE/, un cambio en organs/). CÓDIGO: además frena a la")
    decir("   IA antes de cada acción (Claude Code, Antigravity y Codex) y pone el candado en organs/. Se cambia cuando quieras: --guardian on / off.")
    if SI:
        decir("   modo: prosa (por defecto)")
        return False
    return input("   Enter = prosa · escribe codigo (o code) y Enter para que frene; prosa también vale: ").strip().lower() in ("codigo", "código", "code")


def cambiar_modo(destino, valor):
    """--guardian on|off. Lo corre la persona en su terminal, no la IA (sin una terminal de verdad no corre).
    si: registra el guardián (con onFailure si se puede), prueba que frena y pone el candado.
    no: lo quita de los hooks (solo el de esta carpeta o el de una que ya no existe), y toma la huella de organs/ y el punto de
    partida para ver borrados. Correrlo en prosa otra vez es «lo vi, sigo en prosa»: huella y punto de partida nuevos."""
    global SI
    if valor not in ("on", "off"):
        decir(f"uso: {PY} install.py --guardian on   (código: frena)   ·   {PY} install.py --guardian off   (prosa: reglas escritas)"); return 2
    decir(f"🌱 Endosimbiosis 1.1 — guardián en {'código' if valor == 'on' else 'prosa'}")
    if not sys.stdin.isatty():
        decir("🔴 Esto lo corre la persona en su propia terminal, no la IA: abre una terminal y escribe el comando tú."); return 1
    if not (destino / "organs" / "guardian.py").exists():
        decir(f"🔴 no hay organs/guardian.py en {destino}: primero instala ({PY} install.py)"); return 1
    canario = canario_del_kit()
    antes = canario.leer_modo(destino).get("modo")
    if valor == "on":
        SI = True                                              # la persona lo pidió: no vuelve a preguntar por cada archivo
        ok = [registrar(destino, HOME / ".claude" / "settings.json", "Claude Code")]
        if shutil.which("agy") or (HOME / ".gemini").exists():
            ok.append(registrar(destino, HOME / ".gemini" / "config" / "hooks.json", "Antigravity"))
        codex = hay_codex() and registrar(destino, HOME / ".codex" / "hooks.json", "Codex")
        ok.append(codex)
        if not any(ok):
            decir("🔴 el guardián no quedó registrado: sigue como estaba"); return 1
        canario.guardar_modo(destino, "codigo", "cambio a código")
        vive, lineas = canario.prueba_de_vida(destino)
        for l in lineas:
            decir("   " + l)
        if not vive:
            decir("🔴 El guardián no frena. No uses la IA con permisos libres y manda esta salida."); return 1
        candado(destino, True)
        decir("   ✅ guardián en código. Cierra y vuelve a abrir tu IA (lee sus hooks al arrancar).")
        if codex:
            decir("   " + CODEX_HOOKS)
        return 0
    quitar_registro(destino)
    if con_candado(destino):                                   # 1.0.3, prueba en Windows: en prosa no hay candado (como dice el README)
        decir("   quito el candado de organs/ (en prosa la cuida la huella)")
        candado(destino, False, aviso=False)
    nota = "lo vi, sigo en prosa" if antes == "prosa" else "cambio a prosa"
    canario.guardar_modo(destino, "prosa", nota)
    decir(f"   ⚪ guardián en prosa ({nota}): sus reglas quedan escritas en AGENTS.md y en el trato; huella de organs/ y punto de")
    decir("   partida para ver borrados tomados hoy. El canario te avisa si algo cambia.")
    decir("   Cierra y vuelve a abrir tu IA (lee sus hooks al arrancar).")
    return 0


def quitar_registro(destino):
    """Quita de los hooks de usuario el guardián de esta carpeta (o de una que ya no existe), con copia fuera de git.
    Lo usan --guardian off y la instalación en código cuando algo falla después de registrar. Devuelve cuántos quitó."""
    n = 0
    for archivo in usuario():
        try:
            datos = leer_hooks(archivo) if archivo.exists() else None
        except ValueError:
            decir(f"   ⚪ {archivo} no se puede leer: no lo toco (busca a mano la línea con organs/guardian.py)"); continue
        quitados = limpiar(datos, comando_guardian(destino)) if datos is not None else []
        if quitados:
            decir(f"   copia del anterior en {copia_de_respaldo(destino, archivo, 'guardian-desinstalacion')}")   # *instalacion/: fuera de git
            archivo.write_text(json.dumps(datos, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
            decir(f"   el guardián ya no está registrado en {archivo}")
            n += len(quitados)
    return n


MARCA_HOOK = "Endosimbiosis: segunda puerta del guardián"


def hook_secretos(destino):
    """Pone el hook pre-commit de git que llama a organs/secret_scan.py. No pisa un hook ajeno: lo copia a _QUARANTINE/ y lo encadena
    (pre-commit.anterior corre primero). Idempotente: una segunda pasada deja exactamente lo mismo. Devuelve True si quedó puesto."""
    if not shutil.which("git") or not (destino / ".git").exists():
        decir("   ⚪ sin git no hay commits que cuidar: el hook de secretos no se puso (instala git, corre git init y después python3 install.py --hook)")
        return False
    rc, ruta = correr(["git", "rev-parse", "--git-path", "hooks/pre-commit"], destino)
    if rc != 0 or not ruta.strip():
        decir("   🟡 no pude saber dónde van los hooks de git; el hook de secretos no se puso")
        return False
    hook = (destino / ruta.strip().splitlines()[0]).resolve()
    anterior = hook.with_name("pre-commit.anterior")
    if hook.exists() and MARCA_HOOK not in hook.read_text(encoding="utf-8", errors="replace"):
        decir(f"   copia de tu pre-commit de antes en {copia_de_respaldo(destino, hook)}")
        if anterior.exists():
            copia_de_respaldo(destino, anterior)                 # (si ya había uno anterior, también queda copia)
        hook.replace(anterior)                                   # se renombra (nada se borra): el hook nuevo lo llama primero
        decir(f"   tu pre-commit de antes quedó como {anterior.name}: el nuevo lo corre primero")
    secretos = (destino / "organs" / "secret_scan.py").as_posix()
    cadena = f'if [ -x "$(dirname "$0")/pre-commit.anterior" ]; then "$(dirname "$0")/pre-commit.anterior" "$@" || exit $?; fi\n' if anterior.exists() else ""
    texto = f'#!/bin/sh\n# {MARCA_HOOK} (organs/secret_scan.py). Frena el commit si lleva una llave, una contraseña o un DNI. No lo borres.\n{cadena}exec {PY} -I -B "{secretos}" --pre-commit\n'
    hook.parent.mkdir(parents=True, exist_ok=True)
    hook.write_bytes(texto.encode("utf-8"))
    hook.chmod(0o755)
    decir(f"   ✅ git: hook pre-commit puesto en {hook} (organs/secret_scan.py revisa cada commit)")
    return True


def candado(destino, poner, aviso=True):
    """Pone (o quita) el candado del sistema en organs/ y dice si quedó. Linux pide la clave (sudo).
    aviso=False: no dice «haz el cambio y después --close» (al desinstalar no hay que volver a cerrarlo)."""
    org = carpeta_organos(destino)
    if poner and (org / "__pycache__").exists():           # bajo candado no puede quedar una carpeta escribible adentro
        aparte = destino / "_QUARANTINE" / f"{HOY}-instalacion"
        aparte.mkdir(parents=True, exist_ok=True)
        shutil.move(str(org / "__pycache__"), str(aparte / f"pycache-{datetime.datetime.now():%H%M%S}"))
    archivos = [str(p) for p in sorted(org.iterdir()) if p.is_file()]
    if os.name == "nt":
        ordenes = [["attrib", "+r" if poner else "-r", a] for a in archivos]
    elif sys.platform == "darwin":
        ordenes = [["chflags", "uchg" if poner else "nouchg", *archivos, str(org)]]
    else:
        ordenes = [["sudo", "chattr", "+i" if poner else "-i", *(archivos + [str(org)] if poner else [str(org)] + archivos)]]
    ok = all(subprocess.run(o).returncode == 0 for o in ordenes)
    if ok and con_candado(destino) == poner:
        decir("   🔒 jaula con candado" + (" (muro: solo se quita con tu clave)" if sys.platform.startswith("linux") else " (seguro de puerta: lo quita el mismo usuario)") if poner
              else f"   🔓 jaula abierta: haz el cambio y después corre {PY} install.py --close" if aviso else "   🔓 candado quitado")
        return True
    decir(f"   🟡 no pude {'poner' if poner else 'quitar'} el candado de {org}")
    return False


def copiar(destino):
    if destino == KIT:
        decir("   instalo dentro del kit: uso lo que ya está aquí")
    else:
        if (destino / "core").is_dir():
            decir("   ya tienes core/: no cambio tus notas (tu núcleo es tuyo)")
            faltan = [p.name for p in sorted((KIT / "core").glob("*.md")) if not (destino / "core" / p.name).exists()]
            if faltan and preguntar(f"A tu core/ le faltan {', '.join(faltan)}. ¿Agrego esas plantillas? (las tuyas no cambian)"):
                for n in faltan:
                    shutil.copy2(KIT / "core" / n, destino / "core" / n)
                decir(f"   agregué {len(faltan)} plantillas que faltaban")
        else:
            shutil.copytree(KIT / "core", destino / "core")
            decir("   8 notas copiadas en core/")
        org = destino / "organs"
        if org.is_dir() and con_candado(destino):
            decir(f"   🔒 organs/ tiene candado: corre primero {PY} install.py --open"); raise SystemExit(1)
        if org.is_dir() and not preguntar("Ya tienes organs/. ¿Pongo los nuevos? (los de antes van a _QUARANTINE/)"):
            decir("   ⚪ dejé tus órganos como estaban")
        else:
            viejo = None
            if org.is_dir():
                aparte = destino / "_QUARANTINE" / f"{HOY}-instalacion"
                aparte.mkdir(parents=True, exist_ok=True)
                viejo = aparte / f"organs-{datetime.datetime.now():%H%M%S}"
                shutil.move(str(org), str(viejo))
                decir(f"   los órganos de antes quedaron en {aparte}")
            shutil.copytree(KIT / "organs", org, ignore=shutil.ignore_patterns("__pycache__"))
            for tuyo in ("denied.txt", "checks.txt"):              # tu denied.txt y tu checks.txt se quedan
                if viejo and (viejo / tuyo).exists():
                    shutil.copy2(viejo / tuyo, org / tuyo)
                    decir(f"   tu organs/{tuyo} se conserva")
        for extra in ("ENDOSYMBIOSIS.md", "README.md", "install.py", "plans/DEFERRED.md", "vault/INDEX.md", *MANUAL):
            if (KIT / extra).exists() and not (destino / extra).exists():
                (destino / extra).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(KIT / extra, destino / extra)
    for d in ("_QUARANTINE", ".endo", "plans", "vault"):
        (destino / d).mkdir(exist_ok=True)
    gi = destino / ".gitignore"
    previo = gi.read_text(encoding="utf-8") if gi.exists() else ""
    faltan = [l for l in (".endo/", "__pycache__/", "_QUARANTINE/*instalacion/") if l not in previo.splitlines()]
    if faltan:                                                 # la copia de tu configuración de la IA no entra a git
        with open(gi, "a", encoding="utf-8") as f:
            f.write("\n" + "\n".join(faltan) + "\n")
    agents = destino / "AGENTS.md"
    t = agents.read_text(encoding="utf-8") if agents.exists() else ""
    t = t[:t.index(INI)] + BLOQUE.strip() + t[t.index(FIN) + len(FIN):] if INI in t and FIN in t else (t.rstrip() + "\n\n" if t.strip() else "") + BLOQUE
    agents.write_text(t, encoding="utf-8")
    claude_md = destino / "CLAUDE.md"
    if not claude_md.exists():                                  # bloque 2: sin CLAUDE.md, Claude Code no lee AGENTS.md por sí solo
        claude_md.write_text("@AGENTS.md\n", encoding="utf-8")
        decir("   CLAUDE.md creado con una línea: @AGENTS.md")
    elif "@AGENTS.md" not in claude_md.read_text(encoding="utf-8"):
        with open(claude_md, "a", encoding="utf-8") as f:
            f.write("\n@AGENTS.md\n")
    decir("   órganos en organs/ · _QUARANTINE/ creada · AGENTS.md con el bloque de Endosimbiosis · CLAUDE.md que lo lee")
    if shutil.which("git") and not (destino / ".git").exists():
        subprocess.run(["git", "init", "-q"], cwd=destino)
        decir("   git init ✅ (el primer commit lo haces tú o tu IA, con su firma)")
    hook_secretos(destino)


def correr(args, cwd, timeout=120):
    try:
        r = subprocess.run(args, cwd=cwd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired:
        return 124, "se pasó del tiempo"
    except FileNotFoundError:
        return 127, "no encontrado"


def nacimiento(destino):
    sys.path.insert(0, str(destino / "organs"))
    import canary
    vive, lineas = canary.prueba_de_vida(destino)
    for l in lineas:
        decir("   " + l)
    testigo = destino / "prueba_de_nacimiento.txt"
    testigo.write_text("Si este archivo está en _QUARANTINE/, apartar funciona.\n", encoding="utf-8")
    rc, out = correr([sys.executable, "-B", str(destino / "organs" / "quarantine.py"), str(testigo), "prueba de nacimiento"], destino)
    movido = not testigo.exists() and any((destino / "_QUARANTINE").glob("*-prueba-de-nacimiento/prueba_de_nacimiento.txt"))
    decir(f"   {'✅' if movido else '🔴'} apartar: {out.strip().splitlines()[-1] if out.strip() else 'sin respuesta'}")
    return vive and movido


# --- D230 · --migrate-names: de los nombres de antes (español) a los de ahora (inglés) --------------------------------
# Marco D230: inglés como idioma base de todo lo que lee la máquina; un solo nombre por carpeta, sin alias. Esta sección
# (con el aviso del canario, que solo los detecta) es la única parte del kit que conoce los nombres viejos.
CARPETAS_VIEJAS = [("nucleo", "core"), ("organos", "organs"), ("boveda", "vault"), ("planes", "plans")]
RAIZ_VIEJOS = [("LEEME.md", "README.md"), ("ENDOSIMBIOSIS.md", "ENDOSYMBIOSIS.md"), ("MIGRAR.md", "MIGRATE.md"), ("instalar.py", "install.py")]
ORGANOS_VIEJOS = [("apartar.py", "quarantine.py"), ("canario.py", "canary.py"), ("buscar.py", "search.py"), ("libre.py", "free.py"),
                  ("secretos.py", "secret_scan.py"), ("vedadas.txt", "denied.txt"), ("chequeos.txt", "checks.txt")]
TUYOS = ("denied.txt", "checks.txt")                      # del órgano, lo único que es de la persona: se conserva (con las rutas al día)
RUTAS_VIEJAS = [(r"_BORRAR", "_QUARANTINE"),
                *[(r"(?<![\w-])" + v + r"(?=[/\\])", n) for v, n in CARPETAS_VIEJAS],
                *[(r"(?<![\w-])" + re.escape(v) + r"(?![\w])", n) for v, n in RAIZ_VIEJOS + ORGANOS_VIEJOS],
                (r"--guardian si\b", "--guardian on"), (r"--guardian no\b", "--guardian off"), (r"--abrir\b", "--open"),
                (r"--cerrar\b", "--close"), (r"--desinstalar\b", "--uninstall"), (r"--cabina\b", "--dashboard"),
                (r"--ultimos\b", "--last"), (r"--sin-prueba\b", "--no-life-test"), (r"--raiz\b", "--root"),
                (r"(install\.py\s+)--si\b", r"\1--yes")]


def carpeta_organos(destino):
    """organs/, o la de antes si todavía no se migró (para que --open, --close y --migrate-names sirvan en las dos)."""
    return destino / "organs" if (destino / "organs").is_dir() or not (destino / "organos").is_dir() else destino / "organos"


def rutas_al_dia(texto):
    """El texto con las rutas, los nombres de archivo y los flags de antes cambiados por los de ahora. Devuelve (texto, cuántos)."""
    n = 0
    for viejo, nuevo in RUTAS_VIEJAS:
        texto, k = re.subn(viejo, nuevo, texto)
        n += k
    return texto, n


def en_git(destino, ruta):
    """¿Algo de esta ruta (archivo o carpeta) está en git?"""
    rc, out = correr(["git", "ls-files", "--", ruta.relative_to(destino).as_posix()], destino)
    return rc == 0 and bool(out.strip())


def renombrar(destino, viejo, nuevo):
    """git mv si está en git; si no, mv. Nunca pisa: si el nuevo ya existe, no toca nada. Devuelve el texto de lo hecho, o None."""
    if not viejo.exists() or nuevo.exists():
        return None
    rel = lambda p: p.relative_to(destino).as_posix()
    if shutil.which("git") and (destino / ".git").exists() and en_git(destino, viejo):
        rc, out = correr(["git", "mv", "-k", "--", rel(viejo), rel(nuevo)], destino)
        if rc == 0 and nuevo.exists() and not viejo.exists():
            return f"git mv {rel(viejo)} → {rel(nuevo)}"
        if viejo.exists() and not nuevo.exists():            # git no pudo (algo raro): mv simple
            os.rename(viejo, nuevo)
            return f"mv {rel(viejo)} → {rel(nuevo)} (git mv no pudo: {out.strip()[:80]})"
        return f"git mv {rel(viejo)} → {rel(nuevo)} (a medias: revísalo con git status)"
    os.rename(viejo, nuevo)
    return f"mv {rel(viejo)} → {rel(nuevo)}"


def hooks_viejos(destino):
    """Los archivos de hooks de usuario que apuntan al guardián de esta carpeta con el nombre de antes."""
    viejo = (destino / "organos" / "guardian.py").as_posix()
    res = []
    for archivo in usuario():
        try:
            if viejo in archivo.read_text(encoding="utf-8"):
                res.append(archivo)
        except OSError:
            pass
    return res


def precommit_viejo(destino):
    """El hook pre-commit de secretos con la ruta de antes, o None."""
    if not shutil.which("git") or not (destino / ".git").exists():
        return None
    rc, ruta = correr(["git", "rev-parse", "--git-path", "hooks/pre-commit"], destino)
    h = (destino / ruta.strip().splitlines()[0]).resolve() if rc == 0 and ruta.strip() else None
    try:
        return h if h and h.exists() and MARCA_HOOK in h.read_text(encoding="utf-8") and "secretos.py" in h.read_text(encoding="utf-8") else None
    except OSError:
        return None


def textos_a_revisar(destino):
    """Las notas y archivos de la persona donde se cambian las rutas (nunca la bóveda cerrada: es textual)."""
    org = carpeta_organos(destino)
    nuc = destino / "core" if (destino / "core").is_dir() else destino / "nucleo"
    bov = destino / "vault" if (destino / "vault").is_dir() else destino / "boveda"
    pla = destino / "plans" if (destino / "plans").is_dir() else destino / "planes"
    return (sorted(nuc.glob("*.md")) + [bov / "INDEX.md", pla / "DEFERRED.md", pla / "DEFERRED_INDEX.md", destino / "AGENTS.md",
            destino / "CLAUDE.md", destino / ".gitignore", org / "vedadas.txt", org / "chequeos.txt", org / "denied.txt", org / "checks.txt"])


def borrar_viejos(destino):
    """Las carpetas _BORRAR/ del espacio (la de la raíz y las de subcarpetas: apartar usa la más cercana), sin entrar a .git."""
    res = []
    for d, dirs, _ in os.walk(destino):
        dirs[:] = [x for x in dirs if x not in (".git", "node_modules", "_QUARANTINE")]
        if "_BORRAR" in dirs:
            res.append(Path(d) / "_BORRAR")
            dirs.remove("_BORRAR")
    return res


def migrar_nombres(destino):
    """--migrate-names (D230). Renombra lo de antes (git mv si está en git, mv si no), cambia las rutas dentro de las notas y
    de los archivos de configuración, pone los órganos y las guías de este kit con su nombre nuevo, y al día los hooks.
    Nunca borra: lo que cambia deja su copia en _QUARANTINE/<hoy>-instalacion/. Idempotente: lo ya migrado no se toca."""
    decir("🌱 Endosimbiosis 1.1 — migrar los nombres (de español a inglés)")
    decir(f"   carpeta: {destino}")
    if destino == KIT:
        decir("   ⚪ esta es la carpeta del kit: tiene los nombres nuevos. Indica la carpeta de tu núcleo: "
              f"{PY} install.py --migrate-names <carpeta>"); return 0
    hooks, gancho = hooks_viejos(destino), precommit_viejo(destino)
    if hooks and not sys.stdin.isatty():
        decir("🔴 Tu guardián está en código (registrado con la ruta de antes): esto lo corre la persona en su propia terminal,"
              " no la IA. Abre una terminal y escribe el comando tú."); return 1
    org_viejo = destino / "organos"
    if org_viejo.is_dir() and not (destino / "organs").exists():
        try:
            c = canario_del_kit()
            cerrada = c.cerrado(c.atributos(org_viejo / "guardian.py"))[0]
        except Exception:
            cerrada = False
        if cerrada:
            decir(f"🔒 organos/ tiene candado: no se puede renombrar. Corre primero {PY} install.py --open {destino}")
            decir(f"   y después otra vez {PY} install.py --migrate-names {destino}. Al final, {PY} install.py --close {destino}."); return 1
    hechos, n_rutas, aparte = [], 0, destino / "_QUARANTINE" / f"{HOY}-instalacion"
    actualizar_organos = org_viejo.is_dir() and not (destino / "organs").exists()
    choques = [f"{v}/ y {n}/" for v, n in CARPETAS_VIEJAS if (destino / v).is_dir() and (destino / n).is_dir()]
    for ch in choques:
        decir(f"   🟡 tienes {ch} a la vez: no junto carpetas (decide tú qué queda); sigo con lo demás")

    # 1 · carpetas y archivos (lo de adentro de organos/ primero, con su carpeta todavía en su lugar)
    org = carpeta_organos(destino)
    for v, n in ORGANOS_VIEJOS:
        h = renombrar(destino, org / v, org / n)
        hechos += [h] if h else []
    for v, n in CARPETAS_VIEJAS + RAIZ_VIEJOS:
        h = renombrar(destino, destino / v, destino / n)
        hechos += [h] if h else []
    for b in borrar_viejos(destino):
        h = renombrar(destino, b, b.with_name("_QUARANTINE"))
        hechos += [h] if h else [f"🟡 {b.relative_to(destino).as_posix()} queda: al lado ya hay un _QUARANTINE/ (no junto carpetas)"]
    for h in hechos:
        decir("   " + h)

    # 2 · los órganos y las guías de este kit, con el nombre nuevo (los de antes no conocen las rutas nuevas)
    if actualizar_organos and (destino / "organs").is_dir():
        aparte.mkdir(parents=True, exist_ok=True)
        copia = aparte / f"organos-{datetime.datetime.now():%H%M%S}"
        shutil.copytree(destino / "organs", copia, ignore=shutil.ignore_patterns("__pycache__"))
        puestos = []
        for p in sorted((KIT / "organs").iterdir()):
            if p.is_file() and p.name not in TUYOS and p.suffix in (".py", ".txt"):
                shutil.copy2(p, destino / "organs" / p.name)
                puestos.append(p.name)
        for p in TUYOS:                                        # si no tenía denied.txt o checks.txt, van los del kit
            if not (destino / "organs" / p).exists():
                shutil.copy2(KIT / "organs" / p, destino / "organs" / p)
        for guia in ("README.md", "ENDOSYMBIOSIS.md", "MIGRATE.md", "install.py"):
            if (destino / guia).exists():
                shutil.copy2(destino / guia, aparte / f"{guia}-antes")
            shutil.copy2(KIT / guia, destino / guia)
        for m in MANUAL:                                            # D231: el manual de Simbiosis, si no lo tenía
            if not (destino / m).exists():
                (destino / m).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(KIT / m, destino / m)
        decir(f"   órganos de este kit puestos ({len(puestos)}: {', '.join(puestos)}); tus denied.txt y checks.txt se conservan")
        decir(f"   README.md, ENDOSYMBIOSIS.md, MIGRATE.md e install.py de este kit · los de antes, copia en {copia.parent}")

    # 3 · las rutas dentro de tus notas y de la configuración (la bóveda cerrada no se toca: es textual)
    for p in textos_a_revisar(destino):
        if not p.is_file():
            continue
        t = p.read_text(encoding="utf-8")
        if p.name == "AGENTS.md" and INI in t and FIN in t:
            t2 = t[:t.index(INI)] + BLOQUE.strip() + t[t.index(FIN) + len(FIN):]
            t2, k = rutas_al_dia(t2)
            k += t2 != t and not k
        else:
            t2, k = rutas_al_dia(t)
        if t2 != t:
            p.write_text(t2, encoding="utf-8")
            n_rutas += k
            decir(f"   rutas al día en {p.relative_to(destino).as_posix()} ({k})")

    # 4 · los hooks: el guardián registrado (código) y el pre-commit de secretos
    viejo, nuevo = (destino / "organos" / "guardian.py").as_posix(), (destino / "organs" / "guardian.py").as_posix()
    for archivo in hooks:
        decir(f"   copia del anterior en {copia_de_respaldo(destino, archivo)}")
        archivo.write_text(archivo.read_text(encoding="utf-8").replace(viejo, nuevo), encoding="utf-8")
        decir(f"   el guardián registrado en {archivo} apunta ahora a {nuevo}")
    if gancho:
        decir(f"   copia del pre-commit anterior en {copia_de_respaldo(destino, gancho)}")
        gancho.write_text(rutas_al_dia(gancho.read_text(encoding="utf-8"))[0], encoding="utf-8")
        decir(f"   git: el pre-commit llama ahora a organs/secret_scan.py")

    # 5 · la huella del modo prosa (los órganos cambiaron de nombre y de versión: la toma de nuevo la persona, aquí)
    c = canario_del_kit()
    modo = c.leer_modo(destino)
    if modo and actualizar_organos:
        c.guardar_modo(destino, None, None, {**modo, "huella": c.huella(destino), "nota": "migración de nombres (D230)"})
        decir("   huella de organs/ tomada de nuevo (migración de nombres)")

    if not hechos and not n_rutas and not hooks and not gancho:
        decir("   ✅ nada que migrar: ya tiene los nombres nuevos"); return 0
    if shutil.which("git") and (destino / ".git").exists():
        cambiados = [p.relative_to(destino).as_posix() for p in textos_a_revisar(destino) + [destino / "organs", destino / "README.md",
                     destino / "ENDOSYMBIOSIS.md", destino / "MIGRATE.md", destino / "install.py"] if p.exists() and en_git(destino, p)]
        if cambiados:                                          # lo renombrado ya está en el índice (git mv); el contenido nuevo también
            correr(["git", "add", "--", *cambiados], destino)
    decir(f"\n   ✅ listo: {len(hechos)} renombres · {n_rutas} rutas al día" + (f" · {len(hooks)} registros del guardián" if hooks else "")
          + (" · pre-commit" if gancho else "") + ". Nada se borró.")
    if (destino / ".git").exists():
        decir("   Revisa con git status (son renombres) y haz el commit de la migración.")
    if hooks:
        decir("   Cierra y abre tu IA (lee sus hooks al arrancar)." + (f" Después pon el candado: {PY} install.py --close {destino}" if modo.get("modo") == "codigo" else ""))
    decir(f"   Comprueba: {PY} organs/canary.py (desde la carpeta de tu núcleo)")
    return 0


def main():
    argv = sys.argv[1:]
    valor = argv[argv.index("--guardian") + 1] if "--guardian" in argv and argv.index("--guardian") + 1 < len(argv) else ""
    args = [a for i, a in enumerate(argv) if not a.startswith("--") and not (i and argv[i - 1] == "--guardian")]
    destino = Path(args[0]).expanduser().resolve() if args else KIT
    if "--guardian" in argv:
        return cambiar_modo(destino, valor)
    if "--migrate-names" in argv:
        return migrar_nombres(destino)
    if "--uninstall" in sys.argv:
        return desinstalar(destino)
    if "--open" in sys.argv or "--close" in sys.argv:
        return 0 if candado(destino, "--close" in sys.argv) else 1
    if "--hook" in sys.argv:
        return 0 if hook_secretos(destino) else 1
    decir("🌱 Endosimbiosis 1.1 — instalador")
    decir(f"   carpeta: {destino}")
    decir("\n1. Revisar")
    if sys.version_info < (3, 10):
        decir("🔴 Hace falta Python 3.10 o más nuevo."); return 1
    if os.name == "nt" and " " in str(destino):
        decir("🔴 La carpeta tiene espacios; en Windows el comando del guardián no los admite. Usa por ejemplo C:\\proyectos\\mi-nucleo."); return 1
    claude, agy, codex = shutil.which("claude"), shutil.which("agy"), hay_codex()
    decir(f"   Python {sys.version.split()[0]} ✅ · git {'✅' if shutil.which('git') else '⚪ (sin git, el canario y DAISY no comparan)'}"
          f" · Claude Code {'✅' if claude else '⚪'} · Antigravity {'✅' if agy else '⚪'} · Codex {'✅' if codex else '⚪'}")
    previos = [n for n in ("core", "organs", "AGENTS.md") if (destino / n).exists() and destino != KIT]
    if previos:
        decir(f"   ⚪ ya tienes un sistema aquí ({', '.join(previos)}): no lo piso; te pregunto antes de cambiar algo")
    if not preguntar("¿Instalo aquí?"):
        decir("   No toqué nada."); return 0
    destino.mkdir(parents=True, exist_ok=True)
    antes = ganchos(destino)                                   # 1.1: la lista de ganchos de antes, para compararla al final

    decir("\n2. Copiar")
    copiar(destino)

    decir("\n3. El modo del guardián")
    codigo = elegir_modo(destino)
    if codigo:
        decir("   código: lo registro a nivel de usuario (vigila en todas tus carpetas) cuando pasen las pruebas del paso 4")
    else:
        decir("   ⚪ guardián en prosa (elegido): copiado en organs/, sin registrar; sus reglas están en AGENTS.md y en core/agreement.md.")
        decir(f"   Para que frene: {PY} install.py --guardian on")
    canario_del_kit().guardar_modo(destino, "codigo" if codigo else "prosa", "elegido al instalar")

    decir("\n4. Probar")
    malos = 0
    for o in ("guardian", "quarantine", "free", "canary", "search", "daisy", "secret_scan"):
        rc, out = correr([sys.executable, "-B", str(destino / "organs" / f"{o}.py"), "--selftest"], destino)
        malos += rc != 0
        resumen = [l for l in out.strip().splitlines() if "casos bien" in l or l.startswith("secretos:")]
        decir(f"   {'✅' if rc == 0 else '🔴'} {' · '.join(resumen) if resumen else o}")      # 1.0.3: el canario da tres líneas
    if malos:
        decir("🔴 Algún órgano no pasó su prueba. No sigas: manda esta salida a quien te pasó el kit."
              + (" El guardián no quedó registrado (no se registra si una prueba falla)." if codigo else "")); return 1
    nuevo = False
    if codigo:                                                 # 1.0.3, prueba en Windows: se registra solo con todas las pruebas en verde
        nuevo = not registrado_aqui(destino)
        registrados = [registrar(destino, HOME / ".claude" / "settings.json", "Claude Code")]
        if agy or (HOME / ".gemini").exists():
            registrados.append(registrar(destino, HOME / ".gemini" / "config" / "hooks.json", "Antigravity"))
        codex = codex and registrar(destino, HOME / ".codex" / "hooks.json", "Codex")
        registrados.append(codex)
        if not any(registrados):
            decir("   ⚪ el guardián no quedó registrado: la prueba de nacimiento no se puede hacer"); return 1
    if not nacimiento(destino):
        if codigo and nuevo and quitar_registro(destino):
            decir("   quité el registro que acababa de poner: un guardián que no frena no se deja registrado a medias.")
        revisar_ganchos(antes, destino)
        decir("🔴 El guardián no nació. No uses la IA con permisos libres y manda esta salida." if codigo
              else "🔴 El núcleo no nació (apartar no movió el archivo de prueba). Manda esta salida a quien te pasó el kit."); return 1
    decir("   ✅ el guardián nació: frena el borrado de prueba y apartar mueve a _QUARANTINE/" if codigo
          else "   ✅ el núcleo nació: apartar mueve a _QUARANTINE/ y el guardián queda en prosa (elegido)")

    if not revisar_ganchos(antes, destino):
        decir("🔴 Se cayó un gancho que ya tenías. Manda esta salida a quien te pasó el kit."); return 1

    decir("\n5. Listo")
    if codigo:
        candado(destino, True)
    else:
        decir("   en prosa organs/ queda sin candado: el canario guardó su huella y te avisa si cambia")
    decir("   Activa las instantáneas de tu sistema: en Windows, «Historial de archivos»; en Mac, «Time Machine»; en Linux,")
    decir("   las instantáneas de tu disco (Timeshift u otra). Son la red que el guardián no es.")
    decir(f"   Anota tus carpetas privadas (por ejemplo la de los datos de tus clientes) en {destino / 'organs' / 'denied.txt'},")
    if codigo:
        decir(f"   una por línea, a mano ({PY} install.py --open, lo editas, {PY} install.py --close): la IA no puede escribirlo.")
    else:
        decir(f"   una por línea, a mano; después corre {PY} install.py --guardian off (toma la huella de nuevo). La IA no lo escribe.")
    decir("   Abre tu IA siempre en ESTA carpeta y dile: «Lee ENDOSYMBIOSIS.md y arma mi núcleo conmigo, una pregunta a la vez.»")
    if codigo:
        decir(f"   Para trabajar sin que el guardián te pare en tus carpetas privadas: {PY} organs/free.py 30 (pide tu clave).")
    if codigo and codex:
        decir("   " + CODEX_HOOKS)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (EOFError, KeyboardInterrupt):                      # 1.0.3, prueba en Windows: sin entrada (pegado por ssh, sin terminal)
        decir("\n🔴 El instalador se cortó esperando tu respuesta (no le llegó ninguna). Córrelo en tu propia terminal y responde a")
        decir(f"   cada pregunta, o, para no responder nada, {PY} install.py --yes (el guardián queda en prosa). Lo que ya hizo se repite sin problema.")
        sys.exit(1)
